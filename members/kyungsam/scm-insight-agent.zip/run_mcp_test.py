"""
2단계 — Vega-Lite MCP 연동 테스트 (증적 생성용)

무엇을 확인하는가
    1) MCP 서버 설치 확인
    2) stdio로 접속해 도구 목록 조회 (save_data / visualize_data 가 보이는가)
    3) text 모드 왕복 — 데이터 저장 -> 시각 인코딩 전달
    4) png 모드 왕복 — 서버가 실제로 렌더한 PNG를 받아 docs/vegalite_sample.png 로 저장
    5) 그래프 통합 — MCP를 켠 상태로 파이프라인 전체 실행

사용법
    python run_mcp_test.py

서버가 설치되어 있지 않으면 1)에서 안내를 출력하고 멈춘다.
    pip install git+https://github.com/isaacwasserman/mcp-vegalite-server.git
"""

import base64
import json
import sys
from pathlib import Path

# Windows 한국어 콘솔(cp949)에서 출력이 멈추지 않도록 한다. 자세한 설명은 run_demo.py 참고.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(errors="replace")

from data.dummy_payloads import TIME_SERIES_PAYLOAD
from scm_agent import config
from scm_agent.chart.mcp_client import is_server_available, render_chart
from scm_agent.chart.spec import AxisSpec, ChartSpec, DataPoint
from scm_agent.chart.vegalite_adapter import call_vegalite_mcp, to_vegalite
from scm_agent.config import PROJECT_ROOT
from scm_agent.graph import run_pipeline

# 결과를 모아 마지막에 요약을 찍는다.
RESULTS: list[tuple[str, bool, str]] = []


def record(step: str, passed: bool, detail: str) -> None:
    """단계별 결과를 기록하고 바로 출력한다."""
    if passed:
        mark = "PASS"
    else:
        mark = "FAIL"

    print(f"  [{mark}] {step} : {detail}")
    RESULTS.append((step, passed, detail))


def print_step(number: int, title: str) -> None:
    print()
    print("-" * 72)
    print(f"{number}) {title}")
    print("-" * 72)


def make_sample_spec() -> ChartSpec:
    """테스트용 중립 차트 스펙 하나를 만든다 (더미 시계열)."""
    return ChartSpec(
        chart_type="line",
        title="월별 발주수량 추이 (MCP 연동 테스트)",
        x_axis=AxisSpec(field="YM", label="연월"),
        y_axis=AxisSpec(field="ORDER_QTY", label="발주수량", unit="EA"),
        data=[
            DataPoint(x="2026-03", y=2000.0),
            DataPoint(x="2026-04", y=2400.0),
            DataPoint(x="2026-05", y=2800.0),
        ],
    )


def step_1_check_server() -> bool:
    print_step(1, "MCP 서버 설치 확인")

    available = is_server_available()
    if available:
        record("서버 실행 파일", True, f"{config.VEGALITE_MCP_COMMAND} 발견")
    else:
        record(
            "서버 실행 파일",
            False,
            f"{config.VEGALITE_MCP_COMMAND} 없음. README 6장의 설치 방법 참고",
        )
    return available


def step_2_list_tools() -> None:
    print_step(2, "도구 목록 조회 (stdio 접속)")

    spec = make_sample_spec()
    result = call_vegalite_mcp(spec, output_type="text")

    tool_names = result.get("tool_names", [])
    expected = {"save_data", "visualize_data"}

    passed = expected.issubset(set(tool_names))
    record("도구 목록", passed, f"{tool_names}")


def step_3_text_mode() -> None:
    print_step(3, "text 모드 왕복 (2주차 확정 모드)")

    spec = make_sample_spec()
    result = call_vegalite_mcp(spec, output_type="text")

    record("save_data", "saved" in result.get("save_message", ""), result.get("save_message", ""))
    record(
        "visualize_data",
        result.get("ok", False),
        result.get("visualize_message") or result.get("error", ""),
    )

    print()
    print("  서버에 보낸 인코딩 스펙 (데이터 없음. 데이터는 서버가 주입):")
    print(json.dumps(result.get("sent_specification", {}), ensure_ascii=False, indent=4))
    print(f"  서버에 올린 데이터 행 수: {result.get('sent_row_count')}")


def step_4_png_mode() -> None:
    print_step(4, "png 모드 왕복 (렌더 결과 확인용)")

    spec = make_sample_spec()
    result = call_vegalite_mcp(spec, output_type="png")

    image_base64 = result.get("image_base64")
    if image_base64 is None:
        record("PNG 수신", False, result.get("error") or "이미지가 없습니다")
        return

    image_bytes = base64.b64decode(image_base64)
    output_path = Path(PROJECT_ROOT) / "docs" / "vegalite_sample.png"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(image_bytes)

    record("PNG 수신", True, f"{len(image_bytes):,} bytes -> {output_path.name}")


def step_5_pipeline_with_mcp() -> None:
    print_step(5, "그래프 통합 실행 (MCP 켠 상태)")

    # 실행 중에 설정을 켠다. (config 모듈을 통째로 import 했기 때문에 가능하다)
    original = config.USE_VEGALITE_MCP
    config.USE_VEGALITE_MCP = True

    try:
        response = run_pipeline(TIME_SERIES_PAYLOAD)
    finally:
        config.USE_VEGALITE_MCP = original

    chart_render = response.get("chart_render") or {}
    passed = chart_render.get("ok", False) and response.get("output_type") == "line"

    record(
        "파이프라인 + MCP",
        passed,
        f"output_type={response.get('output_type')}, "
        f"mcp_used={chart_render.get('mcp_used')}, "
        f"message={chart_render.get('message')}",
    )


def step_6_local_spec() -> None:
    print_step(6, "MCP 없이 쓰는 완결 스펙 (프론트 직접 렌더용)")

    spec = make_sample_spec()
    vegalite_spec = to_vegalite(spec)

    output_path = Path(PROJECT_ROOT) / "docs" / "vegalite_sample_spec.json"
    output_path.write_text(
        json.dumps(vegalite_spec, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    has_data = "data" in vegalite_spec
    record("완결 스펙 저장", has_data, f"{output_path.name} (data 포함={has_data})")


def print_summary() -> None:
    print()
    print("=" * 72)
    print("  연동 테스트 요약")
    print("=" * 72)

    failed = 0
    for step, passed, detail in RESULTS:
        if passed:
            mark = "PASS"
        else:
            mark = "FAIL"
            failed = failed + 1
        print(f"  [{mark}] {step}")

    print()
    if failed == 0:
        print(f"  전체 {len(RESULTS)}개 항목 통과")
    else:
        print(f"  {len(RESULTS)}개 중 {failed}개 실패")


def main() -> None:
    print("=" * 72)
    print("  Vega-Lite MCP 연동 테스트 (2단계)")
    print("=" * 72)
    print(f"  서버 명령 : {config.VEGALITE_MCP_COMMAND}")
    print(f"  전송 방식 : stdio (서브프로세스)")
    print(f"  기본 모드 : {config.VEGALITE_MCP_OUTPUT_TYPE}")

    if not step_1_check_server():
        print()
        print("  서버가 없어 이후 단계를 건너뜁니다.")
        print("  설치: pip install git+https://github.com/isaacwasserman/mcp-vegalite-server.git")
        print_summary()
        return

    step_2_list_tools()
    step_3_text_mode()
    step_4_png_mode()
    step_5_pipeline_with_mcp()
    step_6_local_spec()
    print_summary()


if __name__ == "__main__":
    main()
