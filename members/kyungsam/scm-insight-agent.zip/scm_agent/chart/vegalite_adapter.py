"""
Vega-Lite adapter — 중립 스펙을 Vega-Lite 문법으로 옮기고, MCP 서버에 넘긴다.

2주차 MCP 결정 (2주차 산출물 6장)
  - Vega-Lite MCP 채택 (차트 훅, text 모드). save_data + visualize_data 2개 도구
  - langchain-mcp-adapters 로 LangChain/LangGraph 호환 도구로 변환, stdio 전송
  - 데이터는 서버가 주입하고 LLM은 시각 인코딩만 정의한다

이 파일의 역할 분담
  to_vegalite_encoding() — 데이터 없는 '인코딩만' 스펙. MCP의 visualize_data 에 넘긴다.
  to_vegalite()          — 데이터까지 넣은 완결 스펙. 프론트가 그대로 그릴 수 있다.
  call_vegalite_mcp()    — 위 둘을 써서 실제 MCP 서버를 호출한다.

Constitution: 중립 스펙 + adapter.
  present 노드는 중립 스펙까지만 만들고, Vega-Lite라는 단어는 이 파일 밖으로 나가지 않는다.
  나중에 ECharts로 바꾸더라도 이 파일 옆에 echarts_adapter.py 를 하나 더 두면 된다.

[2단계 상태] MCP 연동 완료.
"""

from scm_agent.chart.mcp_client import render_chart
from scm_agent.chart.spec import ChartSpec

# 중립 chart_type -> Vega-Lite mark 이름
MARK_BY_CHART_TYPE = {
    "line": "line",
    "bar": "bar",
}


def to_data_rows(spec: ChartSpec) -> list[dict]:
    """중립 스펙의 데이터 점들을 서버에 올릴 행 목록으로 바꾼다."""
    rows: list[dict] = []
    for point in spec.data:
        rows.append({"x": point.x, "y": point.y})
    return rows


def to_vegalite_encoding(spec: ChartSpec) -> dict:
    """데이터를 뺀 Vega-Lite 스펙(인코딩만)을 만든다.

    visualize_data 도구는 데이터를 서버가 붙여 주므로 data 필드를 넣으면 안 된다.
    """
    mark = MARK_BY_CHART_TYPE.get(spec.chart_type)
    if mark is None:
        # kpi / table 은 차트가 아니므로 Vega-Lite로 그리지 않는다.
        raise ValueError(f"Vega-Lite로 그릴 수 없는 유형입니다: {spec.chart_type}")

    if spec.x_axis is not None:
        x_title = spec.x_axis.label
    else:
        x_title = "x"

    if spec.y_axis is not None:
        y_title = spec.y_axis.label
    else:
        y_title = "y"

    encoding_spec = {
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "title": spec.title,
        # 크기를 지정하지 않으면 축 개수에 따라 그림이 지나치게 좁아진다.
        "width": 480,
        "height": 280,
        "mark": mark,
        "encoding": {
            "x": {"field": "x", "type": "nominal", "title": x_title},
            "y": {"field": "y", "type": "quantitative", "title": y_title},
        },
    }
    return encoding_spec


def to_vegalite(spec: ChartSpec) -> dict:
    """데이터까지 포함한 완결 Vega-Lite 스펙을 만든다 (MCP 없이 쓸 때)."""
    vegalite_spec = to_vegalite_encoding(spec)
    vegalite_spec["data"] = {"values": to_data_rows(spec)}
    return vegalite_spec


def make_data_name(spec: ChartSpec) -> str:
    """서버에 저장할 데이터 테이블 이름을 만든다.

    같은 이름을 쓰면 이전 데이터를 덮어쓰므로, 차트 종류를 이름에 넣어 구분한다.
    """
    return f"scm_{spec.chart_type}_data"


def call_vegalite_mcp(spec: ChartSpec, output_type: str | None = None) -> dict:
    """Vega-Lite MCP 서버를 호출해 차트를 만든다.

    순서 (2주차 산출물 6장)
      1) langchain-mcp-adapters로 MCP 서버(stdio)에 붙는다
      2) save_data 로 데이터를 서버에 넘긴다          ← 데이터는 서버가 주입한다
      3) visualize_data 로 시각 인코딩만 정의한다      ← 수치가 스펙에 섞이지 않는다
      4) 결과를 dict로 돌려준다 (present가 응답에 함께 담는다)

    실패하더라도 예외를 던지지 않는다. ok=False 로 돌려주고 파이프라인은 계속 간다.
    """
    try:
        encoding_spec = to_vegalite_encoding(spec)
    except ValueError as error:
        return {"ok": False, "mcp_used": False, "error": str(error)}

    data_rows = to_data_rows(spec)

    if output_type is None:
        result = render_chart(
            data_name=make_data_name(spec),
            data_rows=data_rows,
            vegalite_spec=encoding_spec,
        )
    else:
        result = render_chart(
            data_name=make_data_name(spec),
            data_rows=data_rows,
            vegalite_spec=encoding_spec,
            output_type=output_type,
        )

    # 서버에 무엇을 보냈는지 함께 남긴다 (증적·디버깅용)
    result["sent_specification"] = encoding_spec
    result["sent_row_count"] = len(data_rows)
    return result
