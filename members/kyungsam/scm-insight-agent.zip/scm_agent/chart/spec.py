"""
라이브러리 중립 차트 의도 스펙 (Constitution: 중립 스펙 + adapter)

Vega-Lite든 ECharts든, 프론트가 무엇을 쓰든 바뀌지 않는 '차트의 의도'만 담는다.
실제 라이브러리 문법으로 바꾸는 일은 adapter(chart/vegalite_adapter.py)가 한다.

Pydantic 모델로 정의하는 이유
  - present 노드가 조립한 스펙이 형식에 맞는지 코드가 검증할 수 있다.
  - 검증에 실패하면 문서대로 1회 재시도 → table degrade 로 안전하게 떨어진다.
"""

from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator


class AxisSpec(BaseModel):
    """축 하나의 정보."""

    field: str = Field(description="데이터 컬럼명")
    label: str = Field(description="화면에 표시할 한글 이름")
    unit: Optional[str] = Field(default=None, description="단위 (공통 계층 units 키)")


class DataPoint(BaseModel):
    """차트에 찍을 점 하나."""

    x: str
    y: float


class ChartSpec(BaseModel):
    """중립 차트 스펙."""

    chart_type: Literal["line", "bar", "kpi", "table"]
    title: str
    x_axis: Optional[AxisSpec] = None
    y_axis: Optional[AxisSpec] = None
    data: list[DataPoint] = Field(default_factory=list)
    # KPI 카드처럼 점이 아니라 값 하나만 필요한 경우에 쓴다.
    value: Optional[float] = None

    @field_validator("data")
    @classmethod
    def check_data_not_empty_for_series_chart(cls, value, info):
        """line/bar 차트인데 데이터가 비어 있으면 잘못된 스펙이다."""
        chart_type = info.data.get("chart_type")
        if chart_type in ("line", "bar") and len(value) == 0:
            raise ValueError(f"{chart_type} 차트에는 데이터 점이 최소 1개 필요합니다")
        return value
