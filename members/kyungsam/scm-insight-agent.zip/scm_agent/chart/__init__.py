"""차트 관련 모듈.

    spec.py             : 라이브러리 중립 차트 의도 스펙 (Pydantic)
    vegalite_adapter.py : 중립 스펙 -> Vega-Lite 변환 / MCP 연동 자리
"""
