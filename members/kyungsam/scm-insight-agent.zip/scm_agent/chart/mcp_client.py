"""
Vega-Lite MCP 클라이언트 — stdio로 서버를 띄우고 도구 2개를 호출한다. (2단계)

2주차 산출물 6장 결정 사항
  - 연동 방식 : langchain-mcp-adapters 로 MCP 도구를 LangChain/LangGraph 호환 도구로 변환
  - 전송      : stdio (클라이언트가 서버를 서브프로세스로 직접 띄운다)
  - 도구      : save_data (데이터 저장) + visualize_data (시각 인코딩 정의)
  - 원칙      : 데이터는 서버가 주입한다. 인코딩(어떻게 그릴지)만 넘긴다.

왜 도구가 2개로 나뉘어 있는가 (이 프로젝트에 중요한 지점)
  save_data 로 데이터를 먼저 서버 메모리에 올려 두고,
  visualize_data 에는 '데이터 이름'과 '인코딩'만 넘긴다.
  즉 수치가 스펙 문자열에 섞여 들어가지 않는다.
  나중에 이 자리에 LLM을 붙이더라도 LLM은 인코딩만 만지게 되고
  수치는 코드가 만든 것이 그대로 서버로 간다 → '사실은 코드, LLM은 표현'과 구조가 일치한다.

★ 세션을 한 번만 열고 두 호출을 이어서 해야 한다.
  서버는 저장한 데이터를 '그 프로세스의 메모리'에 들고 있기 때문에,
  save_data 와 visualize_data 를 다른 세션에서 부르면 데이터를 찾지 못한다.

[2단계 상태] 실제 연동 완료 (text / png 모드 모두 확인).
[다음 할 일] W7 표현 개선 루프에서 렌더 결과를 관찰 신호로 쓰는 것 검토
"""

import asyncio
import json
import shutil
from typing import Any, Optional

from scm_agent.config import (
    VEGALITE_MCP_ARGS,
    VEGALITE_MCP_COMMAND,
    VEGALITE_MCP_CWD,
    VEGALITE_MCP_OUTPUT_TYPE,
    VEGALITE_MCP_TIMEOUT_SECONDS,
)


def build_connection_config(output_type: str) -> dict:
    """MultiServerMCPClient에 넘길 연결 설정을 만든다.

    langchain-mcp-adapters의 stdio 설정 키
        transport : "stdio"
        command   : 실행 파일
        args      : 실행 인자
        cwd       : 작업 디렉터리 (서버가 logs/ 아래에 로그를 남기므로 필요)
    """
    if output_type == VEGALITE_MCP_OUTPUT_TYPE:
        args = list(VEGALITE_MCP_ARGS)
    else:
        # 호출자가 모드를 바꿔 부른 경우 (연동 테스트에서 png를 확인할 때)
        args = ["--output-type", output_type]

    return {
        "vegalite": {
            "transport": "stdio",
            "command": VEGALITE_MCP_COMMAND,
            "args": args,
            "cwd": str(VEGALITE_MCP_CWD),
        }
    }


def is_server_available() -> bool:
    """MCP 서버 실행 파일이 설치되어 있는지 확인한다.

    없으면 연동을 건너뛰고 중립 스펙만으로 응답한다(장애 격리).
    """
    return shutil.which(VEGALITE_MCP_COMMAND) is not None


def to_specification_string(vegalite_spec: dict) -> str:
    """Vega-Lite 스펙 dict를 서버에 넘길 문자열로 바꾼다.

    ★ 주의 (서버 구현상의 제약)
      이 MCP 서버는 받은 문자열을 파이썬 eval()로 해석한다.
      그래서 JSON의 true / false / null 이 들어 있으면 파이썬이 해석하지 못한다.
      (파이썬은 True / False / None 이라고 쓴다)
      그런 값이 섞인 경우에는 JSON 대신 파이썬 리터럴 표기로 보낸다. eval이므로 둘 다 통한다.
    """
    json_text = json.dumps(vegalite_spec, ensure_ascii=False)

    has_json_literal = False
    for token in ("true", "false", "null"):
        if token in json_text:
            has_json_literal = True

    if has_json_literal:
        return repr(vegalite_spec)
    return json_text


def extract_text(content: Any) -> str:
    """도구가 돌려준 content에서 사람이 읽을 텍스트만 뽑는다.

    content는 보통 [{"type": "text", "text": "..."}] 모양의 목록이다.
    """
    if isinstance(content, str):
        return content

    texts: list[str] = []
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(str(block.get("text", "")))
    return " ".join(texts)


def extract_image_base64(content: Any) -> Optional[str]:
    """png 모드에서 돌아온 이미지(base64)를 뽑는다. 없으면 None."""
    if not isinstance(content, list):
        return None

    for block in content:
        if isinstance(block, dict) and block.get("type") == "image":
            # 어댑터 버전에 따라 키 이름이 base64 또는 data 로 온다.
            image_data = block.get("base64")
            if image_data is None:
                image_data = block.get("data")
            if image_data is not None:
                return str(image_data)
    return None


async def render_chart_async(
    data_name: str,
    data_rows: list[dict],
    vegalite_spec: dict,
    output_type: str,
) -> dict:
    """MCP 서버에 붙어 save_data -> visualize_data 를 차례로 호출한다."""

    # import를 함수 안에서 하는 이유:
    # langchain-mcp-adapters를 설치하지 않아도 1단계 파이프라인은 돌아가야 하기 때문이다.
    from langchain_mcp_adapters.client import MultiServerMCPClient
    from langchain_mcp_adapters.tools import load_mcp_tools

    client = MultiServerMCPClient(build_connection_config(output_type))

    # ★ with 블록 하나 안에서 두 호출을 모두 끝낸다 (서버 메모리를 공유해야 하므로)
    async with client.session("vegalite") as session:
        tools = await load_mcp_tools(session)

        tool_by_name: dict[str, Any] = {}
        for tool in tools:
            tool_by_name[tool.name] = tool

        if "save_data" not in tool_by_name or "visualize_data" not in tool_by_name:
            raise RuntimeError(
                f"기대한 도구가 없습니다. 서버가 제공한 도구: {list(tool_by_name)}"
            )

        # 1) 데이터를 서버에 올린다 (수치는 여기서만 이동한다)
        save_result = await tool_by_name["save_data"].ainvoke(
            {"name": data_name, "data": data_rows}
        )

        # 2) 인코딩만 넘겨 시각화를 요청한다
        #    ToolCall 형태로 부르면 결과가 ToolMessage로 와서 content를 꺼내기 쉽다.
        visualize_call = {
            "name": "visualize_data",
            "args": {
                "data_name": data_name,
                "vegalite_specification": to_specification_string(vegalite_spec),
            },
            "id": "visualize_data_call",
            "type": "tool_call",
        }
        visualize_message = await tool_by_name["visualize_data"].ainvoke(visualize_call)

        visualize_content = getattr(visualize_message, "content", visualize_message)

        return {
            "ok": True,
            "mcp_used": True,
            "output_type": output_type,
            "tool_names": sorted(tool_by_name.keys()),
            "save_message": extract_text(save_result),
            "visualize_message": extract_text(visualize_content),
            "image_base64": extract_image_base64(visualize_content),
            "error": None,
        }


def render_chart(
    data_name: str,
    data_rows: list[dict],
    vegalite_spec: dict,
    output_type: str = VEGALITE_MCP_OUTPUT_TYPE,
) -> dict:
    """render_chart_async를 동기 함수로 감싼다.

    LangGraph 노드는 동기 함수라서 여기서 asyncio.run으로 돌린다.
    실패하더라도 예외를 밖으로 던지지 않고 ok=False로 돌려준다 (장애 격리).
    """
    if not is_server_available():
        return {
            "ok": False,
            "mcp_used": False,
            "output_type": output_type,
            "error": (
                f"MCP 서버 실행 파일을 찾을 수 없습니다: {VEGALITE_MCP_COMMAND}. "
                "README 6장의 설치 방법을 참고하세요."
            ),
        }

    async def run_with_timeout() -> dict:
        return await asyncio.wait_for(
            render_chart_async(data_name, data_rows, vegalite_spec, output_type),
            timeout=VEGALITE_MCP_TIMEOUT_SECONDS,
        )

    try:
        return asyncio.run(run_with_timeout())
    except RuntimeError as error:
        # 이미 asyncio 루프가 돌고 있는 곳(예: async 웹 서버)에서 부르면 여기로 온다.
        return {
            "ok": False,
            "mcp_used": False,
            "output_type": output_type,
            "error": (
                f"동기 호출 실패: {error}. "
                "비동기 환경에서는 render_chart_async를 await 하세요."
            ),
        }
    except Exception as error:
        return {
            "ok": False,
            "mcp_used": False,
            "output_type": output_type,
            "error": f"{type(error).__name__}: {error}",
        }
