"""
오프라인 Semantic Layer 빌더 — 스텁 (W6)

2주차 산출물 5.1
  런타임 그래프와 분리된 '두 번째 파이프라인'이다.
  입력 : 화면 설명 + 해당 화면의 SQL Set
  처리 : SQL에서 컬럼·조인·조건을 추출하고, 설명에서 목적을 추출해
         공통 계층 entity에 매핑한 뒤 화면별 계층 초안을 만든다
  트리거 : batch 또는 버튼 (실시간 아님)
  결과 : 사람이 검수한 뒤 확정

Constitution: 런타임 실시간 SQL 파싱은 배제한다.
              따라서 이 모듈은 그래프에서 절대 import 하지 않는다.

[1단계 상태] 함수 뼈대와 출력 형식만. 내부는 비어 있다.
[W6 할 일] Skill 패턴(SKILL.md 지시문 + 스크립트 폴더)으로 재사용 가능하게 조직
"""

from pathlib import Path

import yaml

from scm_agent.config import SCREEN_LAYER_DIR


def extract_columns_from_sql(sql_text: str) -> list[dict]:
    """[TBD · W6] SQL에서 컬럼·조인·조건을 추출한다."""
    raise NotImplementedError("W6에서 구현")


def infer_purpose_from_description(description: str) -> str:
    """[TBD · W6] 화면 설명에서 사용 목적을 추출한다."""
    raise NotImplementedError("W6에서 구현")


def map_to_common_entities(columns: list[dict]) -> list[dict]:
    """[TBD · W6] 추출한 컬럼을 공통 계층 entity에 매핑한다."""
    raise NotImplementedError("W6에서 구현")


def build_screen_layer_draft(
    screen_id: str,
    description: str,
    sql_set: list[str],
) -> dict:
    """화면별 계층 YAML 초안(dict)을 만든다. [TBD · W6]

    지금은 '사람이 채울 자리'가 표시된 빈 틀만 돌려준다.
    """
    return {
        "screen_id": screen_id,
        "version": 0.1,
        "reviewed_by": None,  # 사람 검수 전
        "purpose": "TBD",
        "description": description,
        "sql_set": sql_set,
        "columns": [],  # TBD — extract_columns_from_sql 결과가 들어갈 자리
    }


def save_screen_layer_draft(draft: dict) -> Path:
    """초안을 semantic_layer/screens/<screen_id>.yaml 로 저장한다.

    이미 파일이 있으면 사람이 검수한 내용을 덮어쓸 수 있으므로 저장하지 않는다.
    """
    screen_id = draft["screen_id"]
    path = SCREEN_LAYER_DIR / f"{screen_id}.yaml"

    if path.exists():
        raise FileExistsError(
            f"이미 존재합니다(검수본일 수 있음): {path}. 수동으로 비교 후 반영하세요."
        )

    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(draft, f, allow_unicode=True, sort_keys=False)

    return path
