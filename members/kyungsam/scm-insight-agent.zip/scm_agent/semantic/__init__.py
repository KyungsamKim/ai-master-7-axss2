"""Semantic Layer (2계층) 관련 모듈.

    loader.py       : 공통 + 화면별 YAML을 읽어 합친다 (런타임)
    builder_stub.py : 오프라인 빌더 (W6, 런타임과 분리된 별도 파이프라인)
"""
