"""
Semantic Layer 로더 — 공통 계층 + 화면별 계층을 읽어 합친다.

이 파일은 1단계 스켈레톤에서 "내용이 실제로 채워진" 몇 안 되는 모듈이다.
(YAML 안의 지표·제품속성 값 자체는 다음 주에 회사에서 채우지만,
 읽어서 합치는 로직은 지금 완성해 둔다.)

2계층 구조 (2주차 산출물 5장)
  - 공통 계층 : semantic_layer/common.yaml          — 전 화면 공통 어휘. 거의 불변
  - 화면별 계층 : semantic_layer/screens/<screen_id>.yaml — 화면마다 하나. 오프라인 빌더가 초안 생성

합치는 규칙
  1) 화면별 계층의 값이 공통 계층의 같은 키를 덮어쓴다 (화면이 더 구체적이므로).
  2) 컬럼 바인딩은 화면별 계층에만 있고, 그 안의 entity/semantic_role/unit 이름은
     공통 계층의 정의를 찾아 붙여 준다(= resolve). 뒤쪽 노드가 공통 계층을
     다시 뒤지지 않아도 되도록 한 번에 풀어 놓는 것이 목적이다.
  3) 화면별 계층 파일이 없으면 공통 계층만으로 degrade 한다 (부록 A.2 · 2번 노드).
"""

from pathlib import Path
from typing import Any, Optional

import yaml

from scm_agent.config import COMMON_LAYER_PATH, SCREEN_LAYER_DIR


def load_yaml_file(path: Path) -> dict:
    """YAML 파일 하나를 안전하게 읽어 dict로 돌려준다.

    파일이 없거나 비어 있으면 빈 dict를 준다(예외를 던지지 않는다).
    safe_load를 쓰는 이유: YAML의 임의 파이썬 객체 생성 기능을 막기 위해서다.
    """
    if not path.exists():
        return {}

    with open(path, "r", encoding="utf-8") as f:
        loaded = yaml.safe_load(f)

    if loaded is None:
        # 파일은 있는데 내용이 비어 있는 경우
        return {}
    if not isinstance(loaded, dict):
        # 최상위가 dict가 아니면(예: 리스트) 이 프로젝트 규약에 맞지 않는다.
        raise ValueError(f"Semantic Layer YAML의 최상위는 dict여야 합니다: {path}")
    return loaded


def merge_dict_deep(base: dict, override: dict) -> dict:
    """두 dict를 깊게 합친다. 같은 키가 있으면 override 쪽이 이긴다.

    값이 양쪽 모두 dict이면 한 단계 더 들어가 합치고,
    그 외(문자열·숫자·리스트)는 통째로 교체한다.
    리스트를 이어붙이지 않는 이유: 화면별 계층이 공통 목록을 '대체'하는 편이
    의미가 분명하고, 중복 제거 규칙 같은 숨은 동작이 생기지 않기 때문이다.
    """
    result = dict(base)  # 원본을 건드리지 않도록 복사본으로 시작

    for key in override:
        override_value = override[key]
        base_value = result.get(key)

        if isinstance(base_value, dict) and isinstance(override_value, dict):
            result[key] = merge_dict_deep(base_value, override_value)
        else:
            result[key] = override_value

    return result


def screen_layer_path(screen_id: str) -> Path:
    """screen_id로 화면별 계층 YAML 경로를 만든다."""
    return SCREEN_LAYER_DIR / f"{screen_id}.yaml"


def list_available_screens() -> list[str]:
    """화면별 계층이 준비된 screen_id 목록. (디버깅·안내 메시지용)"""
    if not SCREEN_LAYER_DIR.exists():
        return []

    screen_ids: list[str] = []
    for path in sorted(SCREEN_LAYER_DIR.glob("*.yaml")):
        screen_ids.append(path.stem)
    return screen_ids


def resolve_column_binding(
    column: dict,
    common_layer: dict,
) -> dict:
    """컬럼 바인딩 한 개에 공통 계층 정의를 붙여(resolve) 돌려준다.

    화면별 YAML의 컬럼은 이런 모습이다.
        - name: PLANT_CD
          label: 공장
          dtype: string
          semantic_role: dimension
          entity: Plant

    여기서 entity: Plant 는 공통 계층 entities.Plant 를 가리키는 '이름표'다.
    이 함수가 그 정의를 찾아 entity_def 로 붙여 준다.
    """
    resolved = dict(column)  # 원본 보존

    common_entities = common_layer.get("entities", {})
    common_roles = common_layer.get("semantic_roles", {})
    common_units = common_layer.get("units", {})

    entity_name = column.get("entity")
    if entity_name is not None:
        resolved["entity_def"] = common_entities.get(entity_name)

    role_name = column.get("semantic_role")
    if role_name is not None:
        resolved["semantic_role_def"] = common_roles.get(role_name)

    unit_name = column.get("unit")
    if unit_name is not None:
        resolved["unit_def"] = common_units.get(unit_name)

    return resolved


def resolve_semantic_context(screen_id: str) -> dict:
    """공통 계층 + 화면별 계층을 조합한 metadata 컨텍스트를 만든다.

    반환 dict의 주요 키
        screen_id      : 요청 화면 식별자
        screen_found   : 화면별 계층 파일을 찾았는지 (False면 degrade)
        degraded       : 공통 계층만으로 동작하는 상태인지
        purpose        : 화면 사용 목적 (템플릿 문장에 쓰인다)
        columns        : 공통 정의가 붙은 컬럼 바인딩 목록
        entities       : 공통 계층 업무 객체 사전
        semantic_roles : semantic_role 규약
        units          : 단위 관례
        terms          : 템플릿용 업무 용어
        sql_set        : 화면이 사용하는 SQL Set 참조
        source_files   : 실제로 읽은 파일 경로 (디버깅용)
    """
    common_layer = load_yaml_file(COMMON_LAYER_PATH)
    screen_path = screen_layer_path(screen_id)
    screen_layer = load_yaml_file(screen_path)

    screen_found = len(screen_layer) > 0

    # 1) 공통 계층 위에 화면별 계층을 덮어쓴다.
    merged = merge_dict_deep(common_layer, screen_layer)

    # 2) 컬럼 바인딩에 공통 정의를 붙인다.
    raw_columns = screen_layer.get("columns", [])
    resolved_columns: list[dict] = []
    for column in raw_columns:
        resolved_columns.append(resolve_column_binding(column, common_layer))

    # 3) 뒤 노드가 쓰기 쉬운 평평한(flat) 형태로 정리해 돌려준다.
    context = {
        "screen_id": screen_id,
        "screen_found": screen_found,
        "degraded": not screen_found,
        "purpose": screen_layer.get("purpose", ""),
        "description": screen_layer.get("description", ""),
        "columns": resolved_columns,
        "entities": merged.get("entities", {}),
        "semantic_roles": merged.get("semantic_roles", {}),
        "units": merged.get("units", {}),
        "terms": merged.get("terms", {}),
        "sql_set": screen_layer.get("sql_set", []),
        "source_files": {
            "common": str(COMMON_LAYER_PATH),
            "screen": str(screen_path) if screen_found else None,
        },
    }
    return context


def find_column_by_role(context: dict, role: str) -> Optional[dict]:
    """metadata 컨텍스트에서 semantic_role이 role인 첫 컬럼을 찾는다.

    예) find_column_by_role(metadata, "time") -> 시간축 컬럼
    없으면 None을 돌려준다.
    """
    columns = context.get("columns", [])
    for column in columns:
        if column.get("semantic_role") == role:
            return column
    return None


def find_columns_by_role(context: dict, role: str) -> list[dict]:
    """semantic_role이 role인 컬럼을 모두 찾는다."""
    columns = context.get("columns", [])
    matched: list[dict] = []
    for column in columns:
        if column.get("semantic_role") == role:
            matched.append(column)
    return matched


def get_column_label(context: dict, column_name: str) -> str:
    """컬럼의 한글 label을 찾는다. 없으면 컬럼명을 그대로 쓴다.

    템플릿 문장에서 'PLANT_CD' 대신 '공장'이라고 쓰기 위한 함수다.
    """
    columns = context.get("columns", [])
    for column in columns:
        if column.get("name") == column_name:
            label = column.get("label")
            if label:
                return str(label)
    return column_name
