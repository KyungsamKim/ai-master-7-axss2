"""
문장 템플릿 — present 노드가 쓰는 '문장 공장'

Constitution
  LLM은 사실을 생성하지 않는다. 문장은 템플릿이 옮긴다.
  따라서 사용자에게 보이는 모든 문장은 이 파일 안에 있다.
  템플릿에 들어가는 값은 compute_facts가 확정한 숫자뿐이며,
  여기서 새 숫자를 만들거나 원인을 추측하는 표현을 쓰면 안 된다.

[1단계 상태] 후보 종류별 기본 문장 4종.
[다음 할 일] 업무 용어(common.yaml terms)를 더 적극적으로 끌어 쓰고, 문장 다양화
"""


def format_number(value: float) -> str:
    """숫자를 천 단위 구분 기호가 있는 문자열로 바꾼다."""
    if value == int(value):
        return f"{int(value):,}"
    return f"{value:,.1f}"


def render_single_value(fact: dict, measure_label: str) -> str:
    """단일 값(합계) 문장."""
    total = fact["values"]["total"]
    return f"{measure_label} 합계는 {format_number(total)}입니다."


def render_trend(fact: dict, measure_label: str, time_label: str) -> str:
    """추세 문장. 방향 판단은 하지 않고 '몇 개 구간의 추이'라는 사실만 말한다."""
    point_count = fact["values"]["point_count"]
    return f"{time_label} 기준 {point_count}개 구간의 {measure_label} 추이입니다."


def render_period_change(fact: dict, measure_label: str, terms: dict) -> str:
    """기간 증감 문장. 증가/감소 판단은 compute_facts가 이미 확정한 값을 쓴다."""
    values = fact["values"]

    direction_word = terms.get(values["direction"], values["direction"])
    difference = abs(values["difference"])

    sentence = (
        f"{values['last_period']} {measure_label}은(는) "
        f"{format_number(values['last_value'])}로, "
        f"직전 기간({values['previous_period']}) 대비 "
        f"{format_number(difference)} {direction_word}했습니다"
    )

    change_rate = values.get("change_rate")
    if change_rate is not None:
        sentence = sentence + f" ({change_rate:+.1f}%)"

    return sentence + "."


def render_category_compare(
    fact: dict,
    measure_label: str,
    dimension_label: str,
) -> str:
    """범주 비교 문장."""
    values = fact["values"]

    sentence = (
        f"{dimension_label} {values['category_count']}개 중 "
        f"'{values['top_category']}'의 {measure_label}이(가) "
        f"{format_number(values['top_value'])}로 가장 큽니다"
    )

    top_share = values.get("top_share")
    if top_share is not None:
        sentence = sentence + f" (전체의 {top_share:.1f}%)"

    return sentence + "."


# 표준 안내 문구 (분석 결과가 없는 경우)
MESSAGE_EMPTY = "조회 결과가 없습니다."
MESSAGE_DETAIL_TABLE = "상세 목록 화면이라 표로만 제공합니다."
MESSAGE_NO_FACTS = "제시할 분석 결과가 없어 표로만 제공합니다."
MESSAGE_FATAL = "요청을 처리할 수 없습니다."
