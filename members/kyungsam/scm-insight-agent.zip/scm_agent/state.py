"""
State 스키마 정의 (2주차 산출물 부록 A.1 그대로)

LangGraph의 State는 "노드들이 돌아가며 조금씩 채워 나가는 하나의 사전(dict)"이다.
각 노드는 State 전체를 받고, 자기가 채운 필드만 담은 작은 dict를 반환한다.
LangGraph가 그 반환값을 원래 State에 덮어써 준다.

주의: TypedDict는 "타입 힌트"일 뿐 실행 중에 검사되지 않는다.
      읽는 사람이 어떤 필드가 있는지 한눈에 알게 하려는 목적이다.
"""

from typing import Any, Literal, Optional, TypedDict

# ---------------------------------------------------------------------------
# 부록 A.1에 정의된 값 집합들을 Literal 타입으로 고정한다.
# (오타로 엉뚱한 값이 들어가는 것을 편집기 단계에서 잡기 위함)
# ---------------------------------------------------------------------------

# 화면 구조 유형 — classify_screen_type 노드가 판정한다.
ScreenType = Literal[
    "time_series",  # 시간축이 있는 화면
    "category_compare",  # 시간축 없이 범주 비교
    "single_kpi",  # 단일 행 · 단일 지표
    "cross",  # 축이 2개 이상 (교차 분석)
    "detail_table",  # 식별자 위주 상세 목록 (집계 부적합)
    "empty",  # 행 수 0
]

# 후보를 만든 주체 — 나중에 rule/llm 성능을 나눠 측정하기 위해 남긴다.
PlannedBy = Literal["rule", "llm"]

# 최종 표현 방식 — present 노드가 결정한다.
OutputType = Literal["line", "bar", "kpi", "table", "empty"]


class AgentState(TypedDict, total=False):
    """대화형 SCM 데이터 분석 Agent의 전역 State.

    total=False 이므로 모든 필드가 선택 항목이다.
    파이프라인 앞쪽 노드는 뒤쪽 필드를 아직 채우지 않았기 때문이다.
    """

    # --- 입력 (ingest가 채운다) ---------------------------------------------
    screen_id: str  # 요청 화면 식별자. Semantic Layer 조회 키
    sql: str  # 실행된 MyBatis 쿼리 원문 (의미 보조 신호)
    raw_data: list[dict]  # 원본 결과 전체. 결정론적 레이어 전용, LLM에 넣지 않는다

    # --- 의미 계층 (resolve_semantic_layer가 채운다) ------------------------
    metadata: dict  # screen_id로 resolve된 (공통 + 화면별) 조합 컨텍스트

    # --- 분석 (profile ~ compute_facts) -------------------------------------
    profile: dict  # 통계 프로파일 · 집계값
    screen_type: ScreenType  # 화면 구조 유형
    candidates: list[dict]  # 분석 후보 (plan_analysis 산출)
    planned_by: PlannedBy  # 후보 생성 주체 (측정용)
    facts: list[dict]  # 구조화된 검증 사실 (compute_facts가 확정)

    # --- 표현 (present) ------------------------------------------------------
    output_type: OutputType  # 최종 표현 방식
    chart_spec: Optional[dict]  # 라이브러리 중립 차트 의도 스펙
    summary: Optional[str]  # 템플릿 렌더 문장 (LLM이 쓰지 않는다)
    # [2단계 추가] Vega-Lite MCP 호출 결과. MCP를 끄면 None이다.
    # A.1 표에는 없는 필드로, 연동 증적과 디버깅을 위해 둔다.
    chart_render: Optional[dict]

    # --- 공통 상태 -----------------------------------------------------------
    validation_errors: list[str]  # 스펙 검증 실패 기록
    degraded: bool  # degrade 경로 진입 여부
    response: dict  # 최종 조립 결과 (프론트 반환 페이로드)

    # --- 구현 보조 필드 (A.1 표에는 없지만 그래프 제어에 필요) --------------
    # 문서의 State 표는 "업무적으로 의미 있는 필드"만 담고 있다.
    # 아래 세 개는 조건부 엣지(A.5)를 돌리기 위한 내부 카운터/플래그다.
    fatal_error: Optional[str]  # ingest 단계 치명적 오류 (있으면 즉시 assemble)
    react_iterations: int  # llm_planner 자기 순환 횟수 (상한 R)
    need_more_react: bool  # True면 plan_analysis로 다시 돌아간다
    present_retries: int  # present 스펙 검증 재시도 횟수 (상한 1)
    present_ok: bool  # False면 present를 한 번 더 시도한다


def create_initial_state(payload: dict) -> AgentState:
    """백엔드 payload로 State 초기값을 만든다.

    ingest 노드가 실제 검증을 하지만, 그래프에 넣기 전에
    "빈 값이라도 모든 필드가 있는 상태"를 만들어 두면 뒤 노드가 훨씬 단순해진다.
    """
    state: AgentState = {
        "screen_id": payload.get("screen_id", ""),
        "sql": payload.get("sql", ""),
        "raw_data": payload.get("raw_data", []),
        "metadata": {},
        "profile": {},
        "candidates": [],
        "facts": [],
        "chart_spec": None,
        "chart_render": None,
        "summary": None,
        "validation_errors": [],
        "degraded": False,
        "response": {},
        "fatal_error": None,
        "react_iterations": 0,
        "need_more_react": False,
        "present_retries": 0,
        "present_ok": True,
    }
    return state
