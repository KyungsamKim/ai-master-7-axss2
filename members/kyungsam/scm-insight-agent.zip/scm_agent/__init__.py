"""대화형 SCM 데이터 분석 Agent — LangGraph 스켈레톤 (2주차 산출물 부록 A 기준)."""

__version__ = "0.1.0"
