"""
rule_planner — 유형별 고정 후보를 만드는 규칙 기반 플래너 (부록 A.2 · 5번 노드)

"분석 후보(candidate)"란 '무엇을 계산해 볼지'를 적은 작은 주문서다.
실제 계산은 절대 여기서 하지 않는다. 계산은 compute_facts가 한다.
(Constitution: 사실은 코드가 만든다 / plan은 '무엇을'만 정한다)

[1단계 상태] 유형별 고정 후보 목록을 만드는 스텁.
[다음 할 일] "전수 실행 후 상위 K 선정"에서 '전수 실행 → 점수화' 부분 구현
"""

from scm_agent.config import TOP_K_CANDIDATES


def make_candidate(
    candidate_id: str,
    kind: str,
    description: str,
    measure: str | None = None,
    dimension: str | None = None,
    time_column: str | None = None,
) -> dict:
    """후보 하나를 만든다. (모든 후보가 같은 모양을 갖게 하기 위한 도우미 함수)"""
    return {
        "id": candidate_id,
        "kind": kind,  # compute_facts가 이 값을 보고 계산 방법을 고른다
        "description": description,
        "measure": measure,
        "dimension": dimension,
        "time_column": time_column,
        "score": 0.0,  # [TBD] 전수 실행 후 유용성 점수를 넣을 자리
    }


def pick_first(names: list[str]) -> str | None:
    """목록에서 첫 항목을 꺼낸다. 비어 있으면 None."""
    if len(names) == 0:
        return None
    return names[0]


def plan_with_rules(
    screen_type: str,
    columns_by_role: dict[str, list[str]],
) -> list[dict]:
    """화면 유형에 맞는 고정 후보 목록을 만든다 (부록 A.3의 '분석 전략' 열)."""

    time_column = pick_first(columns_by_role.get("time", []))
    dimension_column = pick_first(columns_by_role.get("dimension", []))
    measure_column = pick_first(columns_by_role.get("measure", []))

    candidates: list[dict] = []

    if screen_type == "time_series":
        # 전략: 추세 · 기간 증감 · 기여도
        candidates.append(
            make_candidate(
                "ts_trend",
                "trend",
                "기간별 추세",
                measure=measure_column,
                time_column=time_column,
            )
        )
        candidates.append(
            make_candidate(
                "ts_period_change",
                "period_change",
                "직전 기간 대비 증감",
                measure=measure_column,
                time_column=time_column,
            )
        )
        if dimension_column is not None:
            candidates.append(
                make_candidate(
                    "ts_contribution",
                    "contribution",
                    "증감 기여도 상위",
                    measure=measure_column,
                    dimension=dimension_column,
                    time_column=time_column,
                )
            )

    elif screen_type == "category_compare":
        # 전략: 카테고리 비교 · 상위 기여
        candidates.append(
            make_candidate(
                "cat_compare",
                "category_compare",
                "범주별 비교",
                measure=measure_column,
                dimension=dimension_column,
            )
        )
        candidates.append(
            make_candidate(
                "cat_top_contribution",
                "contribution",
                "상위 기여 범주",
                measure=measure_column,
                dimension=dimension_column,
            )
        )

    elif screen_type == "single_kpi":
        # 전략: KPI 요약
        candidates.append(
            make_candidate(
                "kpi_value",
                "single_value",
                "KPI 값 요약",
                measure=measure_column,
            )
        )

    elif screen_type == "cross":
        # cross는 원래 llm_planner가 맡지만, LLM을 쓰지 않는 경우를 대비해
        # 축별 비교 후보를 규칙으로도 준비해 둔다 (degrade 대비).
        candidates.append(
            make_candidate(
                "cross_axis_compare",
                "category_compare",
                "축별 비교",
                measure=measure_column,
                dimension=dimension_column,
            )
        )

    # detail_table / empty 는 분석을 하지 않으므로 후보가 비어 있는 것이 정상이다.

    # 상위 K개만 남긴다 (지금은 점수가 모두 0이므로 앞에서부터 K개).
    return candidates[:TOP_K_CANDIDATES]


def make_default_candidates(columns_by_role: dict[str, list[str]]) -> list[dict]:
    """후보가 하나도 없을 때 쓰는 기본 후보 세트 (부록 A.2 · 5번 노드 실패 처리)."""
    measure_column = pick_first(columns_by_role.get("measure", []))

    if measure_column is None:
        # 수치 컬럼조차 없으면 진짜로 분석할 것이 없다. 표로 보여 주면 된다.
        return []

    return [
        make_candidate(
            "default_total",
            "single_value",
            "전체 합계 (기본 후보)",
            measure=measure_column,
        )
    ]
