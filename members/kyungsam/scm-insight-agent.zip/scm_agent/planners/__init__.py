"""분석 후보 플래너 모음 (plan_analysis 노드가 골라 쓴다).

    rule_planner : 유형별 고정 후보 (단순 유형)
    llm_planner  : ReAct 루프로 후보를 좁혀 감 (cross / 조합 수 임계 초과)
"""
