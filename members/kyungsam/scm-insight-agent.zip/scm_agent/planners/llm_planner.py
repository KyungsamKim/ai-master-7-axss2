"""
llm_planner — ReAct 루프로 분석 후보를 좁혀 가는 플래너 (부록 A.2 · 5번 노드 / A.5)

ReAct = Reason(제안) → Act(실행) → Observe(관찰) → 다시 Reason ... 를 상한 R회 반복.
이 프로젝트에서 ReAct는 '사실 생성'이 아니라 '무엇을 분석할지 고르는 일'에만 쓴다.
(2주차 산출물 4.3 — 사실 생성에 ReAct를 넣으면 Constitution이 무너진다)

루프의 '반복'은 이 파일 안의 for 문이 아니라 LangGraph 그래프의 자기 순환 엣지로 만든다.
따라서 이 함수는 "한 번의 반복(1 iteration)"만 수행하고 돌아간다.
그래야 매 반복이 State에 남고, LangGraph 스트림에서 눈으로 볼 수 있다.

[1단계 상태] LLM을 전혀 호출하지 않는 완전 스텁. 규칙 후보를 그대로 돌려준다.
[다음 할 일] W3에서 아래 3개 함수의 내부를 실제 LLM 호출로 교체
             - propose_candidates_with_llm : Reason (후보 제안)
             - observe_and_decide          : Observe (더 볼지 말지 판단)
"""

from scm_agent.config import REACT_MAX_ITERATIONS, TOP_K_CANDIDATES, USE_LLM
from scm_agent.planners.rule_planner import plan_with_rules


def build_llm_payload(profile: dict, metadata: dict) -> dict:
    """LLM에 넣을 페이로드를 만든다.

    Constitution: 원본 데이터(raw_data)는 절대 LLM에 넣지 않는다.
    프로파일 요약과 컬럼의 '의미'만 넣는다.
    """
    column_summaries: list[dict] = []
    for column in metadata.get("columns", []):
        column_summaries.append(
            {
                "name": column.get("name"),
                "label": column.get("label"),
                "semantic_role": column.get("semantic_role"),
                "unit": column.get("unit"),
            }
        )

    return {
        "purpose": metadata.get("purpose", ""),
        "columns": column_summaries,
        "row_count": profile.get("row_count", 0),
        # [TBD] 이전 반복의 관찰 결과(observation)를 여기 추가해 재탐색에 쓴다.
    }


def propose_candidates_with_llm(
    screen_type: str,
    columns_by_role: dict[str, list[str]],
    llm_payload: dict,
) -> list[dict]:
    """[Reason] LLM에게 분석 후보를 제안받는다.

    [1단계 스텁] LLM을 호출하지 않고 규칙 후보를 그대로 쓴다.
    이렇게 해 두면 API 키가 없어도 그래프가 처음부터 끝까지 돈다.
    """
    if USE_LLM:
        # [TBD] W3에서 구현
        #   1) 구조화 출력(Pydantic)으로 후보 목록을 받는다
        #   2) 후보의 measure/dimension 이 실제 컬럼인지 코드로 검증한다
        #   3) 검증에 실패한 후보는 버린다 (LLM이 없는 컬럼을 지어내지 못하게)
        raise NotImplementedError("W3에서 실제 LLM 호출을 붙인다")

    candidates = plan_with_rules(screen_type, columns_by_role)

    # 후보 출처를 표시해 둔다. 나중에 rule/llm 후보 품질을 나눠 측정하기 위함.
    marked: list[dict] = []
    for candidate in candidates:
        marked_candidate = dict(candidate)
        marked_candidate["origin"] = "llm_stub"
        marked.append(marked_candidate)

    return marked


def observe_and_decide(
    candidates: list[dict],
    iteration: int,
) -> bool:
    """[Observe] 한 번 더 탐색할지 결정한다. True면 재탐색(자기 순환).

    [1단계 스텁] 상한 R에만 의존하고, 후보가 하나라도 있으면 즉시 멈춘다.
    [다음 할 일] 실행 결과(빈 후보·낮은 점수)를 보고 재탐색 여부를 판단
    """
    if iteration >= REACT_MAX_ITERATIONS:
        return False  # 상한에 도달하면 무조건 멈춘다 (무한 루프 방지)
    if len(candidates) > 0:
        return False  # 쓸 만한 후보가 이미 있으면 더 돌지 않는다
    return True


def plan_with_llm(
    screen_type: str,
    columns_by_role: dict[str, list[str]],
    profile: dict,
    metadata: dict,
    iteration: int,
) -> dict:
    """ReAct 한 번의 반복을 수행한다.

    반환 dict
        candidates      : 이번 반복에서 얻은 후보 목록
        need_more_react : True면 그래프가 plan_analysis로 다시 돌아온다
        observation     : 이번 반복에서 관찰한 내용 (로그·디버깅용)
    """
    llm_payload = build_llm_payload(profile, metadata)

    candidates = propose_candidates_with_llm(screen_type, columns_by_role, llm_payload)
    candidates = candidates[:TOP_K_CANDIDATES]

    need_more_react = observe_and_decide(candidates, iteration)

    observation = (
        f"ReAct {iteration}회차: 후보 {len(candidates)}개 확보, "
        f"재탐색 {'필요' if need_more_react else '불필요'}"
    )

    return {
        "candidates": candidates,
        "need_more_react": need_more_react,
        "observation": observation,
    }
