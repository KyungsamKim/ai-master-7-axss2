"""
설정값 모음

부록 A.2 / A.3에 나온 임계값과 파일 경로를 한 곳에 모아 둔다.
"첫 화면에서 캘리브레이션"이라고 문서에 적힌 값들이므로,
나중에 튜닝할 때 이 파일만 열면 되도록 상수로 분리했다.
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# 경로
# ---------------------------------------------------------------------------

# 이 파일 기준 프로젝트 루트 (scm_agent/config.py -> scm_agent -> 프로젝트 루트)
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Semantic Layer YAML 위치
SEMANTIC_LAYER_DIR = PROJECT_ROOT / "semantic_layer"
COMMON_LAYER_PATH = SEMANTIC_LAYER_DIR / "common.yaml"
SCREEN_LAYER_DIR = SEMANTIC_LAYER_DIR / "screens"

# ---------------------------------------------------------------------------
# plan_analysis 임계값 (부록 A.2 · 5번 노드 "초기값" 행)
# ---------------------------------------------------------------------------

TOP_K_CANDIDATES = 3  # K: 후보 상위 몇 개를 남길지
REACT_MAX_ITERATIONS = 2  # R: llm_planner ReAct 자기 순환 상한
LLM_PLANNER_COMBINATION_THRESHOLD = 30  # 조합 수가 이 값을 넘으면 llm_planner로

# ---------------------------------------------------------------------------
# classify_screen_type 임계값 (부록 A.3)
# ---------------------------------------------------------------------------

# "저카디널리티 dimension"의 경계. 고유값이 이 값 이하이면 비교용 축으로 본다.
LOW_CARDINALITY_MAX = 20

# 고유값 비율이 이 값을 넘으면 식별자성 컬럼(=상세 표)으로 본다.
DETAIL_TABLE_UNIQUE_RATIO = 0.9

# ---------------------------------------------------------------------------
# present 설정
# ---------------------------------------------------------------------------

PRESENT_MAX_RETRIES = 1  # 스펙 검증 실패 시 재시도 횟수 (문서: 1회)

# ---------------------------------------------------------------------------
# LLM 사용 여부
# ---------------------------------------------------------------------------

# 1단계(스켈레톤)에서는 LLM을 전혀 호출하지 않는다.
# W3에서 실제 ReAct 루프를 붙일 때 True로 바꾸고 llm_planner 내부를 채운다.
USE_LLM = False

# ---------------------------------------------------------------------------
# Vega-Lite MCP 설정 (2단계)
# ---------------------------------------------------------------------------
# 2주차 산출물 6장: Vega-Lite MCP 채택 · text 모드 · stdio(서브프로세스) 전송
#
# 서버는 isaacwasserman/mcp-vegalite-server 를 쓴다. 설치 방법은 README 6장 참고.
#   pip install git+https://github.com/isaacwasserman/mcp-vegalite-server.git
# 설치하면 mcp_server_vegalite 실행 파일이 생긴다.

# present 노드가 MCP를 실제로 호출할지 여부.
#   False — 중립 스펙만 만들고 끝낸다 (MCP 서버가 없어도 파이프라인이 돈다)
#   True  — 중립 스펙을 Vega-Lite로 바꿔 MCP 서버에 넘긴다
# run_demo.py --mcp 로 실행하면 코드 수정 없이 True로 켤 수 있다.
USE_VEGALITE_MCP = False

# 서버 실행 명령 (stdio 전송이므로 클라이언트가 이 프로세스를 직접 띄운다)
VEGALITE_MCP_COMMAND = "mcp_server_vegalite"

# 출력 모드: "text" | "png"
#   text — Vega-Lite 스펙을 그대로 두고 처리 결과 메시지만 받는다 (2주차 확정)
#   png  — 서버가 vl-convert로 렌더한 PNG(base64)를 받는다 (연동 확인·증적용)
VEGALITE_MCP_OUTPUT_TYPE = "text"

# 주의: 실행 인자는 --output-type (하이픈)이다.
#       저장소 README에는 --output_type 으로 적혀 있으나 실제 argparse 정의는 하이픈이다.
VEGALITE_MCP_ARGS = ["--output-type", VEGALITE_MCP_OUTPUT_TYPE]

# 서버가 logs/mcp_vegalite_server.log 에 로그를 남긴다. 이 경로는 '실행 디렉터리 기준'
# 상대 경로라서, logs 폴더가 있는 프로젝트 루트에서 띄워야 서버가 뜬다.
VEGALITE_MCP_CWD = PROJECT_ROOT

# MCP 호출 전체 제한 시간(초). 넘으면 포기하고 중립 스펙만으로 응답한다.
VEGALITE_MCP_TIMEOUT_SECONDS = 30
