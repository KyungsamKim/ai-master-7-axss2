"""
LangGraph 그래프 조립 — 부록 A.2(노드) + A.5(조건부 엣지 · degrade)

흐름 (2주차 산출물 4.1 '현재 확정')
    ingest
      -> resolve_semantic_layer
      -> profile
      -> classify_screen_type
      -> plan_analysis (rule | llm_planner=ReAct 자기 순환)
      -> compute_facts
      -> present
      -> assemble

A.5 조건부 엣지
    classify_screen_type 3분기 — plan_analysis / present(표만) / assemble(empty)
    plan_analysis 2분기        — rule_planner / llm_planner  (분기 자체는 노드 안에서)
    llm_planner 자기 순환      — ReAct 재탐색 (상한 R)
    present 2분기              — 정상 / 스펙 실패 시 table degrade
    전 구간 예외               — 해당 시점에서 degrade, assemble은 항상 응답 반환

읽는 법
  - add_node   : 이름 <-> 함수를 등록한다
  - add_edge   : 항상 A 다음 B (무조건 이동)
  - add_conditional_edges : 함수가 돌려준 '다음 노드 이름'으로 이동 (분기)
"""

from langgraph.graph import END, START, StateGraph

from scm_agent.nodes import (
    assemble,
    classify_screen_type,
    compute_facts,
    ingest,
    plan_analysis,
    present,
    profile,
    resolve_semantic_layer,
)
from scm_agent.state import AgentState

# ---------------------------------------------------------------------------
# 라우팅 함수들 — State를 보고 '다음에 갈 노드 이름'을 문자열로 돌려준다.
# ---------------------------------------------------------------------------


def route_after_ingest(state: AgentState) -> str:
    """필수 필드가 없으면 분석을 건너뛰고 바로 응답 조립으로 간다."""
    if state.get("fatal_error"):
        print("      [분기] ingest 실패 → assemble")
        return "assemble"
    return "resolve_semantic_layer"


def route_after_classify(state: AgentState) -> str:
    """A.5 · classify_screen_type 3분기."""
    screen_type = state.get("screen_type", "detail_table")

    if screen_type == "empty":
        print("      [분기] empty → assemble")
        return "assemble"

    if screen_type == "detail_table":
        # 상세 목록 화면은 분석하지 않고 표만 보여 준다.
        print("      [분기] detail_table → present (표만)")
        return "present"

    return "plan_analysis"


def route_after_plan_analysis(state: AgentState) -> str:
    """A.5 · llm_planner 자기 순환 (ReAct 재탐색, 상한 R)."""
    if state.get("need_more_react", False):
        print("      [분기] ReAct 재탐색 → plan_analysis")
        return "plan_analysis"
    return "compute_facts"


def route_after_present(state: AgentState) -> str:
    """A.5 · present 2분기 (스펙 검증 실패 시 1회 재시도)."""
    if state.get("present_ok", True):
        return "assemble"
    print("      [분기] 스펙 검증 실패 → present 재시도")
    return "present"


# ---------------------------------------------------------------------------
# 그래프 조립
# ---------------------------------------------------------------------------


def build_graph():
    """8개 노드와 조건부 엣지를 붙여 실행 가능한 그래프를 만든다."""

    builder = StateGraph(AgentState)

    # --- 노드 등록 (부록 A.2의 8개) ----------------------------------------
    builder.add_node("ingest", ingest)
    builder.add_node("resolve_semantic_layer", resolve_semantic_layer)
    builder.add_node("profile", profile)
    builder.add_node("classify_screen_type", classify_screen_type)
    builder.add_node("plan_analysis", plan_analysis)
    builder.add_node("compute_facts", compute_facts)
    builder.add_node("present", present)
    builder.add_node("assemble", assemble)

    # --- 시작 ---------------------------------------------------------------
    builder.add_edge(START, "ingest")

    # --- ingest 이후: 치명적 오류면 바로 assemble ---------------------------
    builder.add_conditional_edges(
        "ingest",
        route_after_ingest,
        {
            "resolve_semantic_layer": "resolve_semantic_layer",
            "assemble": "assemble",
        },
    )

    # --- 무조건 이동 구간 ----------------------------------------------------
    builder.add_edge("resolve_semantic_layer", "profile")
    builder.add_edge("profile", "classify_screen_type")

    # --- classify 3분기 ------------------------------------------------------
    builder.add_conditional_edges(
        "classify_screen_type",
        route_after_classify,
        {
            "plan_analysis": "plan_analysis",
            "present": "present",
            "assemble": "assemble",
        },
    )

    # --- plan_analysis 자기 순환 (ReAct) ------------------------------------
    builder.add_conditional_edges(
        "plan_analysis",
        route_after_plan_analysis,
        {
            "plan_analysis": "plan_analysis",
            "compute_facts": "compute_facts",
        },
    )

    builder.add_edge("compute_facts", "present")

    # --- present 2분기 (재시도 자기 순환) -----------------------------------
    builder.add_conditional_edges(
        "present",
        route_after_present,
        {
            "present": "present",
            "assemble": "assemble",
        },
    )

    # --- 끝 -----------------------------------------------------------------
    builder.add_edge("assemble", END)

    return builder.compile()


def run_pipeline(payload: dict) -> dict:
    """payload 하나를 그래프에 흘려 최종 응답을 받는다.

    이 함수가 백엔드에서 부를 진입점이다.
    """
    from scm_agent.state import create_initial_state

    graph = build_graph()
    initial_state = create_initial_state(payload)
    final_state = graph.invoke(initial_state)
    return final_state.get("response", {})
