"""
노드 8. assemble  [결정론적]  — 부록 A.2

입력  : summary, chart_spec, output_type, degraded
처리  : 최종 응답 조립. empty·오류·degrade 케이스 메시지 포함
출력  : response
실패  : 없음 — 항상 응답을 반환한다

이 노드는 절대 예외를 던지면 안 된다. 앞에서 무슨 일이 있었든
프론트가 화면에 뿌릴 수 있는 응답을 하나 만들어 내는 것이 유일한 책임이다.

[1단계 상태] 응답 조립 완료.
[다음 할 일] 프론트와 확정한 실제 페이로드 스키마로 맞추기
"""

from scm_agent import templates
from scm_agent.state import AgentState


def summarize_chart_render(chart_render: dict | None) -> dict | None:
    """[2단계] MCP 호출 결과를 응답에 담기 좋게 줄인다.

    png 모드의 이미지(base64)는 매우 길어서 그대로 응답에 넣으면 로그가 읽기 어려워진다.
    길이만 남기고, 이미지가 필요하면 State의 chart_render에서 직접 꺼내 쓴다.
    """
    if chart_render is None:
        return None

    image_base64 = chart_render.get("image_base64")
    if image_base64 is None:
        image_length = 0
    else:
        image_length = len(image_base64)

    return {
        "mcp_used": chart_render.get("mcp_used", False),
        "ok": chart_render.get("ok", False),
        "output_type": chart_render.get("output_type"),
        "message": chart_render.get("visualize_message"),
        "image_base64_length": image_length,
        "error": chart_render.get("error"),
    }


def assemble(state: AgentState) -> dict:
    """최종 응답 페이로드를 만든다."""

    print("[8/8] assemble 실행")

    fatal_error = state.get("fatal_error")

    # --- 치명적 오류 (ingest에서 바로 넘어온 경우) ---------------------------
    if fatal_error:
        response = {
            "status": "error",
            "screen_id": state.get("screen_id", ""),
            "output_type": "empty",
            "summary": templates.MESSAGE_FATAL,
            "chart_spec": None,
            "message": fatal_error,
            "degraded": True,
        }
        print("      -> status=error")
        return {"response": response}

    degraded = state.get("degraded", False)
    validation_errors = state.get("validation_errors", [])

    if degraded:
        status = "degraded"
    else:
        status = "ok"

    output_type = state.get("output_type", "empty")

    # empty 케이스는 present를 거치지 않고 바로 여기로 오므로(A.5) 안내 문구를 여기서 넣는다.
    summary = state.get("summary")
    if summary is None and output_type == "empty":
        summary = templates.MESSAGE_EMPTY

    response = {
        "status": status,
        "screen_id": state.get("screen_id", ""),
        "screen_type": state.get("screen_type"),
        "output_type": output_type,
        "summary": summary,
        "chart_spec": state.get("chart_spec"),
        "chart_render": summarize_chart_render(state.get("chart_render")),
        "degraded": degraded,
        # 측정·디버깅용 부가 정보 (프론트는 무시해도 된다)
        "meta": {
            "planned_by": state.get("planned_by"),
            "candidate_count": len(state.get("candidates", [])),
            "fact_count": len(state.get("facts", [])),
            "react_iterations": state.get("react_iterations", 0),
            "validation_errors": validation_errors,
        },
    }

    print(f"      -> status={status}, output_type={response['output_type']}")
    return {"response": response}
