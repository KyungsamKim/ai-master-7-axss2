"""
노드 3. profile  [결정론적 · pandas]  — 부록 A.2

입력  : raw_data, metadata
처리  : 컬럼 타입별 통계(전체·수치형·범주형·시계열) + 차트 시리즈용 집계값 사전 계산
출력  : profile
실패  : 산출 불가 컬럼은 스킵·경고 기록 (전체 실패가 아니다)

[1단계 상태] 유형 판정(classify)에 필요한 최소 통계까지만 계산하는 스텁.
[다음 할 일] 결측률·이상치·기간 커버리지·차트 시리즈용 사전 집계 추가
"""

import pandas as pd

from scm_agent.state import AgentState


def profile(state: AgentState) -> dict:
    """raw_data를 pandas DataFrame으로 만들어 기본 통계를 낸다."""

    print("[3/8] profile 실행")

    raw_data = state.get("raw_data", [])
    metadata = state.get("metadata", {})

    row_count = len(raw_data)

    # 행이 없으면 통계를 낼 것이 없다. 뒤에서 empty로 판정된다.
    if row_count == 0:
        print("      -> 행 수 0. 통계 생략")
        return {"profile": {"row_count": 0, "columns": {}, "warnings": []}}

    frame = pd.DataFrame(raw_data)

    # metadata의 컬럼 바인딩을 "컬럼명 -> semantic_role" 사전으로 미리 바꿔 둔다.
    role_by_column: dict[str, str] = {}
    for column in metadata.get("columns", []):
        column_name = column.get("name")
        role = column.get("semantic_role")
        if column_name is not None and role is not None:
            role_by_column[column_name] = role

    column_stats: dict[str, dict] = {}
    warnings: list[str] = []

    for column_name in frame.columns:
        series = frame[column_name]

        # 컬럼 하나가 실패해도 전체가 죽지 않도록 각각 감싼다.
        try:
            stats: dict = {
                "semantic_role": role_by_column.get(column_name, "unknown"),
                "pandas_dtype": str(series.dtype),
                "null_count": int(series.isna().sum()),
                "unique_count": int(series.nunique(dropna=True)),
            }

            # 고유값 비율 — 식별자성 컬럼(상세 표) 판정에 쓰인다.
            stats["unique_ratio"] = round(stats["unique_count"] / row_count, 4)

            # 수치형이면 기본 통계를 추가한다.
            if pd.api.types.is_numeric_dtype(series):
                stats["is_numeric"] = True
                stats["sum"] = float(series.sum())
                stats["mean"] = float(series.mean())
                stats["min"] = float(series.min())
                stats["max"] = float(series.max())
            else:
                stats["is_numeric"] = False
                # 범주형이면 상위 값 몇 개를 남긴다(비교 분석 후보의 재료).
                top_values = series.value_counts().head(5)
                stats["top_values"] = {
                    str(key): int(value) for key, value in top_values.items()
                }

            column_stats[column_name] = stats

        except Exception as error:  # 노드 전체를 실패시키지 않는다
            warnings.append(f"{column_name} 통계 산출 실패: {error}")

    result_profile = {
        "row_count": row_count,
        "column_count": len(frame.columns),
        "columns": column_stats,
        "warnings": warnings,
        # [TBD] 차트 시리즈용 사전 집계는 다음 단계에서 여기에 추가한다.
        "series": {},
    }

    print(
        f"      -> 행 {row_count}건 / 컬럼 {len(frame.columns)}개 통계 완료"
        + (f" (경고 {len(warnings)}건)" if warnings else "")
    )

    return {"profile": result_profile}
