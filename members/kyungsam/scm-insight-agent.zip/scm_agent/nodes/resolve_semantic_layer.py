"""
노드 2. resolve_semantic_layer  [결정론적 · W5 Retrieval]  — 부록 A.2

입력  : screen_id
처리  : 공통 계층 + 화면별 계층을 로드해 조합
        (첫 구현은 screen_id로 YAML 로드, W5에서 검색 기반으로 확장)
출력  : metadata (조합 컨텍스트)
실패  : 화면별 계층 부재 시 공통 계층만으로 degrade (분석 범위 축소)

[1단계 상태] 조합 로직은 완성. YAML 내용(지표·제품속성)만 [TBD]
[다음 할 일] W5에서 screen_id 완전 일치 대신 유사 화면 검색으로 확장
"""

from scm_agent.semantic.loader import list_available_screens, resolve_semantic_context
from scm_agent.state import AgentState


def resolve_semantic_layer(state: AgentState) -> dict:
    """screen_id로 Semantic Layer 2계층을 조합해 metadata를 만든다."""

    print("[2/8] resolve_semantic_layer 실행")

    screen_id = state.get("screen_id", "")

    # 로더가 공통 계층 + 화면별 계층을 읽어 하나의 컨텍스트로 합쳐 준다.
    metadata = resolve_semantic_context(screen_id)

    column_count = len(metadata.get("columns", []))

    if metadata.get("screen_found"):
        print(f"      -> 화면별 계층 로드 완료 (컬럼 바인딩 {column_count}개)")
        return {"metadata": metadata}

    # --- degrade: 화면별 계층이 없다 -----------------------------------------
    # 공통 계층만으로도 파이프라인은 끝까지 돈다. 다만 분석 범위가 좁아진다.
    available = list_available_screens()
    print(
        f"      -> [degrade] '{screen_id}' 화면별 계층 없음. 공통 계층만 사용. "
        f"(준비된 화면: {available})"
    )

    validation_errors = list(state.get("validation_errors", []))
    validation_errors.append(f"화면별 Semantic Layer 없음: {screen_id}")

    return {
        "metadata": metadata,
        "degraded": True,
        "validation_errors": validation_errors,
    }
