"""
노드 4. classify_screen_type  [규칙 라우터 · 분기]  — 부록 A.2 / A.3

입력  : profile, metadata(semantic_role)
처리  : 구조 유형 판정 후 유형별 분석 전략으로 분기
출력  : screen_type
실패  : 규칙 충돌·불명확 시 detail_table로 안전 fallback

부록 A.3 판정 규칙
    empty            행 수 = 0
    single_kpi       단일 행 · 단일 measure
    cross            time + dimension >= 2, 또는 dimension >= 2 + measure
    time_series      time 컬럼 존재 · measure >= 1
    category_compare time 없음 · 저카디널리티 dimension · measure >= 1
    detail_table     고카디널리티 · 식별자 위주 (집계 부적합)

※ 판정 순서가 중요하다. 조건이 겹치는 유형이 있으므로
  "더 구체적인 유형"을 먼저 검사한다 (cross를 time_series보다 먼저).

[1단계 상태] 규칙 판정은 실제로 동작한다. 임계값은 첫 대상 화면에서 캘리브레이션 예정.
[다음 할 일] 오분류 실측 후 재판정 루프 검토 (2주차 산출물 8장 열린 질문)
"""

from scm_agent.config import DETAIL_TABLE_UNIQUE_RATIO, LOW_CARDINALITY_MAX
from scm_agent.state import AgentState


def collect_columns_by_role(state: AgentState) -> dict[str, list[str]]:
    """profile을 훑어 semantic_role 별 컬럼명 목록을 만든다.

    반환 예) {"time": ["YM"], "dimension": ["PLANT_CD"], "measure": ["ORDER_QTY"]}
    """
    columns_by_role: dict[str, list[str]] = {
        "time": [],
        "dimension": [],
        "measure": [],
        "identifier": [],
        "attribute": [],
        "unknown": [],
    }

    column_stats = state.get("profile", {}).get("columns", {})
    for column_name in column_stats:
        role = column_stats[column_name].get("semantic_role", "unknown")
        if role not in columns_by_role:
            columns_by_role[role] = []
        columns_by_role[role].append(column_name)

    return columns_by_role


def find_low_cardinality_dimensions(
    state: AgentState,
    dimension_columns: list[str],
) -> list[str]:
    """고유값이 적어 '비교축'으로 쓸 만한 dimension만 골라낸다."""
    column_stats = state.get("profile", {}).get("columns", {})

    low_cardinality: list[str] = []
    for column_name in dimension_columns:
        unique_count = column_stats.get(column_name, {}).get("unique_count", 0)
        if unique_count <= LOW_CARDINALITY_MAX:
            low_cardinality.append(column_name)

    return low_cardinality


def looks_like_detail_table(state: AgentState) -> bool:
    """식별자 위주 · 고카디널리티 화면인지 본다."""
    profile_data = state.get("profile", {})
    column_stats = profile_data.get("columns", {})

    for column_name in column_stats:
        stats = column_stats[column_name]
        role = stats.get("semantic_role")
        unique_ratio = stats.get("unique_ratio", 0)

        # 식별자 role이 명시되어 있거나, 사실상 행마다 값이 다른 컬럼이 있으면
        # 집계보다는 상세 목록 화면으로 본다.
        if role == "identifier":
            return True
        if unique_ratio >= DETAIL_TABLE_UNIQUE_RATIO and not stats.get("is_numeric"):
            return True

    return False


def classify_screen_type(state: AgentState) -> dict:
    """화면 구조 유형을 판정한다."""

    print("[4/8] classify_screen_type 실행")

    row_count = state.get("profile", {}).get("row_count", 0)

    # --- 1) empty -----------------------------------------------------------
    if row_count == 0:
        print("      -> screen_type=empty (행 수 0)")
        return {"screen_type": "empty"}

    columns_by_role = collect_columns_by_role(state)
    time_columns = columns_by_role["time"]
    dimension_columns = columns_by_role["dimension"]
    measure_columns = columns_by_role["measure"]

    low_cardinality_dimensions = find_low_cardinality_dimensions(
        state, dimension_columns
    )

    # --- 2) single_kpi ------------------------------------------------------
    if row_count == 1 and len(measure_columns) == 1:
        print("      -> screen_type=single_kpi (단일 행 · 단일 measure)")
        return {"screen_type": "single_kpi"}

    # --- 3) cross (더 구체적인 조건이므로 time_series보다 먼저 검사) --------
    has_time_and_two_dimensions = len(time_columns) >= 1 and len(dimension_columns) >= 2
    has_two_dimensions_and_measure = (
        len(dimension_columns) >= 2 and len(measure_columns) >= 1
    )
    if has_time_and_two_dimensions or has_two_dimensions_and_measure:
        print("      -> screen_type=cross (축 2개 이상)")
        return {"screen_type": "cross"}

    # --- 4) time_series -----------------------------------------------------
    if len(time_columns) >= 1 and len(measure_columns) >= 1:
        print("      -> screen_type=time_series (시간축 존재)")
        return {"screen_type": "time_series"}

    # --- 5) category_compare ------------------------------------------------
    if (
        len(time_columns) == 0
        and len(low_cardinality_dimensions) >= 1
        and len(measure_columns) >= 1
    ):
        print("      -> screen_type=category_compare (저카디널리티 범주 비교)")
        return {"screen_type": "category_compare"}

    # --- 6) detail_table / 안전 fallback ------------------------------------
    if looks_like_detail_table(state):
        print("      -> screen_type=detail_table (식별자 위주)")
    else:
        print("      -> screen_type=detail_table (규칙 불명확 → 안전 fallback)")

    return {"screen_type": "detail_table"}
