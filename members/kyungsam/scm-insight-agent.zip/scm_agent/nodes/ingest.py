"""
노드 1. ingest  [결정론적]  — 부록 A.2

입력  : 백엔드 payload (screen_id, sql, raw_data)
처리  : State 초기화, 필수 필드 확인, 행 수 0 여부 플래그
출력  : screen_id, sql, raw_data
실패  : 필수 필드 누락 시 오류 응답으로 즉시 assemble 패스

[1단계 상태] 필수 필드 검증까지는 실제로 동작한다.
[다음 할 일] 민감 컬럼 마스킹(Constitution)과 payload 스키마 검증(Pydantic) 추가
"""

from scm_agent.state import AgentState


def ingest(state: AgentState) -> dict:
    """백엔드에서 넘어온 payload를 확인하고 State를 준비한다."""

    print("[1/8] ingest 실행")

    screen_id = state.get("screen_id", "")
    raw_data = state.get("raw_data", [])

    # --- 필수 필드 확인 ------------------------------------------------------
    missing_fields: list[str] = []
    if not screen_id:
        missing_fields.append("screen_id")
    if raw_data is None:
        missing_fields.append("raw_data")

    if missing_fields:
        # 치명적 오류: 뒤 노드가 할 일이 없으므로 바로 assemble로 보낸다.
        message = "필수 필드 누락: " + ", ".join(missing_fields)
        print("      -> 치명적 오류:", message)
        return {
            "fatal_error": message,
            "degraded": True,
            "screen_type": "empty",
        }

    # --- 행 수 0 여부 플래그 -------------------------------------------------
    row_count = len(raw_data)
    print(f"      -> screen_id={screen_id}, 행 수={row_count}")

    # 행이 0건이면 뒤에서 classify가 empty로 판정하도록 profile에 미리 남긴다.
    return {
        "screen_id": screen_id,
        "sql": state.get("sql", ""),
        "raw_data": raw_data,
        "profile": {"row_count": row_count},
        "fatal_error": None,
    }
