"""
노드 7. present  [결정론적 · 표현 결정 (파이프라인 마지막)]  — 부록 A.2 / A.4

입력  : facts, screen_type, metadata
처리  : (a) facts의 shape로 차트 타입 결정 → 중립 스펙 조립 후 Pydantic 검증
        (b) 템플릿에 검증된 사실만 주입해 문장 렌더 (새 수치·인과 금지)
출력  : output_type, chart_spec, summary
실패  : 스펙 검증 실패 시 1회 재시도 → 재실패 시 table degrade

부록 A.4 차트 타입 규칙
    시계열 추세                       -> line
    카테고리 비교 · 기여도            -> bar
    단일 스칼라                       -> kpi
    detail_table 유형 또는 스펙 검증 실패 -> table
    행 수 0                           -> empty (메시지)

※ '표현 결정'이 파이프라인 마지막에 오는 것이 1주차 대비 가장 큰 변경점이다.
  무엇을 분석했는지(facts) 정해진 뒤에야 어떻게 그릴지 정한다.

[1단계 상태] 규칙 판정 + 스펙 조립 + 템플릿 렌더까지 동작.
[다음 할 일] W7에서 표현 개선 루프(생성된 차트를 관찰→보완) 검토
"""

from pydantic import ValidationError

from scm_agent import config, templates
from scm_agent.chart.spec import AxisSpec, ChartSpec, DataPoint
from scm_agent.chart.vegalite_adapter import call_vegalite_mcp
from scm_agent.config import PRESENT_MAX_RETRIES
from scm_agent.semantic.loader import get_column_label
from scm_agent.state import AgentState

# fact 종류 -> 차트 타입 (부록 A.4)
CHART_TYPE_BY_FACT_KIND = {
    "trend": "line",
    "category_compare": "bar",
    "contribution": "bar",
    "single_value": "kpi",
    "period_change": "kpi",
}


def choose_primary_fact(facts: list[dict], skip_count: int) -> dict | None:
    """차트로 그릴 대표 사실을 고른다.

    skip_count : 재시도 시 앞의 실패한 사실을 건너뛰기 위한 개수.
                 (같은 스펙으로 그대로 재시도하면 또 같은 이유로 실패하므로)
    """
    # 차트로 그릴 수 있는 사실만 남긴다.
    drawable: list[dict] = []
    for fact in facts:
        if fact.get("kind") in CHART_TYPE_BY_FACT_KIND:
            drawable.append(fact)

    if skip_count >= len(drawable):
        return None
    return drawable[skip_count]


def build_chart_spec(fact: dict, metadata: dict) -> ChartSpec:
    """대표 사실로 중립 차트 스펙을 조립한다. 형식이 틀리면 여기서 예외가 난다."""

    chart_type = CHART_TYPE_BY_FACT_KIND[fact["kind"]]

    measure_name = fact.get("measure") or ""
    measure_label = get_column_label(metadata, measure_name)

    # x축은 시계열이면 시간 컬럼, 범주 비교면 dimension 컬럼이다.
    if fact.get("time_column"):
        x_name = fact["time_column"]
    elif fact.get("dimension"):
        x_name = fact["dimension"]
    else:
        x_name = ""

    x_label = get_column_label(metadata, x_name) if x_name else ""

    data_points: list[DataPoint] = []
    for point in fact.get("series", []):
        data_points.append(DataPoint(x=point["x"], y=point["y"]))

    title = metadata.get("purpose") or "분석 결과"

    # KPI는 점이 아니라 값 하나만 필요하다.
    if chart_type == "kpi":
        values = fact.get("values", {})
        kpi_value = values.get("total", values.get("last_value"))
        return ChartSpec(
            chart_type="kpi",
            title=title,
            y_axis=AxisSpec(field=measure_name, label=measure_label),
            value=kpi_value,
        )

    return ChartSpec(
        chart_type=chart_type,
        title=title,
        x_axis=AxisSpec(field=x_name, label=x_label),
        y_axis=AxisSpec(field=measure_name, label=measure_label),
        data=data_points,
    )


def render_summary(facts: list[dict], metadata: dict) -> str:
    """검증된 사실만 템플릿에 주입해 문장을 만든다. 새 숫자·인과는 만들지 않는다."""

    terms = metadata.get("terms", {})
    sentences: list[str] = []

    for fact in facts:
        kind = fact.get("kind")
        measure_label = get_column_label(metadata, fact.get("measure") or "")

        if kind == "single_value":
            sentences.append(templates.render_single_value(fact, measure_label))

        elif kind == "trend":
            time_label = get_column_label(metadata, fact.get("time_column") or "")
            sentences.append(
                templates.render_trend(fact, measure_label, time_label)
            )

        elif kind == "period_change":
            sentences.append(
                templates.render_period_change(fact, measure_label, terms)
            )

        elif kind in ("category_compare", "contribution"):
            dimension_label = get_column_label(metadata, fact.get("dimension") or "")
            sentences.append(
                templates.render_category_compare(fact, measure_label, dimension_label)
            )

    return " ".join(sentences)


def present(state: AgentState) -> dict:
    """차트 타입과 문장을 결정한다."""

    retry_count = state.get("present_retries", 0)
    if retry_count == 0:
        print("[7/8] present 실행")
    else:
        print(f"[7/8] present 재시도 ({retry_count}회차)")

    screen_type = state.get("screen_type", "detail_table")
    facts = state.get("facts", [])
    metadata = state.get("metadata", {})
    validation_errors = list(state.get("validation_errors", []))

    # --- 분석 결과가 없는 경우들 -------------------------------------------
    if screen_type == "empty":
        print("      -> output_type=empty")
        return {
            "output_type": "empty",
            "chart_spec": None,
            "summary": templates.MESSAGE_EMPTY,
            "present_ok": True,
        }

    if screen_type == "detail_table":
        print("      -> output_type=table (상세 목록 화면)")
        return {
            "output_type": "table",
            "chart_spec": None,
            "summary": templates.MESSAGE_DETAIL_TABLE,
            "present_ok": True,
        }

    if len(facts) == 0:
        print("      -> [degrade] 사실 없음 → output_type=table")
        return {
            "output_type": "table",
            "chart_spec": None,
            "summary": templates.MESSAGE_NO_FACTS,
            "present_ok": True,
            "degraded": True,
        }

    # --- (a) 차트 타입 결정 + 중립 스펙 조립 + 검증 -------------------------
    primary_fact = choose_primary_fact(facts, retry_count)

    if primary_fact is None:
        print("      -> [degrade] 그릴 수 있는 사실 없음 → output_type=table")
        return {
            "output_type": "table",
            "chart_spec": None,
            "summary": render_summary(facts, metadata),
            "present_ok": True,
            "degraded": True,
        }

    try:
        chart_spec = build_chart_spec(primary_fact, metadata)
    except (ValidationError, ValueError, KeyError) as error:
        # 검증 실패: 재시도 여지가 있으면 그래프가 present로 다시 보낸다.
        validation_errors.append(f"차트 스펙 검증 실패({primary_fact.get('id')}): {error}")

        if retry_count < PRESENT_MAX_RETRIES:
            print("      -> 스펙 검증 실패. 다른 사실로 1회 재시도")
            return {
                "present_ok": False,
                "present_retries": retry_count + 1,
                "validation_errors": validation_errors,
            }

        print("      -> [degrade] 재시도 실패 → output_type=table")
        return {
            "output_type": "table",
            "chart_spec": None,
            "summary": render_summary(facts, metadata),
            "present_ok": True,
            "degraded": True,
            "validation_errors": validation_errors,
        }

    # --- (b) 템플릿 문장 렌더 -----------------------------------------------
    summary = render_summary(facts, metadata)

    print(f"      -> output_type={chart_spec.chart_type}, 문장 {len(summary)}자")

    # --- (c) [2단계] Vega-Lite MCP 호출 -------------------------------------
    # config를 모듈째로 import 한 이유: run_demo.py --mcp 처럼 실행 중에
    # config.USE_VEGALITE_MCP 값을 바꿔 켤 수 있게 하기 위해서다.
    # (from config import USE_VEGALITE_MCP 로 값을 복사해 오면 바꿔도 반영되지 않는다)
    chart_render = None
    degraded = state.get("degraded", False)

    if config.USE_VEGALITE_MCP and chart_spec.chart_type in ("line", "bar"):
        print("      -> Vega-Lite MCP 호출")
        chart_render = call_vegalite_mcp(chart_spec)

        if chart_render.get("ok"):
            print(f"         MCP 응답: {chart_render.get('visualize_message')}")
        else:
            # MCP가 실패해도 중립 스펙은 이미 만들어져 있으므로 응답은 나간다(장애 격리).
            print(f"         [degrade] MCP 실패: {chart_render.get('error')}")
            validation_errors.append(f"Vega-Lite MCP 실패: {chart_render.get('error')}")
            degraded = True

    return {
        "output_type": chart_spec.chart_type,
        "chart_spec": chart_spec.model_dump(),
        "chart_render": chart_render,
        "summary": summary,
        "present_ok": True,
        "degraded": degraded,
        "validation_errors": validation_errors,
    }
