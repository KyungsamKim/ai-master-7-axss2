"""
노드 5. plan_analysis  [분기 (rule | LLM)]  — 부록 A.2 / A.5

입력  : screen_type, profile, metadata
처리  : rule_planner  — 단순 유형에서 유형별 고정 후보를 전수 실행 후 상위 K 선정
        llm_planner   — cross 또는 조합 수 임계 초과 시 제안→실행→관찰→좁힘을 상한 R회 반복
출력  : candidates, planned_by
실패  : 후보 없음 시 기본 후보 세트로 degrade
초기값: K=3, R=2, 임계=조합 30

이 노드는 '무엇을 분석할지'만 정한다. 실제 계산은 다음 노드(compute_facts)가 한다.

[1단계 상태] 분기 판단과 후보 생성 골격까지 동작. LLM 호출은 스텁.
[다음 할 일] W3에서 llm_planner 내부를 실제 ReAct로 교체
"""

from scm_agent.config import LLM_PLANNER_COMBINATION_THRESHOLD
from scm_agent.nodes.classify_screen_type import collect_columns_by_role
from scm_agent.planners.llm_planner import plan_with_llm
from scm_agent.planners.rule_planner import make_default_candidates, plan_with_rules
from scm_agent.state import AgentState


def count_combinations(columns_by_role: dict[str, list[str]]) -> int:
    """분석 조합 수를 대략 센다.

    (dimension 개수 + time 개수) x measure 개수 를 조합 수로 본다.
    이 값이 임계(기본 30)를 넘으면 규칙으로 전수 탐색하기 버거우므로
    llm_planner에게 '어디를 볼지' 고르게 한다.
    """
    axis_count = len(columns_by_role.get("dimension", [])) + len(
        columns_by_role.get("time", [])
    )
    measure_count = len(columns_by_role.get("measure", []))
    return axis_count * measure_count


def should_use_llm_planner(
    screen_type: str,
    columns_by_role: dict[str, list[str]],
) -> bool:
    """rule_planner와 llm_planner 중 무엇을 쓸지 정한다 (A.5 · plan_analysis 2분기)."""
    if screen_type == "cross":
        return True
    if count_combinations(columns_by_role) > LLM_PLANNER_COMBINATION_THRESHOLD:
        return True
    return False


def plan_analysis(state: AgentState) -> dict:
    """분석 후보를 만든다. llm 분기일 때는 ReAct 한 반복만 수행하고 돌아간다."""

    iteration = state.get("react_iterations", 0)
    if iteration == 0:
        print("[5/8] plan_analysis 실행")
    else:
        print(f"[5/8] plan_analysis 재실행 (ReAct {iteration}회차)")

    screen_type = state.get("screen_type", "detail_table")
    profile_data = state.get("profile", {})
    metadata = state.get("metadata", {})

    columns_by_role = collect_columns_by_role(state)

    # --- 분기 1: llm_planner (ReAct) ----------------------------------------
    if should_use_llm_planner(screen_type, columns_by_role):
        react_result = plan_with_llm(
            screen_type=screen_type,
            columns_by_role=columns_by_role,
            profile=profile_data,
            metadata=metadata,
            iteration=iteration,
        )
        candidates = react_result["candidates"]
        print("      -> planner=llm |", react_result["observation"])

        return {
            "candidates": candidates,
            "planned_by": "llm",
            # 자기 순환 여부는 graph.py의 조건부 엣지가 이 두 값을 보고 판단한다.
            "react_iterations": iteration + 1,
            "need_more_react": react_result["need_more_react"],
        }

    # --- 분기 2: rule_planner ------------------------------------------------
    candidates = plan_with_rules(screen_type, columns_by_role)

    # 후보가 하나도 없으면 기본 후보 세트로 degrade 한다.
    degraded = state.get("degraded", False)
    if len(candidates) == 0:
        candidates = make_default_candidates(columns_by_role)
        if len(candidates) > 0:
            degraded = True
            print("      -> [degrade] 후보 없음 → 기본 후보 세트 사용")

    print(f"      -> planner=rule | 후보 {len(candidates)}개")

    return {
        "candidates": candidates,
        "planned_by": "rule",
        "degraded": degraded,
        "need_more_react": False,
    }
