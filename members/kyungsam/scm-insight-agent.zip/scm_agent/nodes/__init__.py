"""
노드 모음

부록 A.2의 8개 노드를 각각 별도 파일로 두었다.
매주 한 노드씩 살을 붙일 예정이므로, 파일 하나만 열어 고치면 되도록 분리했다.

    1. ingest                  ingest.py
    2. resolve_semantic_layer  resolve_semantic_layer.py
    3. profile                 profile.py
    4. classify_screen_type    classify_screen_type.py
    5. plan_analysis           plan_analysis.py
    6. compute_facts           compute_facts.py
    7. present                 present.py
    8. assemble                assemble.py
"""

from scm_agent.nodes.assemble import assemble
from scm_agent.nodes.classify_screen_type import classify_screen_type
from scm_agent.nodes.compute_facts import compute_facts
from scm_agent.nodes.ingest import ingest
from scm_agent.nodes.plan_analysis import plan_analysis
from scm_agent.nodes.present import present
from scm_agent.nodes.profile import profile
from scm_agent.nodes.resolve_semantic_layer import resolve_semantic_layer

__all__ = [
    "ingest",
    "resolve_semantic_layer",
    "profile",
    "classify_screen_type",
    "plan_analysis",
    "compute_facts",
    "present",
    "assemble",
]
