"""
노드 6. compute_facts  [결정론적 · LLM 없음]  — 부록 A.2

입력  : candidates, raw_data, metadata
처리  : 후보를 pandas로 실행해 구조화된 사실 확정
        (기간 증감 · 기여도 · 이상치 등. 수치·비교·인과 근거가 모두 여기서 만들어진다)
출력  : facts
실패  : 일부 후보 실패는 스킵, 전체 실패 시 표 degrade

★ 이 노드가 이 시스템의 '진실의 원천'이다.
  Constitution: LLM은 사실을 생성하지 않는다. 수치도, 비교도, 인과도 여기서만 나온다.
  따라서 이 파일에는 LLM 호출이 절대 들어오면 안 된다.

[1단계 상태] 후보 종류별로 최소 계산만 하는 스텁 (합계 / 기간 증감 / 범주 비교).
[다음 할 일] 이상치 탐지, 기여도 분해, 유의성 판단 추가
"""

import pandas as pd

from scm_agent.state import AgentState


def make_fact(candidate: dict, values: dict, series: list[dict]) -> dict:
    """사실(fact) 하나를 만든다. 모든 fact가 같은 모양을 갖도록 한다.

    values : 문장 템플릿에 주입할 '검증된 숫자'들
    series : 차트에 그릴 점들 ({"x": ..., "y": ...} 목록)
    """
    return {
        "id": candidate.get("id"),
        "kind": candidate.get("kind"),
        "measure": candidate.get("measure"),
        "dimension": candidate.get("dimension"),
        "time_column": candidate.get("time_column"),
        "values": values,
        "series": series,
    }


def compute_single_value(frame: pd.DataFrame, candidate: dict) -> dict:
    """단일 스칼라(합계)를 구한다."""
    measure = candidate.get("measure")
    total = float(frame[measure].sum())

    return make_fact(candidate, {"total": total}, [])


def compute_trend(frame: pd.DataFrame, candidate: dict) -> dict:
    """시간축을 기준으로 measure를 합계 내어 시계열 점들을 만든다."""
    measure = candidate.get("measure")
    time_column = candidate.get("time_column")

    grouped = frame.groupby(time_column, as_index=False)[measure].sum()
    grouped = grouped.sort_values(by=time_column)

    series: list[dict] = []
    for _, row in grouped.iterrows():
        series.append({"x": str(row[time_column]), "y": float(row[measure])})

    values = {
        "point_count": len(series),
        "first_value": series[0]["y"] if series else 0.0,
        "last_value": series[-1]["y"] if series else 0.0,
    }
    return make_fact(candidate, values, series)


def compute_period_change(frame: pd.DataFrame, candidate: dict) -> dict:
    """마지막 기간과 직전 기간을 비교해 증감을 구한다.

    '증가/감소'라는 비교 주장도 여기서 숫자로 확정한다.
    present는 이 값을 그대로 문장에 끼워 넣기만 한다.
    """
    measure = candidate.get("measure")
    time_column = candidate.get("time_column")

    grouped = frame.groupby(time_column, as_index=False)[measure].sum()
    grouped = grouped.sort_values(by=time_column)

    if len(grouped) < 2:
        # 비교할 기간이 없으면 사실을 만들 수 없다. 후보를 스킵한다.
        raise ValueError("비교할 기간이 2개 미만")

    last_row = grouped.iloc[-1]
    previous_row = grouped.iloc[-2]

    last_value = float(last_row[measure])
    previous_value = float(previous_row[measure])
    difference = last_value - previous_value

    if previous_value == 0:
        change_rate = None  # 0으로 나눌 수 없다. 비율은 만들지 않는다.
    else:
        change_rate = round(difference / previous_value * 100, 1)

    if difference > 0:
        direction = "increase"
    elif difference < 0:
        direction = "decrease"
    else:
        direction = "flat"

    values = {
        "last_period": str(last_row[time_column]),
        "previous_period": str(previous_row[time_column]),
        "last_value": last_value,
        "previous_value": previous_value,
        "difference": difference,
        "change_rate": change_rate,
        "direction": direction,
    }
    return make_fact(candidate, values, [])


def compute_category_compare(frame: pd.DataFrame, candidate: dict) -> dict:
    """범주별 합계를 구하고 1위 범주를 확정한다."""
    measure = candidate.get("measure")
    dimension = candidate.get("dimension")

    grouped = frame.groupby(dimension, as_index=False)[measure].sum()
    grouped = grouped.sort_values(by=measure, ascending=False)

    series: list[dict] = []
    for _, row in grouped.iterrows():
        series.append({"x": str(row[dimension]), "y": float(row[measure])})

    total = float(grouped[measure].sum())
    top_row = grouped.iloc[0]
    top_value = float(top_row[measure])

    if total == 0:
        top_share = None
    else:
        top_share = round(top_value / total * 100, 1)

    values = {
        "category_count": len(series),
        "top_category": str(top_row[dimension]),
        "top_value": top_value,
        "total": total,
        "top_share": top_share,
    }
    return make_fact(candidate, values, series)


# 후보 kind -> 계산 함수 연결표.
# 새 분석을 추가할 때는 함수 하나 만들고 여기 한 줄만 추가하면 된다.
COMPUTE_FUNCTIONS = {
    "single_value": compute_single_value,
    "trend": compute_trend,
    "period_change": compute_period_change,
    "category_compare": compute_category_compare,
    "contribution": compute_category_compare,  # [TBD] 기여도 분해는 W3 이후 별도 구현
}


def compute_facts(state: AgentState) -> dict:
    """후보를 하나씩 실행해 구조화된 사실을 확정한다."""

    print("[6/8] compute_facts 실행")

    candidates = state.get("candidates", [])
    raw_data = state.get("raw_data", [])

    if len(candidates) == 0 or len(raw_data) == 0:
        print("      -> 실행할 후보 없음")
        return {"facts": []}

    frame = pd.DataFrame(raw_data)

    facts: list[dict] = []
    skipped: list[str] = []

    for candidate in candidates:
        kind = candidate.get("kind", "")
        compute_function = COMPUTE_FUNCTIONS.get(kind)

        if compute_function is None:
            skipped.append(f"{candidate.get('id')}(알 수 없는 kind: {kind})")
            continue

        # 후보 하나가 실패해도 나머지는 계속 계산한다.
        try:
            fact = compute_function(frame, candidate)
            facts.append(fact)
        except Exception as error:
            skipped.append(f"{candidate.get('id')}({error})")

    print(f"      -> 사실 {len(facts)}건 확정" + (f", 스킵 {skipped}" if skipped else ""))

    # 전체 실패 시 degrade (뒤의 present가 표로 떨어뜨린다).
    if len(facts) == 0:
        validation_errors = list(state.get("validation_errors", []))
        validation_errors.append("모든 분석 후보 실행 실패")
        return {"facts": [], "degraded": True, "validation_errors": validation_errors}

    return {"facts": facts}
