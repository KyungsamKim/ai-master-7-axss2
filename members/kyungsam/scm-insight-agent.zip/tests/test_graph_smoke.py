"""
스모크 테스트 — "그래프가 처음부터 끝까지 도는가"만 확인한다.

노드 내용은 앞으로 매주 바뀌므로, 여기서는 세세한 값 대신
'START -> END가 끊기지 않고 응답이 나온다'는 것을 지킨다.

실행
    pytest -v
    또는 python -m pytest tests/test_graph_smoke.py -v
"""

from data.dummy_payloads import (
    CROSS_PAYLOAD,
    EMPTY_PAYLOAD,
    INVALID_PAYLOAD,
    TIME_SERIES_PAYLOAD,
    UNKNOWN_SCREEN_PAYLOAD,
)
from scm_agent.graph import build_graph, run_pipeline
from scm_agent.semantic.loader import merge_dict_deep, resolve_semantic_context


def test_graph_builds():
    """그래프가 컴파일된다."""
    graph = build_graph()
    assert graph is not None


def test_graph_has_eight_nodes():
    """부록 A.2의 노드 8개가 모두 등록되어 있다."""
    graph = build_graph()
    node_names = set(graph.get_graph().nodes.keys())

    expected = {
        "ingest",
        "resolve_semantic_layer",
        "profile",
        "classify_screen_type",
        "plan_analysis",
        "compute_facts",
        "present",
        "assemble",
    }
    assert expected.issubset(node_names)


def test_time_series_path_returns_line_chart():
    """정상 경로: 시계열 화면은 line 차트로 끝난다."""
    response = run_pipeline(TIME_SERIES_PAYLOAD)

    assert response["status"] == "ok"
    assert response["output_type"] == "line"
    assert response["chart_spec"] is not None
    assert len(response["summary"]) > 0


def test_cross_path_uses_llm_planner():
    """cross 경로: 축이 2개 이상이면 llm_planner 분기를 탄다 (1단계에서는 스텁)."""
    response = run_pipeline(CROSS_PAYLOAD)

    assert response["screen_type"] == "cross"
    assert response["meta"]["planned_by"] == "llm"
    assert response["meta"]["react_iterations"] >= 1
    assert response["output_type"] in ("bar", "line", "kpi", "table")


def test_empty_path_returns_empty():
    """empty 경로: 행 수 0이면 분석을 건너뛰고 메시지만 남는다."""
    response = run_pipeline(EMPTY_PAYLOAD)

    assert response["screen_type"] == "empty"
    assert response["output_type"] == "empty"
    assert response["chart_spec"] is None
    assert response["summary"] is not None  # 안내 문구는 반드시 있다


def test_unknown_screen_degrades():
    """degrade 경로: 화면별 Semantic Layer가 없어도 응답은 반환된다."""
    response = run_pipeline(UNKNOWN_SCREEN_PAYLOAD)

    assert response["status"] == "degraded"
    assert response["degraded"] is True
    assert response["output_type"] in ("table", "empty")


def test_invalid_payload_returns_error_response():
    """오류 경로: 필수 필드가 없어도 assemble은 항상 응답을 만든다."""
    response = run_pipeline(INVALID_PAYLOAD)

    assert response["status"] == "error"
    assert "screen_id" in response["message"]


def test_semantic_layer_merge_order():
    """화면별 계층의 값이 공통 계층을 덮어쓴다."""
    common = {"terms": {"increase": "증가", "decrease": "감소"}, "version": 0.1}
    screen = {"terms": {"increase": "늘어남"}}

    merged = merge_dict_deep(common, screen)

    assert merged["terms"]["increase"] == "늘어남"  # 화면별이 이긴다
    assert merged["terms"]["decrease"] == "감소"  # 공통은 남는다
    assert merged["version"] == 0.1


def test_semantic_layer_resolves_entity_definition():
    """컬럼의 entity 이름표에 공통 계층 정의가 붙는다."""
    context = resolve_semantic_context("SCM_DEMO_TIMESERIES")

    assert context["screen_found"] is True

    plant_column = None
    for column in context["columns"]:
        if column["name"] == "PLANT_CD":
            plant_column = column

    assert plant_column is not None
    assert plant_column["entity_def"]["label"] == "공장"


def test_missing_screen_layer_falls_back_to_common():
    """화면별 계층이 없으면 공통 계층만으로 degrade 한다."""
    context = resolve_semantic_context("NO_SUCH_SCREEN")

    assert context["screen_found"] is False
    assert context["degraded"] is True
    assert len(context["entities"]) > 0  # 공통 계층은 살아 있다
