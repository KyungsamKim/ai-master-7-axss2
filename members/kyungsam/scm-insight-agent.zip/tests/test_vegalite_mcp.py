"""
2단계 — Vega-Lite MCP 연동 테스트 (pytest)

MCP 서버가 설치되어 있지 않은 PC에서도 테스트가 깨지지 않도록,
서버가 없으면 skip 한다. 서버 없이도 성립하는 변환 로직은 항상 검사한다.

실행
    pytest -v
    pytest -v -m ""            # 전체
"""

import pytest

from scm_agent import config
from scm_agent.chart.mcp_client import (
    build_connection_config,
    extract_text,
    is_server_available,
    to_specification_string,
)
from scm_agent.chart.spec import AxisSpec, ChartSpec, DataPoint
from scm_agent.chart.vegalite_adapter import (
    call_vegalite_mcp,
    to_data_rows,
    to_vegalite,
    to_vegalite_encoding,
)

# 서버가 없으면 통과시킬 수 없는 테스트에 붙일 표식
requires_server = pytest.mark.skipif(
    not is_server_available(),
    reason="Vega-Lite MCP 서버(mcp_server_vegalite)가 설치되어 있지 않습니다",
)


def make_spec(chart_type: str = "line") -> ChartSpec:
    """테스트용 중립 차트 스펙."""
    return ChartSpec(
        chart_type=chart_type,
        title="테스트 차트",
        x_axis=AxisSpec(field="YM", label="연월"),
        y_axis=AxisSpec(field="ORDER_QTY", label="발주수량", unit="EA"),
        data=[DataPoint(x="2026-04", y=100.0), DataPoint(x="2026-05", y=200.0)],
    )


# ---------------------------------------------------------------------------
# 서버 없이도 항상 성립해야 하는 것들 (변환 로직)
# ---------------------------------------------------------------------------


def test_encoding_spec_has_no_data_field():
    """★ visualize_data 에 넘길 스펙에는 데이터가 들어가면 안 된다.

    데이터는 save_data로 따로 올리고 서버가 주입한다.
    이 규칙이 '수치가 스펙 문자열에 섞이지 않는다'를 보장한다.
    """
    encoding_spec = to_vegalite_encoding(make_spec())

    assert "data" not in encoding_spec
    assert encoding_spec["mark"] == "line"
    assert encoding_spec["encoding"]["x"]["title"] == "연월"


def test_full_spec_has_data_field():
    """MCP 없이 프론트가 직접 그릴 때 쓰는 완결 스펙에는 데이터가 있다."""
    vegalite_spec = to_vegalite(make_spec())

    assert vegalite_spec["data"]["values"][0] == {"x": "2026-04", "y": 100.0}


def test_bar_chart_maps_to_bar_mark():
    """중립 chart_type이 Vega-Lite mark로 옮겨진다."""
    assert to_vegalite_encoding(make_spec("bar"))["mark"] == "bar"


def test_kpi_chart_type_is_rejected():
    """kpi/table은 차트가 아니므로 Vega-Lite로 넘기지 않는다."""
    spec = ChartSpec(chart_type="kpi", title="KPI", value=10.0)

    with pytest.raises(ValueError):
        to_vegalite_encoding(spec)


def test_call_vegalite_mcp_returns_error_instead_of_raising():
    """MCP로 그릴 수 없는 유형이면 예외 대신 ok=False로 돌아온다 (장애 격리)."""
    spec = ChartSpec(chart_type="kpi", title="KPI", value=10.0)
    result = call_vegalite_mcp(spec)

    assert result["ok"] is False
    assert result["error"]


def test_specification_string_avoids_json_literals():
    """서버가 eval()로 해석하므로 true/false/null이 그대로 나가면 안 된다."""
    text = to_specification_string({"mark": "line", "clip": True})

    assert "true" not in text
    assert "True" in text  # 파이썬 리터럴 표기로 바뀐다


def test_connection_config_uses_stdio_and_project_cwd():
    """stdio 전송 · 프로젝트 루트에서 서버를 띄운다 (서버가 logs/에 로그를 남김)."""
    connection = build_connection_config("text")["vegalite"]

    assert connection["transport"] == "stdio"
    assert connection["args"] == ["--output-type", "text"]
    assert connection["cwd"] == str(config.PROJECT_ROOT)


def test_extract_text_reads_content_blocks():
    """도구 응답에서 텍스트만 뽑아낸다."""
    content = [{"type": "text", "text": "Data saved successfully to table t1"}]

    assert "saved successfully" in extract_text(content)


def test_to_data_rows_shape():
    """save_data에 올릴 행 모양은 {"x":..., "y":...} 이다."""
    rows = to_data_rows(make_spec())

    assert rows == [{"x": "2026-04", "y": 100.0}, {"x": "2026-05", "y": 200.0}]


# ---------------------------------------------------------------------------
# 서버가 있어야 도는 것들 (실제 stdio 왕복)
# ---------------------------------------------------------------------------


@requires_server
def test_mcp_roundtrip_text_mode():
    """text 모드: save_data -> visualize_data 가 한 세션에서 성공한다."""
    result = call_vegalite_mcp(make_spec(), output_type="text")

    assert result["ok"] is True
    assert result["mcp_used"] is True
    assert result["tool_names"] == ["save_data", "visualize_data"]
    assert "saved successfully" in result["save_message"]
    assert "Visualized data" in result["visualize_message"]


@requires_server
def test_mcp_roundtrip_png_mode_returns_image():
    """png 모드: 서버가 vl-convert로 렌더한 PNG(base64)를 돌려준다."""
    result = call_vegalite_mcp(make_spec(), output_type="png")

    assert result["ok"] is True
    assert result["image_base64"] is not None
    assert len(result["image_base64"]) > 1000


@requires_server
def test_pipeline_with_mcp_enabled():
    """MCP를 켠 상태로 파이프라인 전체가 돈다."""
    from data.dummy_payloads import TIME_SERIES_PAYLOAD
    from scm_agent.graph import run_pipeline

    original = config.USE_VEGALITE_MCP
    config.USE_VEGALITE_MCP = True
    try:
        response = run_pipeline(TIME_SERIES_PAYLOAD)
    finally:
        config.USE_VEGALITE_MCP = original

    assert response["status"] == "ok"
    assert response["output_type"] == "line"
    assert response["chart_render"]["ok"] is True
    assert response["chart_render"]["mcp_used"] is True


def test_pipeline_degrades_when_server_is_missing(monkeypatch):
    """★ 장애 격리: MCP 서버가 없어도 응답은 나온다 (degrade로 표시될 뿐).

    monkeypatch는 pytest가 주는 도구로, 테스트가 끝나면 값을 원래대로 돌려놓는다.
    여기서는 서버 명령을 '없는 명령'으로 바꿔 서버가 죽어 있는 상황을 흉내 낸다.
    """
    from data.dummy_payloads import TIME_SERIES_PAYLOAD
    from scm_agent.chart import mcp_client
    from scm_agent.graph import run_pipeline

    monkeypatch.setattr(mcp_client, "VEGALITE_MCP_COMMAND", "no_such_mcp_server_xyz")

    original = config.USE_VEGALITE_MCP
    config.USE_VEGALITE_MCP = True
    try:
        response = run_pipeline(TIME_SERIES_PAYLOAD)
    finally:
        config.USE_VEGALITE_MCP = original

    # 차트 스펙과 문장은 그대로 나온다. MCP만 실패로 기록된다.
    assert response["output_type"] == "line"
    assert response["chart_spec"] is not None
    assert response["summary"]
    assert response["status"] == "degraded"
    assert response["chart_render"]["ok"] is False
    assert "찾을 수 없습니다" in response["chart_render"]["error"]


def test_pipeline_without_mcp_has_no_render():
    """MCP를 끄면 chart_render는 None이고 파이프라인은 그대로 돈다."""
    from data.dummy_payloads import TIME_SERIES_PAYLOAD
    from scm_agent.graph import run_pipeline

    original = config.USE_VEGALITE_MCP
    config.USE_VEGALITE_MCP = False
    try:
        response = run_pipeline(TIME_SERIES_PAYLOAD)
    finally:
        config.USE_VEGALITE_MCP = original

    assert response["status"] == "ok"
    assert response["chart_render"] is None
