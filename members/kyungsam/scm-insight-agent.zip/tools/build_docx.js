// 제출용 Word 문서 생성 (docx-js)
// 2주차 구현 증적 — 대화형 SCM 데이터 분석 Agent (1단계 스켈레톤 + 2단계 MCP 연동)

const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  ImageRun, PageBreak, TableOfContents, PositionalTab, PositionalTabAlignment,
  PositionalTabLeader,
} = require("docx");

// ----- 색/상수 -----
const ACCENT = "1F4E79";     // 진한 남색 (제목)
const CODEBG = "F5F5F5";     // 코드 배경
const HEADBG = "1F4E79";     // 표 헤더 배경
const HEADTX = "FFFFFF";
const FONT = "맑은 고딕";
const CODEFONT = "D2Coding";  // 없으면 뷰어가 대체
const MONO = "Consolas";

// ----- 작은 도우미들 -----
function T(text, opts = {}) { return new TextRun({ text, font: FONT, ...opts }); }

function para(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 120, line: 276 },
    children: [T(text, opts)],
    ...opts.paraOpts,
  });
}

// 여러 런(부분 강조 등)을 받는 문단
function paraRuns(runs, paraOpts = {}) {
  return new Paragraph({ spacing: { after: 120, line: 276 }, children: runs, ...paraOpts });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 320, after: 160 },
    children: [new TextRun({ text, font: FONT, bold: true, size: 30, color: ACCENT })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120 },
    children: [new TextRun({ text, font: FONT, bold: true, size: 25, color: ACCENT })],
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 180, after: 100 },
    children: [new TextRun({ text, font: FONT, bold: true, size: 22, color: "333333" })],
  });
}

// 불릿
function bullet(text, level = 0) {
  return new Paragraph({
    bullet: { level },
    spacing: { after: 60, line: 264 },
    children: [T(text)],
  });
}
// 부분 강조 불릿
function bulletRuns(runs, level = 0) {
  return new Paragraph({ bullet: { level }, spacing: { after: 60, line: 264 }, children: runs });
}

// 코드 블록 (한 문자열, 줄바꿈은 문단 분리)
function codeBlock(code) {
  const lines = code.replace(/\t/g, "    ").split("\n");
  return lines.map((line, i) =>
    new Paragraph({
      spacing: { after: 0, line: 240 },
      shading: { type: ShadingType.CLEAR, fill: CODEBG, color: "auto" },
      border: {
        left: { style: BorderStyle.SINGLE, size: 12, color: "CCCCCC", space: 6 },
      },
      indent: { left: 120 },
      children: [new TextRun({ text: line.length ? line : " ", font: MONO, size: 17 })],
    })
  );
}

// 캡션
function caption(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 60, after: 200 },
    children: [new TextRun({ text, font: FONT, italics: true, size: 17, color: "666666" })],
  });
}

// 표 만들기: headers=[...], rows=[[...],...], widths=[dxa...]
function makeTable(headers, rows, widths) {
  const total = widths.reduce((a, b) => a + b, 0);
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map((hh, i) =>
      new TableCell({
        width: { size: widths[i], type: WidthType.DXA },
        shading: { type: ShadingType.CLEAR, fill: HEADBG, color: "auto" },
        margins: { top: 40, bottom: 40, left: 80, right: 80 },
        children: [new Paragraph({ children: [new TextRun({ text: hh, font: FONT, bold: true, size: 18, color: HEADTX })] })],
      })
    ),
  });
  const bodyRows = rows.map((r, ri) =>
    new TableRow({
      children: r.map((cell, i) =>
        new TableCell({
          width: { size: widths[i], type: WidthType.DXA },
          shading: ri % 2 === 1 ? { type: ShadingType.CLEAR, fill: "F2F6FB", color: "auto" } : undefined,
          margins: { top: 40, bottom: 40, left: 80, right: 80 },
          children: String(cell).split("\n").map((ln) =>
            new Paragraph({ children: [new TextRun({ text: ln, font: FONT, size: 18 })] })
          ),
        })
      ),
    })
  );
  return new Table({
    columnWidths: widths,
    width: { size: total, type: WidthType.DXA },
    rows: [headerRow, ...bodyRows],
  });
}

function image(path, w, h) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 40 },
    children: [new ImageRun({ type: "png", data: fs.readFileSync(path), transformation: { width: w, height: h } })],
  });
}

function hr() {
  return new Paragraph({
    spacing: { before: 80, after: 80 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "DDDDDD", space: 1 } },
    children: [T("")],
  });
}

// ===========================================================================
// 본문
// ===========================================================================
const children = [];

// ---- 표지 ----
children.push(
  new Paragraph({ spacing: { before: 1600, after: 0 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "AI Agent 개발 · 2주차 구현 산출물", font: FONT, size: 24, color: "666666" })] }),
  new Paragraph({ spacing: { before: 200, after: 0 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "대화형 SCM 데이터 분석 Agent", font: FONT, bold: true, size: 44, color: ACCENT })] }),
  new Paragraph({ spacing: { before: 120, after: 0 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "LangGraph 스켈레톤 구현 및 Vega-Lite MCP 연동", font: FONT, size: 26, color: "333333" })] }),
  new Paragraph({ spacing: { before: 700, after: 0 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "1단계: 실행되는 8노드 뼈대 (end-to-end 통과)", font: FONT, size: 20, color: "555555" })] }),
  new Paragraph({ spacing: { before: 80, after: 0 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "2단계: Vega-Lite MCP 연동 (save_data → visualize_data 왕복 검증)", font: FONT, size: 20, color: "555555" })] }),
  new Paragraph({ spacing: { before: 1000, after: 0 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "작성일 2026-08-13", font: FONT, size: 20, color: "888888" })] }),
  new Paragraph({ spacing: { before: 60, after: 0 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "근거 문서: 2주차_ICE변동사항_대화형SCM데이터분석Agent (부록 A 확정 Spec)", font: FONT, size: 18, color: "888888" })] }),
  new Paragraph({ children: [new PageBreak()] }),
);

// ---- 목차 (정적: 뷰어에서 항상 보이도록) ----
children.push(h1("목차"));
const tocItems = [
  ["1. 개요", 3],
  ["2. 시스템 개요", 4],
  ["3. 1단계 — LangGraph 스켈레톤", 6],
  ["4. 2단계 — Vega-Lite MCP 연동", 8],
  ["5. 설계 원칙 정합성 (Constitution)", 10],
  ["6. 형상관리(Git) 방안", 10],
  ["7. 남은 작업", 11],
  ["부록. 프로젝트 구조 및 실행", 12],
];
const NOBORDER = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NOBORDER, bottom: NOBORDER, left: NOBORDER, right: NOBORDER,
  insideHorizontal: NOBORDER, insideVertical: NOBORDER };
const tocRows = tocItems.map(([t, p]) =>
  new TableRow({
    children: [
      new TableCell({
        width: { size: 8100, type: WidthType.DXA }, borders: noBorders,
        margins: { top: 30, bottom: 30, left: 0, right: 0 },
        children: [new Paragraph({ children: [new TextRun({ text: t, font: FONT, size: 20, bold: true })] })],
      }),
      new TableCell({
        width: { size: 900, type: WidthType.DXA }, borders: noBorders,
        margins: { top: 30, bottom: 30, left: 0, right: 0 },
        children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: String(p), font: FONT, size: 20 })] })],
      }),
    ],
  })
);
children.push(new Table({ columnWidths: [8100, 900], width: { size: 9000, type: WidthType.DXA }, borders: noBorders, rows: tocRows }));
children.push(new Paragraph({ children: [new PageBreak()] }));

// ===========================================================================
// 1. 개요
// ===========================================================================
children.push(h1("1. 개요"));
children.push(para("이 문서는 AI Master 프로그램 2주차 과제의 구현 산출물이다. 1주차에 확정한 설계(부록 A)를 바탕으로 실제 코드를 작성했으며, 두 단계로 나누어 진행했다."));
children.push(bulletRuns([T("1단계 — ", { bold: true }), T("LangGraph 8노드 스켈레톤. 각 노드는 스텁이지만 더미 데이터로 START→END가 끊기지 않고 통과한다.")]));
children.push(bulletRuns([T("2단계 — ", { bold: true }), T("Vega-Lite MCP 연동. 차트 생성을 MCP 서버에 위임하고 save_data → visualize_data 왕복을 검증했다.")]));
children.push(para("구현 목적의 첫째는 학습이다. 따라서 매주 증분 수정이 쉬운 구조를 유지하고, 초보자가 읽을 수 있도록 한글 주석을 충실히 달았으며, 람다·난해한 문법을 지양했다(구현 규약, 본문 2.3절)."));

children.push(h2("1.1 실행 환경"));
children.push(makeTable(
  ["항목", "내용"],
  [
    ["언어 / 런타임", "Python 3.11"],
    ["핵심 라이브러리", "langgraph, pandas, pydantic, PyYAML"],
    ["MCP 연동", "langchain-mcp-adapters 0.3.2, mcp 1.27.0 (stdio 전송)"],
    ["MCP 서버", "isaacwasserman/mcp-vegalite-server (vl-convert 기반)"],
    ["테스트", "pytest — 총 24개 통과"],
    ["LLM 호출", "없음 (현재 단계까지 API 키 불필요)"],
  ],
  [3000, 6000],
));

children.push(new Paragraph({ children: [new PageBreak()] }));

// ===========================================================================
// 2. 시스템 개요
// ===========================================================================
children.push(h1("2. 시스템 개요"));
children.push(para("파이프라인은 백엔드가 넘긴 조회 결과를 받아, 화면의 의미(Semantic Layer)를 조합하고, 화면 유형을 판정한 뒤, 분석 후보를 세우고, 사실을 결정론적으로 확정하고, 마지막에 표현(차트·문장)을 정해 응답으로 조립한다. 표현을 파이프라인 마지막에 두는 것이 1주차 대비 핵심 변경점이다."));
children.push(image("docs/graph.png", 430, 560));
children.push(caption("그림 1. LangGraph 8노드 파이프라인 (점선 = 분기·degrade 경로, 부록 A.5)"));

children.push(h2("2.1 노드 구성 (부록 A.2)"));
children.push(makeTable(
  ["#", "노드", "종류", "역할"],
  [
    ["1", "ingest", "결정론적", "페이로드 수신, 필수 필드 확인, 행 수 0 플래그"],
    ["2", "resolve_semantic_layer", "Semantic", "공통+화면별 계층을 screen_id로 조합"],
    ["3", "profile", "결정론적", "pandas 통계 프로파일 산출"],
    ["4", "classify_screen_type", "분기", "화면 구조 유형 판정 후 전략 분기 (A.3)"],
    ["5", "plan_analysis", "분기(rule|LLM)", "분석 후보 탐색 (llm은 ReAct, 현재 스텁)"],
    ["6", "compute_facts", "결정론적", "후보 실행 → 사실 확정 (수치·비교·인과의 원천)"],
    ["7", "present", "결정론적", "차트 타입 결정 + 템플릿 문장 + MCP 호출"],
    ["8", "assemble", "결정론적", "최종 응답 조립 (항상 응답 반환)"],
  ],
  [500, 2900, 1700, 3900],
));

children.push(h2("2.2 State 스키마 (부록 A.1)"));
children.push(para("모든 노드는 하나의 State(사전)를 돌아가며 채운다. 문서 A.1의 필드를 그대로 두고, 조건부 엣지 제어에 필요한 내부 필드(fatal_error, react_iterations, need_more_react, present_retries, present_ok, chart_render)만 별도 구획에 주석과 함께 추가했다."));

children.push(new Paragraph({ children: [new PageBreak()] }));

// ===========================================================================
// 3. 1단계 — LangGraph 스켈레톤
// ===========================================================================
children.push(h1("3. 1단계 — LangGraph 스켈레톤"));
children.push(para("1단계의 목표는 기능 완성이 아니라 “그래프가 처음부터 끝까지 도는 것”을 먼저 확보하는 것이다. 각 노드를 스텁으로 두더라도 START→END가 돌면, 이후 매주 한 노드씩 살을 붙이기가 훨씬 쉽다."));

children.push(h2("3.1 조건부 엣지 · degrade 구현 (부록 A.5)"));
children.push(para("분기 4곳을 라우팅 함수로 구현했다. 라우팅 함수는 State를 보고 “다음에 갈 노드 이름”을 문자열로 돌려주며, 그래프가 그 이름으로 이동한다."));
children.push(makeTable(
  ["분기", "위치", "내용"],
  [
    ["ingest 실패", "route_after_ingest", "필수 필드 누락 시 즉시 assemble"],
    ["classify 3분기", "route_after_classify", "plan_analysis / present(표만) / assemble(empty)"],
    ["ReAct 자기 순환", "route_after_plan_analysis", "need_more_react=True면 plan_analysis로 복귀 (상한 R=2)"],
    ["present 재시도", "route_after_present", "스펙 검증 실패 시 1회 재시도 → 재실패면 table degrade"],
  ],
  [1900, 3100, 4000],
));
children.push(h3("핵심 코드 — classify 3분기"));
children.push(...codeBlock(
`def route_after_classify(state: AgentState) -> str:
    """A.5 · classify_screen_type 3분기."""
    screen_type = state.get("screen_type", "detail_table")

    if screen_type == "empty":
        return "assemble"          # 분석할 것이 없다

    if screen_type == "detail_table":
        return "present"           # 상세 목록: 분석 없이 표만

    return "plan_analysis"         # 그 외: 분석 진행`
));
children.push(paraRuns([
  T("설계상 강조점. ", { bold: true }),
  T("ReAct 반복을 노드 내부 for문이 아니라 그래프의 자기 순환 엣지로 만들었다. 그래야 매 반복이 State에 남고 LangGraph 스트림에서 눈으로 보인다. 그래서 llm_planner는 “한 번의 반복”만 수행하고 돌아간다."),
]));

children.push(h2("3.2 Semantic Layer 로더 (완성된 부분)"));
children.push(para("이번 단계에서 실제 내용이 채워진 핵심 모듈이다. YAML 안의 지표·제품속성 값은 다음 주에 회사 자료로 채우지만(TBD), 공통 계층과 화면별 계층을 읽어 합치는 로직은 지금 완성했다. 화면별 계층이 없으면 공통 계층만으로 degrade 한다."));
children.push(...codeBlock(
`def merge_dict_deep(base, override):
    """두 dict를 깊게 합친다. 같은 키는 override(화면별)가 이긴다."""
    result = dict(base)
    for key in override:
        if isinstance(result.get(key), dict) and isinstance(override[key], dict):
            result[key] = merge_dict_deep(result[key], override[key])
        else:
            result[key] = override[key]
    return result`
));

children.push(h2("3.3 실행 검증"));
children.push(para("더미 페이로드 5종으로 서로 다른 경로를 태워, 모든 경로가 응답을 반환하는지 확인했다."));
children.push(makeTable(
  ["경로", "흐름", "결과"],
  [
    ["time_series", "8노드 전부 통과 · rule_planner", "ok / line / 후보 3→사실 3"],
    ["cross", "classify=cross → llm_planner 분기(스텁)", "ok / bar / planned_by=llm"],
    ["empty", "classify에서 assemble로 직행", "ok / empty + 안내 문구"],
    ["unknown_screen", "화면별 YAML 부재 → 공통 계층만", "degraded / table"],
    ["invalid", "ingest에서 assemble로 직행", "error + 메시지"],
  ],
  [1900, 4100, 3000],
));
children.push(h3("time_series 경로 실제 출력 (템플릿 문장)"));
children.push(...codeBlock(
`연월 기준 3개 구간의 발주수량 추이입니다.
2026-05 발주수량은(는) 2,800로, 직전 기간(2026-04) 대비 400 증가했습니다 (+16.7%).
공장 2개 중 'P100'의 발주수량이(가) 4,400로 가장 큽니다 (전체의 61.1%).`
));
children.push(paraRuns([
  T("이 문장의 모든 수치·비교(“400 증가”, “가장 큽니다”)는 compute_facts가 확정한 값이다. present는 템플릿에 값을 끼워 넣기만 했다. "),
  T("LLM은 한 글자도 쓰지 않았다.", { bold: true }),
]));

children.push(new Paragraph({ children: [new PageBreak()] }));

// ===========================================================================
// 4. 2단계 — Vega-Lite MCP 연동
// ===========================================================================
children.push(h1("4. 2단계 — Vega-Lite MCP 연동"));
children.push(para("1주차 MCP 리서치에서 채택한 Vega-Lite MCP를 실제로 붙였다. 연동 방식은 문서대로 langchain-mcp-adapters + stdio(서브프로세스)이며, 기본 출력은 text 모드다."));

children.push(h2("4.1 왜 도구가 2개인가 (원칙과의 정합)"));
children.push(para("Vega-Lite MCP는 save_data와 visualize_data 두 도구로 나뉘어 있다. 데이터를 save_data로 먼저 서버에 올려 두고, visualize_data에는 “데이터 이름과 시각 인코딩”만 넘긴다. 즉 수치가 스펙 문자열에 섞여 들어가지 않는다."));
children.push(paraRuns([
  T("이 구조가 핵심 원칙(“사실은 코드, LLM은 표현”)을 코드 수준에서 강제한다. ", { bold: true }),
  T("나중에 이 자리에 LLM을 붙여도 LLM은 인코딩만 만지게 되고, 수치는 compute_facts가 만든 값이 그대로 서버로 간다."),
]));
children.push(...codeBlock(
`async with client.session("vegalite") as session:
    tools = await load_mcp_tools(session)
    tool_by_name = {t.name: t for t in tools}

    # 1) 데이터를 서버에 올린다 (수치는 여기서만 이동한다)
    await tool_by_name["save_data"].ainvoke(
        {"name": data_name, "data": data_rows})

    # 2) 인코딩만 넘겨 시각화를 요청한다 (data 필드는 넣지 않는다)
    call = {"name": "visualize_data",
            "args": {"data_name": data_name,
                     "vegalite_specification": to_specification_string(spec)},
            "id": "c1", "type": "tool_call"}
    msg = await tool_by_name["visualize_data"].ainvoke(call)`
));
children.push(paraRuns([
  T("★ save_data와 visualize_data는 같은 세션에서 불러야 한다. ", { bold: true }),
  T("서버가 저장한 데이터를 그 프로세스 메모리에 들고 있어서, 세션을 나누면 데이터를 못 찾는다."),
]));

children.push(h2("4.2 연동 검증 결과"));
children.push(para("전용 테스트 스크립트(run_mcp_test.py)로 6단계를 확인했고, 14개 항목이 모두 통과했다."));
children.push(makeTable(
  ["단계", "결과"],
  [
    ["도구 목록 조회", "['save_data', 'visualize_data']"],
    ["text 모드 왕복", "\"Data saved…\" → \"Visualized data … with provided spec.\""],
    ["png 모드 왕복", "73,382 bytes PNG 수신 (그림 2)"],
    ["그래프 통합 실행", "MCP 켠 상태로 파이프라인 통과 (mcp_used=True)"],
  ],
  [2600, 6400],
));
children.push(image("docs/vegalite_sample.png", 400, 262));
children.push(caption("그림 2. Vega-Lite MCP 서버(png 모드)가 실제로 렌더한 차트 — 한글 축 라벨 정상"));

children.push(h2("4.3 연동하며 확인한 함정"));
children.push(para("저장소 문서와 실제 동작이 달라 헤맬 수 있는 지점을 코드와 주석에 정리해 두었다."));
children.push(makeTable(
  ["항목", "내용"],
  [
    ["실행 인자", "README의 --output_type이 아니라 --output-type (하이픈)"],
    ["실행 파일명", "README 예시가 아니라 mcp_server_vegalite"],
    ["작업 디렉터리", "서버가 logs/에 로그를 남김 → logs 폴더가 있는 곳에서 실행"],
    ["스펙 문자열", "서버가 eval()로 해석 → JSON true/false/null을 파이썬 리터럴로 변환"],
    ["data 필드", "visualize_data 스펙에는 data를 넣지 않음 (서버가 주입)"],
    ["크기 지정", "width/height 없으면 그림이 지나치게 좁게 렌더됨"],
  ],
  [2400, 6600],
));

children.push(h2("4.4 장애 격리"));
children.push(para("MCP 호출이 실패해도(서버 미설치·타임아웃·오류) 예외를 던지지 않는다. 중립 차트 스펙과 템플릿 문장은 이미 만들어져 있으므로 응답은 그대로 나가고, status만 degraded가 되며 사유가 validation_errors에 남는다. 서버가 없는 환경을 흉내 낸 테스트로 이 동작을 고정했다."));

children.push(new Paragraph({ children: [new PageBreak()] }));

// ===========================================================================
// 5. 원칙 정합성
// ===========================================================================
children.push(h1("5. 설계 원칙 정합성 (Constitution)"));
children.push(para("구현 전반에서 1주차에 확정한 규칙을 지켰다."));
children.push(bulletRuns([T("LLM은 사실을 생성하지 않는다. ", { bold: true }), T("수치·비교·인과는 전부 compute_facts.py에서만 나온다.")]));
children.push(bulletRuns([T("문장은 템플릿이 옮긴다. ", { bold: true }), T("사용자에게 보이는 모든 문장은 templates.py 안에 있다.")]));
children.push(bulletRuns([T("원본 데이터는 LLM에 넣지 않는다. ", { bold: true }), T("llm_planner는 프로파일 요약과 컬럼 의미만 페이로드로 만든다.")]));
children.push(bulletRuns([T("표현 결정은 마지막에 한다. ", { bold: true }), T("차트 타입·문장은 파이프라인 끝단 present에서 정한다.")]));
children.push(bulletRuns([T("중립 스펙 + adapter. ", { bold: true }), T("present는 라이브러리 중립 스펙까지만 만들고, Vega-Lite라는 이름은 adapter 밖으로 나가지 않는다.")]));

// ===========================================================================
// 6. 형상관리
// ===========================================================================
children.push(h1("6. 형상관리(Git) 방안"));
children.push(para("AI 코딩으로 코드를 받더라도 버전을 남기는 일은 사람이 한다. 그래야 “지난주 잘 되던 상태로 되돌리기”와 “무엇이 언제 바뀌었는지 보기”가 가능하다. 매주 한 노드씩 채워 나가는 이 프로젝트에는 git이 특히 잘 맞는다."));

children.push(h2("6.1 기본 흐름"));
children.push(bulletRuns([T("최초 1회 — ", { bold: true }), T("git init 후 전체를 첫 커밋한다.")]));
children.push(bulletRuns([T("매주 반복 — ", { bold: true }), T("한 주 작업이 끝나면 git add . → git commit → git push. “노드 하나를 채우면 한 커밋”이 자연스럽다.")]));
children.push(bulletRuns([T("제출 지점 — ", { bold: true }), T("태그로 표시한다: git tag -a week2 -m \"2주차 제출\".")]));
children.push(...codeBlock(
`git init
git add .
git commit -m "2주차: LangGraph 스켈레톤 + Vega-Lite MCP 연동"

# 매주 반복
git add .
git commit -m "W3: llm_planner ReAct 실제 LLM 호출로 교체"
git push`
));

children.push(h2("6.2 원격 저장소(GitHub)"));
children.push(para("백업·이력·공유를 위해 GitHub private 저장소에 올린다. GitHub CLI를 쓰면 한 번에 생성·연결·업로드가 된다."));
children.push(...codeBlock(
`winget install --id GitHub.cli    # 최초 1회
gh auth login
gh repo create scm-insight-agent --private --source . --remote origin --push`
));

children.push(h2("6.3 OneDrive 주의 (중요)"));
children.push(paraRuns([
  T("현재 프로젝트가 OneDrive 폴더 안에 있다. ", { bold: true }),
  T("OneDrive가 파일을 실시간 동기화하는 동안 git이 .git 내부 파일을 빠르게 바꾸면 저장소가 깨질 수 있다. 가장 안전한 방법은 프로젝트를 OneDrive 밖(예: D:\\dev\\)으로 옮기는 것이다. 백업은 GitHub push가 대신한다. 옮기기 어렵다면 커밋·push 하는 동안만 OneDrive 동기화를 일시 중지한다."),
]));

children.push(h2("6.4 이 저장소에 포함한 형상관리 설정"));
children.push(makeTable(
  ["파일", "역할"],
  [
    [".gitignore", "가상환경·캐시·로그·.env·OneDrive 부산물 제외"],
    [".gitattributes", "줄바꿈(EOL) LF 통일, 이미지·docx를 바이너리로 표시 (Windows 대비)"],
    [".env.example", "필요한 환경변수 키 이름만 공유 (실제 .env는 커밋 안 함)"],
    ["docs/git-guide.md", "초보자용 git 사용 가이드 전문"],
  ],
  [2400, 6600],
));
children.push(paraRuns([
  T("습관 하나. ", { bold: true }),
  T("AI에게 코드를 받기 전에 먼저 커밋해 두면, 결과가 마음에 안 들 때 git restore . 로 즉시 되돌릴 수 있다. AI가 만든 변경은 git diff로 직접 읽고 커밋하는 것이 학습 목적에도 맞는다."),
]));

// ===========================================================================
// 7. 남은 작업
// ===========================================================================
children.push(h1("7. 남은 작업"));
children.push(makeTable(
  ["시점", "작업"],
  [
    ["W3", "llm_planner를 실제 ReAct(LLM 호출)로 교체 — 구조화 출력 + 컬럼 존재 검증"],
    ["W5", "resolve_semantic_layer를 screen_id 완전 일치에서 유사 화면 검색으로 확장"],
    ["W6", "오프라인 Semantic Layer 빌더 구현 (builder_stub → 실제 구현)"],
    ["W7", "임계값(저카디널리티 경계 / llm 전환 / K / R) 캘리브레이션, 표현 개선 루프 검토"],
    ["상시", "semantic_layer/*.yaml의 [TBD]를 회사 지표·제품속성으로 채우기"],
  ],
  [1200, 7800],
));
children.push(paraRuns([
  T("코드에서 ", {}),
  new TextRun({ text: "[TBD]", font: MONO, size: 18 }),
  T(" 로 검색하면 채워야 할 자리가 전부 나온다. 노드가 파일로 분리돼 있어, 매주 파일 하나만 열어 살을 붙이면 된다.", {}),
]));

// ===========================================================================
// 부록
// ===========================================================================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h1("부록. 프로젝트 구조 및 실행"));
children.push(h2("A. 폴더 구조"));
children.push(...codeBlock(
`scm-insight-agent/
├── run_demo.py               1단계 실행 (--mcp 로 2단계 포함)
├── run_mcp_test.py           2단계 MCP 연동 테스트
├── requirements.txt
├── scm_agent/
│   ├── state.py              State 스키마 (A.1)
│   ├── config.py             임계값·경로·MCP 설정
│   ├── graph.py              8노드 조립 + 조건부 엣지 (A.5)
│   ├── templates.py          문장 템플릿
│   ├── nodes/                노드 8개 (파일 1개씩)
│   ├── planners/             rule_planner / llm_planner
│   ├── semantic/             loader(완성) / builder_stub(W6)
│   └── chart/                spec / vegalite_adapter / mcp_client
├── semantic_layer/           공통 + 화면별 YAML
├── data/dummy_payloads.py    더미 페이로드 5종
├── tests/                    스모크 10 + MCP 14 = 24개
└── docs/                     그래프·샘플 차트·git 가이드`
));
children.push(h2("B. 실행 방법"));
children.push(...codeBlock(
`python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt

python run_demo.py            # 5개 경로 전부 실행
pytest -v                     # 테스트 24개

# 2단계 (MCP 서버 설치 후)
pip install git+https://github.com/isaacwasserman/mcp-vegalite-server.git
python run_mcp_test.py`
));
children.push(paraRuns([
  T("참고 — Windows 인코딩. ", { bold: true }),
  T("한국어 Windows는 기본 인코딩이 cp949라서, 도구가 읽는 설정 파일(requirements.txt 등)에 한글이 있으면 pip이 실패한다. 이 프로젝트는 그런 설정 파일을 영문으로만 작성했고, 실행 스크립트도 콘솔 인코딩 오류를 무시하도록 처리해 두었다."),
]));

// ===========================================================================
// 문서 생성
// ===========================================================================
const doc = new Document({
  creator: "SCM Insight Agent",
  title: "2주차 구현 산출물 — 대화형 SCM 데이터 분석 Agent",
  styles: {
    default: {
      document: { run: { font: FONT, size: 20 } },
    },
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },  // A4
        margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },
      },
    },
    children,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("2주차_구현산출물_대화형SCM데이터분석Agent.docx", buf);
  console.log("생성 완료:", buf.length, "bytes");
});
