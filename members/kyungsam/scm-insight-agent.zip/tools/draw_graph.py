"""
파이프라인 그래프 다이어그램 생성 (문서·발표용)

LangGraph 기본 렌더러(draw_mermaid_png)는 외부 API(mermaid.ink)를 쓰기 때문에
사내망·오프라인에서 자주 실패한다. 그래서 matplotlib로 직접 그린다.
부록 A.6의 색 구분(결정론적=파랑 / LLM=앰버 / 분기=보라 / Semantic=초록)을 따른다.

    python tools/draw_graph.py   ->  docs/graph.png
"""

import matplotlib

matplotlib.use("Agg")  # 화면 없이 파일로만 저장
import matplotlib.font_manager as fm
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

# 한글 폰트 (컨테이너에 설치된 Noto Sans CJK 사용)
for candidate in ["Noto Sans CJK KR", "Noto Sans CJK JP", "NanumGothic"]:
    if any(candidate in f.name for f in fm.fontManager.ttflist):
        plt.rcParams["font.family"] = candidate
        break
plt.rcParams["axes.unicode_minus"] = False

# 색 팔레트 (채움, 테두리)
BLUE = ("#dbeafe", "#2563eb")  # 결정론적
GREEN = ("#dcfce7", "#16a34a")  # Semantic Layer
PURPLE = ("#ede9fe", "#7c3aed")  # 분기
AMBER = ("#fef3c7", "#d97706")  # LLM


def add_box(ax, x, y, text, fill, edge, w=2.6, h=0.7):
    """둥근 사각형 노드 하나를 그린다."""
    box = FancyBboxPatch(
        (x - w / 2, y - h / 2),
        w,
        h,
        boxstyle="round,pad=0.02,rounding_size=0.12",
        linewidth=1.6,
        edgecolor=edge,
        facecolor=fill,
    )
    ax.add_patch(box)
    ax.text(x, y, text, ha="center", va="center", fontsize=9.5, color="#111827")


def add_arrow(ax, p1, p2, style="-", color="#374151", rad=0.0):
    """노드 사이 화살표. style='--'이면 점선(degrade/분기)."""
    arrow = FancyArrowPatch(
        p1,
        p2,
        arrowstyle="-|>",
        mutation_scale=13,
        linewidth=1.3,
        linestyle=style,
        color=color,
        connectionstyle=f"arc3,rad={rad}",
        shrinkA=2,
        shrinkB=2,
    )
    ax.add_patch(arrow)


def main():
    fig, ax = plt.subplots(figsize=(8.2, 10.5))
    ax.set_xlim(0, 8)
    ax.set_ylim(0, 12)
    ax.axis("off")

    xc = 3.0  # 메인 세로줄 x 좌표

    # (y, 라벨, 채움, 테두리)
    nodes = {
        "START": (11.3, "START", "#f3f4f6", "#9ca3af"),
        "ingest": (10.4, "1. ingest", *BLUE),
        "resolve": (9.5, "2. resolve_semantic_layer", *GREEN),
        "profile": (8.6, "3. profile", *BLUE),
        "classify": (7.7, "4. classify_screen_type", *PURPLE),
        "plan": (6.6, "5. plan_analysis  (rule | LLM)", *AMBER),
        "compute": (5.5, "6. compute_facts", *BLUE),
        "present": (4.6, "7. present", *BLUE),
        "assemble": (3.5, "8. assemble", *BLUE),
        "END": (2.6, "END", "#f3f4f6", "#9ca3af"),
    }
    for key, (y, label, fill, edge) in nodes.items():
        wide = 3.6 if key in ("resolve", "plan", "classify") else 2.6
        add_box(ax, xc, y, label, fill, edge, w=wide)

    def top(key):
        return (xc, nodes[key][0] + 0.35)

    def bottom(key):
        return (xc, nodes[key][0] - 0.35)

    # --- 메인 흐름 (실선) ---
    main_seq = ["START", "ingest", "resolve", "profile", "classify"]
    for a, b in zip(main_seq, main_seq[1:]):
        add_arrow(ax, bottom(a), top(b))
    add_arrow(ax, bottom("classify"), top("plan"))
    add_arrow(ax, bottom("plan"), top("compute"))
    add_arrow(ax, bottom("compute"), top("present"))
    add_arrow(ax, bottom("present"), top("assemble"))
    add_arrow(ax, bottom("assemble"), top("END"))

    # --- 분기/degrade (점선, 오른쪽으로 우회) ---
    dashed = "#7c3aed"

    # ingest 실패 -> assemble (치명적 오류)
    add_arrow(ax, (xc + 1.3, 10.4), (xc + 1.3, 3.5), style="--", color="#9ca3af", rad=0)
    ax.text(xc + 1.45, 6.9, "ingest 실패", fontsize=8, color="#6b7280", rotation=90, va="center")

    # classify -> assemble (empty)
    add_arrow(ax, (xc + 1.8, 7.7), (xc + 1.8, 3.5), style="--", color=dashed, rad=0)
    ax.text(xc + 1.95, 5.6, "empty", fontsize=8, color=dashed, rotation=90, va="center")

    # classify -> present (detail_table: 표만)
    add_arrow(ax, (xc + 0.9, 7.35), (xc + 0.9, 4.6), style="--", color=dashed, rad=0)
    ax.text(xc + 1.05, 6.0, "detail_table", fontsize=8, color=dashed, rotation=90, va="center")

    # plan_analysis 자기 순환 (ReAct)
    add_arrow(ax, (xc - 1.85, 6.85), (xc - 1.85, 6.35), style="--", color=AMBER[1], rad=-1.2)
    ax.text(xc - 2.55, 6.6, "ReAct\n(R회)", fontsize=8, color=AMBER[1], ha="center", va="center")

    # present 자기 순환 (재시도)
    add_arrow(ax, (xc - 1.35, 4.85), (xc - 1.35, 4.35), style="--", color=BLUE[1], rad=-1.2)
    ax.text(xc - 2.0, 4.6, "재시도\n(1회)", fontsize=8, color=BLUE[1], ha="center", va="center")

    # --- 범례 ---
    legend_handles = [
        mpatches.Patch(facecolor=BLUE[0], edgecolor=BLUE[1], label="결정론적 (LLM 없음)"),
        mpatches.Patch(facecolor=GREEN[0], edgecolor=GREEN[1], label="Semantic Layer"),
        mpatches.Patch(facecolor=PURPLE[0], edgecolor=PURPLE[1], label="분기"),
        mpatches.Patch(facecolor=AMBER[0], edgecolor=AMBER[1], label="LLM 분기 (현재 스텁)"),
    ]
    ax.legend(
        handles=legend_handles,
        loc="lower left",
        bbox_to_anchor=(0.0, 0.0),
        fontsize=8.5,
        frameon=True,
        title="노드 종류",
        title_fontsize=9,
    )

    ax.set_title(
        "대화형 SCM 데이터 분석 Agent — LangGraph 파이프라인 (8노드)",
        fontsize=12,
        pad=14,
    )
    ax.text(
        xc,
        1.6,
        "점선 = 분기 · degrade 경로 (부록 A.5)",
        ha="center",
        fontsize=8.5,
        color="#6b7280",
    )

    fig.tight_layout()
    fig.savefig("docs/graph.png", dpi=150, bbox_inches="tight")
    print("저장: docs/graph.png")


if __name__ == "__main__":
    main()
