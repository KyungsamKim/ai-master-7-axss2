"""
1단계 실행 진입점 — 더미 데이터로 그래프를 START부터 END까지 돌려 본다.

사용법
    python run_demo.py              # 5가지 경로를 모두 실행
    python run_demo.py time_series  # 특정 경로만 실행
    python run_demo.py --mermaid    # 그래프 구조를 Mermaid 텍스트로 출력
    python run_demo.py --mcp        # [2단계] Vega-Lite MCP를 켜고 실행
                                    #   (config.USE_VEGALITE_MCP를 코드 수정 없이 True로)

목적
    노드 내용을 채우기 전에 "그래프가 처음부터 끝까지 도는 것"을 먼저 확인한다.
    스텁이라도 START->END가 돌면, 이후 매주 한 노드씩 살을 붙이기가 훨씬 쉽다.
"""

import json
import sys

# Windows 한국어 콘솔은 기본 인코딩이 cp949라서, cp949에 없는 문자가 하나라도 있으면
# 출력 도중 UnicodeEncodeError로 프로그램이 멈춘다.
# errors="replace"로 바꿔 두면 그런 문자는 '?'로 대체되고 실행은 계속된다.
# (콘솔 인코딩 자체는 건드리지 않으므로 한글은 그대로 잘 보인다)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(errors="replace")

from data.dummy_payloads import ALL_PAYLOADS
from scm_agent import config
from scm_agent.graph import build_graph
from scm_agent.state import create_initial_state


def print_divider(title: str) -> None:
    """구분선을 찍는다. 실행 로그를 눈으로 읽기 쉽게 하려는 용도."""
    print()
    print("=" * 72)
    print(f"  {title}")
    print("=" * 72)


def run_one(name: str, payload: dict) -> dict:
    """페이로드 하나를 그래프에 흘린다."""
    print_divider(f"경로: {name}  (screen_id={payload.get('screen_id', '없음')})")

    graph = build_graph()
    initial_state = create_initial_state(payload)
    final_state = graph.invoke(initial_state)

    response = final_state.get("response", {})

    print()
    print("--- 최종 응답 ---")
    print(json.dumps(response, ensure_ascii=False, indent=2))

    return response


def print_mermaid() -> None:
    """그래프 구조를 Mermaid 텍스트로 출력한다. (문서에 붙여 넣기 좋다)"""
    graph = build_graph()
    print(graph.get_graph().draw_mermaid())


def main() -> None:
    arguments = sys.argv[1:]

    if "--mermaid" in arguments:
        print_mermaid()
        return

    # [2단계] --mcp 를 주면 Vega-Lite MCP 호출을 켠다.
    if "--mcp" in arguments:
        config.USE_VEGALITE_MCP = True
        arguments.remove("--mcp")
        print("[설정] Vega-Lite MCP 호출을 켰습니다 "
              f"(output_type={config.VEGALITE_MCP_OUTPUT_TYPE})")

    if len(arguments) > 0:
        name = arguments[0]
        if name not in ALL_PAYLOADS:
            print(f"알 수 없는 경로: {name}")
            print(f"사용 가능: {list(ALL_PAYLOADS.keys())}")
            return
        run_one(name, ALL_PAYLOADS[name])
        return

    # 인자가 없으면 모든 경로를 순서대로 실행한다.
    for name in ALL_PAYLOADS:
        run_one(name, ALL_PAYLOADS[name])

    print_divider("전체 경로 실행 완료")


if __name__ == "__main__":
    main()
