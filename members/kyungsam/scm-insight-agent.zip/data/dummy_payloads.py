"""
더미 페이로드 — 1단계 end-to-end 확인용

실제 백엔드가 보낼 payload 모양을 흉내 낸 가짜 데이터다.
payload = {"screen_id": ..., "sql": ..., "raw_data": [...]}

각 페이로드는 서로 다른 경로를 타도록 일부러 다르게 만들었다.
그래프의 분기·degrade가 실제로 도는지 눈으로 확인하기 위함이다.
"""

# 1) 정상 경로 — time_series -> rule_planner -> line 차트
TIME_SERIES_PAYLOAD = {
    "screen_id": "SCM_DEMO_TIMESERIES",
    "sql": "SELECT YM, PLANT_CD, SUM(ORDER_QTY) FROM ... GROUP BY YM, PLANT_CD",
    "raw_data": [
        {"YM": "2026-03", "PLANT_CD": "P100", "ORDER_QTY": 1200},
        {"YM": "2026-03", "PLANT_CD": "P200", "ORDER_QTY": 800},
        {"YM": "2026-04", "PLANT_CD": "P100", "ORDER_QTY": 1500},
        {"YM": "2026-04", "PLANT_CD": "P200", "ORDER_QTY": 900},
        {"YM": "2026-05", "PLANT_CD": "P100", "ORDER_QTY": 1700},
        {"YM": "2026-05", "PLANT_CD": "P200", "ORDER_QTY": 1100},
    ],
}

# 2) cross 경로 — 축 2개 이상 -> llm_planner(ReAct) 분기 (1단계에서는 스텁)
CROSS_PAYLOAD = {
    "screen_id": "SCM_DEMO_CROSS",
    "sql": "SELECT YM, PLANT_CD, VENDOR_CD, SUM(ORDER_QTY) FROM ... GROUP BY 1,2,3",
    "raw_data": [
        {"YM": "2026-04", "PLANT_CD": "P100", "VENDOR_CD": "V01", "ORDER_QTY": 700},
        {"YM": "2026-04", "PLANT_CD": "P100", "VENDOR_CD": "V02", "ORDER_QTY": 800},
        {"YM": "2026-04", "PLANT_CD": "P200", "VENDOR_CD": "V01", "ORDER_QTY": 500},
        {"YM": "2026-05", "PLANT_CD": "P100", "VENDOR_CD": "V01", "ORDER_QTY": 900},
        {"YM": "2026-05", "PLANT_CD": "P100", "VENDOR_CD": "V02", "ORDER_QTY": 600},
        {"YM": "2026-05", "PLANT_CD": "P200", "VENDOR_CD": "V01", "ORDER_QTY": 1300},
    ],
}

# 3) empty 경로 — 행 수 0 -> classify에서 바로 assemble
EMPTY_PAYLOAD = {
    "screen_id": "SCM_DEMO_TIMESERIES",
    "sql": "SELECT ... WHERE 1=0",
    "raw_data": [],
}

# 4) degrade 경로 — 화면별 Semantic Layer가 없는 screen_id
#    공통 계층만으로 진행되며, semantic_role을 몰라 detail_table로 fallback 한다.
UNKNOWN_SCREEN_PAYLOAD = {
    "screen_id": "SCM_UNKNOWN_9999",
    "sql": "SELECT * FROM SOME_TABLE",
    "raw_data": [
        {"COL_A": "a1", "COL_B": 10},
        {"COL_A": "a2", "COL_B": 20},
    ],
}

# 5) 오류 경로 — screen_id 누락 -> ingest에서 바로 assemble
INVALID_PAYLOAD = {
    "sql": "SELECT 1",
    "raw_data": [],
}

ALL_PAYLOADS = {
    "time_series": TIME_SERIES_PAYLOAD,
    "cross": CROSS_PAYLOAD,
    "empty": EMPTY_PAYLOAD,
    "unknown_screen": UNKNOWN_SCREEN_PAYLOAD,
    "invalid": INVALID_PAYLOAD,
}
