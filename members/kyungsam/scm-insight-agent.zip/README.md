# 대화형 SCM 데이터 분석 Agent — LangGraph 스켈레톤

2주차 산출물 **부록 A(확정 Spec)** 대로 만든 구현체입니다.

- **1단계 (완료)** — 8노드 스켈레톤. 각 노드는 스텁이고, 더미 데이터로 end-to-end가 통과합니다.
- **2단계 (완료)** — Vega-Lite MCP 연동. `save_data` → `visualize_data` stdio 왕복 확인.

매주 한 노드씩 살을 붙여 나갑니다.

---

## 1. 빠른 실행

```bash
# 1) 가상환경
python -m venv .venv
.venv\Scripts\activate          # Windows
# source .venv/bin/activate      # macOS / Linux

# 2) 의존성
pip install -r requirements.txt

# 3) 전체 경로 실행 (5가지 경로를 순서대로)
python run_demo.py

# 특정 경로만
python run_demo.py time_series
python run_demo.py cross
python run_demo.py empty
python run_demo.py unknown_screen
python run_demo.py invalid

# 그래프 구조를 Mermaid로 출력
python run_demo.py --mermaid

# 스모크 테스트
pytest -v

# [2단계] Vega-Lite MCP 연동 테스트 (서버 설치 후)
python run_mcp_test.py
python run_demo.py --mcp time_series
```

LLM API 키는 필요 없습니다. 지금까지는 LLM을 한 번도 호출하지 않습니다
(`scm_agent/config.py`의 `USE_LLM = False`).

### 1.1 Windows에서 겪을 수 있는 인코딩 문제

한국어 Windows의 기본 문자 인코딩은 **cp949**입니다. UTF-8로 저장된 파일을 도구가
cp949로 읽으려다 실패하는 일이 있어, 이 프로젝트는 아래와 같이 대비해 두었습니다.

| 증상 | 원인 | 이 프로젝트의 대응 |
|---|---|---|
| `pip install -r requirements.txt` 가 `UnicodeDecodeError: 'cp949' codec can't decode...` 로 죽음 | pip이 requirements.txt를 시스템 코드페이지로 읽는데 파일에 한글 주석이 있었음 | **`requirements.txt`와 `pytest.ini`는 영문(ASCII)으로만 작성**합니다. 한글 설명은 이 README에 둡니다 |
| 실행 도중 `UnicodeEncodeError` 로 멈춤 | 콘솔이 cp949라서 cp949에 없는 문자(예: 긴 대시 `—`)를 출력할 수 없음 | 화면에 찍는 문자열에서 그런 문자를 뺐고, `run_demo.py`/`run_mcp_test.py` 첫머리에서 `sys.stdout.reconfigure(errors="replace")` 로 한 번 더 막아 둡니다 |
| 로그 파일의 한글이 깨져 보임 | `>` 리다이렉트도 콘솔 인코딩을 따라감 | 필요하면 `python run_demo.py 2>&1 | Out-File -Encoding utf8 logs\run.log` 처럼 인코딩을 지정하세요 |

파이썬 소스(.py)와 YAML은 항상 UTF-8로 읽고 씁니다(`encoding="utf-8"` 명시). 그대로 두시면 됩니다.

**앞으로 파일을 추가할 때 기억할 규칙 하나** — 도구가 읽는 설정 파일(`requirements.txt`,
`pytest.ini`, `.env` 등)에는 한글을 쓰지 마세요. 코드와 문서에는 마음껏 쓰셔도 됩니다.

---

## 2. 폴더 구조

```
scm-insight-agent/
├── run_demo.py                       1단계 실행 진입점 (--mcp 로 2단계 연동 포함)
├── run_mcp_test.py                   2단계 Vega-Lite MCP 연동 테스트
├── requirements.txt
├── pytest.ini
│
├── scm_agent/
│   ├── state.py                      부록 A.1 State 스키마
│   ├── config.py                     임계값(K/R/조합 30) · 경로 상수
│   ├── graph.py                      8노드 조립 + 부록 A.5 조건부 엣지
│   ├── templates.py                  문장 템플릿 (사용자에게 보이는 문장은 전부 여기)
│   │
│   ├── nodes/                        ★ 노드마다 파일 1개 (매주 하나씩 채움)
│   │   ├── ingest.py                 1. 페이로드 수신 · 필수 필드 확인
│   │   ├── resolve_semantic_layer.py 2. 공통+화면별 Semantic Layer 조합  (W5)
│   │   ├── profile.py                3. pandas 통계 프로파일
│   │   ├── classify_screen_type.py   4. 화면 구조 유형 판정 (부록 A.3)
│   │   ├── plan_analysis.py          5. 분석 후보 탐색 (rule | llm=ReAct)  (W3)
│   │   ├── compute_facts.py          6. 사실 확정 — LLM 절대 금지 구역
│   │   ├── present.py                7. 표현 결정 (차트 타입 + 템플릿 문장)
│   │   └── assemble.py               8. 최종 응답 조립
│   │
│   ├── planners/
│   │   ├── rule_planner.py           유형별 고정 후보
│   │   └── llm_planner.py            ReAct 한 반복 (지금은 스텁)      (W3)
│   │
│   ├── semantic/
│   │   ├── loader.py                 ★ 공통+화면별 YAML 로드·병합 (완성됨)
│   │   └── builder_stub.py           오프라인 빌더 스텁               (W6)
│   │
│   └── chart/
│       ├── spec.py                   중립 차트 스펙 (Pydantic 검증)
│       ├── vegalite_adapter.py       중립 → Vega-Lite 변환 + MCP 호출     (2단계)
│       └── mcp_client.py             stdio 세션 관리 · 도구 2개 호출      (2단계)
│
├── semantic_layer/
│   ├── common.yaml                   공통 계층 (지표·제품속성은 [TBD])
│   └── screens/
│       ├── SCM_DEMO_TIMESERIES.yaml  데모 화면 1 (시계열)
│       └── SCM_DEMO_CROSS.yaml       데모 화면 2 (교차 → llm_planner 분기)
│
├── data/dummy_payloads.py            더미 페이로드 5종
├── tests/
│   ├── test_graph_smoke.py           1단계 스모크 테스트 10개
│   └── test_vegalite_mcp.py          2단계 MCP 연동 테스트 14개
├── docs/
│   ├── graph.mmd                     그래프 구조 (Mermaid)
│   ├── vegalite_sample.png           MCP 서버가 렌더한 PNG (2단계 증적)
│   └── vegalite_sample_spec.json     완결 Vega-Lite 스펙 (프론트 직접 렌더용)
└── logs/                             실행·테스트 로그
```

---

## 3. 파이프라인 (부록 A.2 · A.5)

```
ingest
  → resolve_semantic_layer
  → profile
  → classify_screen_type ─┬→ plan_analysis ⟲(ReAct, 상한 R) → compute_facts → present ⟲(1회 재시도) → assemble
                          ├→ present (detail_table: 표만)
                          └→ assemble (empty)
```

조건부 엣지 4곳이 부록 A.5 그대로 들어가 있습니다.

| 분기 | 위치 | 내용 |
|---|---|---|
| ingest 실패 | `route_after_ingest` | 필수 필드 누락 시 즉시 assemble |
| classify 3분기 | `route_after_classify` | plan_analysis / present(표만) / assemble(empty) |
| ReAct 자기 순환 | `route_after_plan_analysis` | `need_more_react`가 True면 plan_analysis로 복귀 (상한 R=2) |
| present 재시도 | `route_after_present` | 스펙 검증 실패 시 1회 재시도 → 재실패면 table degrade |

**ReAct 루프를 노드 안의 for 문이 아니라 그래프의 자기 순환 엣지로 만든 이유**
매 반복이 State에 남고 LangGraph 스트림에서 눈으로 보이기 때문입니다.
그래서 `llm_planner.plan_with_llm()`은 "한 번의 반복"만 수행하고 돌아갑니다.

---

## 4. 지금 채워진 것 / 비어 있는 것

| 모듈 | 상태 |
|---|---|
| `semantic/loader.py` | **완성** — 공통+화면별 YAML 로드·병합, entity/role/unit resolve |
| `graph.py`, `state.py` | **완성** — 8노드 + 조건부 엣지 + degrade 경로 |
| `ingest` / `assemble` | 동작 (실제 스키마는 프론트 확정 후 조정) |
| `profile` | 최소 통계만 (유형 판정에 필요한 만큼) |
| `classify_screen_type` | 부록 A.3 규칙 판정 동작. 임계값은 첫 화면에서 캘리브레이션 |
| `plan_analysis` / `rule_planner` | 유형별 고정 후보 생성. 점수화·전수 실행은 [TBD] |
| `llm_planner` | **완전 스텁** — LLM 호출 없음. W3에서 교체 |
| `compute_facts` | 합계 / 추세 / 기간 증감 / 범주 비교 4종만 |
| `present` | 부록 A.4 규칙 + 템플릿 문장 렌더 + MCP 호출 동작 |
| `chart/vegalite_adapter.py`, `chart/mcp_client.py` | **완성** — Vega-Lite MCP 연동 (2단계) |
| `semantic_layer/*.yaml` | **뼈대만** — 실제 지표·제품속성은 `[TBD]` 주석 자리에 다음 주 회사 자료로 채움 |
| `semantic/builder_stub.py` | 함수 뼈대만 (W6) |

`[TBD]`로 검색하면 채워야 할 자리가 전부 나옵니다.

---

## 5. 구현 규약 (2주차 산출물 2.3절)

이 코드는 아래 규약을 따릅니다. 이어서 작업할 때도 유지해 주세요.

- **초보자 가독성 우선.** 람다·컴프리헨션 남용·난해한 문법을 쓰지 않습니다. `for` 문으로 풀어 씁니다.
- **한글 주석을 충실히.** 모든 파일 맨 위에 그 파일이 무엇인지, 지금 어디까지 됐는지, 다음에 뭘 할지 적습니다.
- **노드는 작고 독립적으로.** 파일 하나만 열어 고치면 되도록 합니다.
- **Constitution 준수.**
  - LLM은 사실을 생성하지 않습니다. 수치·비교·인과는 전부 `compute_facts.py`에서 나옵니다.
  - 문장은 `templates.py`가 옮깁니다. LLM이 문장을 쓰지 않습니다.
  - 원본 데이터(`raw_data`)는 LLM에 넣지 않습니다 (`llm_planner.build_llm_payload` 참고).
  - 표현 결정은 파이프라인 **마지막**(`present`)에서 합니다.

---

## 6. Vega-Lite MCP 연동 (2단계)

### 6.1 서버 설치

PyPI에 없어 GitHub에서 직접 설치합니다. (`vl-convert-python`이 함께 깔립니다)

```bash
pip install git+https://github.com/isaacwasserman/mcp-vegalite-server.git
mcp_server_vegalite --help      # 설치 확인
```

서버가 없어도 파이프라인은 그대로 돕니다. MCP 호출만 건너뛰고 `chart_render`가 `null`이 됩니다.

### 6.2 켜고 끄기

```python
# scm_agent/config.py
USE_VEGALITE_MCP = False          # 기본값. True로 두면 항상 호출한다
VEGALITE_MCP_OUTPUT_TYPE = "text" # "text"(2주차 확정) | "png"(렌더 확인용)
```

코드를 고치지 않고 켜려면 `python run_demo.py --mcp` 로 실행합니다.

### 6.3 호출 흐름

```
present (line/bar일 때만)
  → vegalite_adapter.call_vegalite_mcp(중립 스펙)
      ├ to_data_rows()          데이터 행 목록  ─┐
      └ to_vegalite_encoding()  인코딩만 (데이터 없음)
  → mcp_client.render_chart()
      stdio로 서버 프로세스 기동
      ├ save_data(name, data)                 ← 수치는 여기서만 이동
      └ visualize_data(data_name, spec 문자열) ← 인코딩만 전달
  → 결과를 State.chart_render 에 담고 응답에 요약해서 포함
```

**왜 도구가 2개로 나뉘어 있는가.** `save_data`로 데이터를 먼저 서버에 올려 두고
`visualize_data`에는 데이터 이름과 인코딩만 넘깁니다. 수치가 스펙 문자열에 섞이지 않으므로,
나중에 이 자리에 LLM을 붙여도 LLM은 인코딩만 만지게 됩니다.
`사실은 코드, LLM은 표현`이라는 원칙과 구조가 그대로 맞아떨어집니다.

### 6.4 연동하면서 확인한 것 (다음 사람이 헤매지 않도록)

| 항목 | 내용 |
|---|---|
| 실행 인자 | 저장소 README에는 `--output_type`으로 적혀 있으나 실제 코드는 **`--output-type`**(하이픈)입니다 |
| 실행 파일 이름 | README 예시의 `mcp_server_datavis`가 아니라 **`mcp_server_vegalite`** 입니다 |
| 작업 디렉터리 | 서버가 `logs/mcp_vegalite_server.log`에 로그를 남깁니다. **`logs/` 폴더가 있는 곳에서 띄워야** 서버가 뜹니다 (`config.VEGALITE_MCP_CWD`) |
| 세션 | `save_data`와 `visualize_data`는 **같은 세션 안에서** 불러야 합니다. 서버가 데이터를 그 프로세스 메모리에 들고 있습니다 |
| 스펙 문자열 | 서버가 받은 문자열을 파이썬 `eval()`로 해석합니다. JSON의 `true/false/null`이 있으면 깨지므로 `to_specification_string()`이 파이썬 리터럴 표기로 바꿔 보냅니다 |
| data 필드 | `visualize_data`에 넘기는 스펙에는 **`data`를 넣으면 안 됩니다**. 서버가 붙여 줍니다 |
| 크기 | `width`/`height`를 지정하지 않으면 그림이 지나치게 좁게 렌더됩니다 |

### 6.5 실패해도 응답은 나갑니다

MCP 호출이 실패하면(서버 미설치·타임아웃·오류) 예외를 던지지 않고 `ok=False`로 돌려줍니다.
중립 차트 스펙과 템플릿 문장은 이미 만들어져 있으므로 응답은 그대로 나가고,
`status`만 `degraded`가 되며 `validation_errors`에 사유가 남습니다. (Constitution: 장애 격리)

---

## 7. 다음 단계

**이후 주차**

- W3 — `llm_planner.py`의 3개 함수를 실제 LLM 호출로 교체 (구조화 출력 + 컬럼 존재 검증)
- W5 — `resolve_semantic_layer`를 screen_id 완전 일치에서 유사 화면 검색으로 확장
- W6 — `builder_stub.py`를 실제 오프라인 빌더로 구현, Skill 패턴으로 조직
- W7 — 골든셋·평가·임계값(저카디널리티 경계 / llm 전환 임계 / K / R) 캘리브레이션
- W7 — 표현 개선 루프 검토: png 모드로 받은 렌더 결과를 관찰 신호로 쓰는 방안 (2주차 산출물 8장 열린 질문)
