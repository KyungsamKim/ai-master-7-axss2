# 형상관리(Git) 가이드 — 초보자용

이 프로젝트를 매주 이어서 개발할 때 쓸 형상관리 방법입니다.
AI 코딩(Cowork 등)으로 코드를 받더라도, **버전을 남기는 일은 사람이** 합니다.
그래야 "지난주 잘 되던 상태로 되돌리기", "무엇이 언제 바뀌었는지 보기"가 가능합니다.

---

## 0. git이 필요한 이유 (한 문장)

git은 코드의 "저장 지점(commit)"을 시간순으로 쌓아 두는 도구입니다.
매주 한 노드씩 채워 나가는 이 프로젝트에 특히 잘 맞습니다 — 주차마다 저장 지점을 찍으면
언제든 그 주의 상태로 되돌아갈 수 있습니다.

---

## 1. 처음 한 번만 (최초 설정)

PowerShell에서 프로젝트 폴더로 이동한 뒤:

```powershell
cd D:\Users\kyung\OneDrive\Desktop\VibeCoding\ai-master\scm-insight-agent

# 내 이름·이메일 등록 (처음 한 번, 전역 설정)
git config --global user.name "Kyungsam Kim"
git config --global user.email "rudtka12@gmail.com"

# 저장소 시작
git init
git add .
git commit -m "2주차: LangGraph 스켈레톤 + Vega-Lite MCP 연동"
```

이제 이 폴더는 git 저장소가 되었습니다.

---

## 2. ★ OneDrive 주의 (중요)

지금 프로젝트가 **OneDrive 폴더 안**에 있습니다
(`...\OneDrive\Desktop\VibeCoding\...`). 여기엔 함정이 있습니다.

OneDrive는 폴더 안 파일을 실시간으로 클라우드에 동기화합니다. 그런데 git이
`.git` 폴더 안에서 수많은 작은 파일을 빠르게 만들고 지웁니다. 둘이 동시에 같은
파일을 건드리면 **저장소가 깨지거나("`.git` corrupt"), 충돌 파일이 생길 수** 있습니다.

권장 순서(안전한 것부터):

1. **가장 안전** — 프로젝트를 OneDrive 밖으로 옮긴다. 예: `D:\dev\scm-insight-agent`.
   백업은 아래 4번의 GitHub push가 대신해 줍니다(OneDrive 백업이 필요 없어짐).
2. **차선** — OneDrive 밖으로 옮기기 어렵다면, 커밋·push 하는 잠깐만 OneDrive 동기화를
   일시 중지(작업 표시줄 OneDrive 아이콘 → 동기화 일시 중지)한 뒤 git 작업을 한다.
3. 그대로 쓰더라도 최소한 GitHub(4번)에 올려 두면, OneDrive가 저장소를 깨뜨려도
   원격에서 되살릴 수 있습니다.

---

## 3. 매주 반복하는 흐름

한 주 작업(예: W3에서 `llm_planner` 채우기)이 끝날 때마다:

```powershell
# 무엇이 바뀌었는지 본다
git status

# 바뀐 것을 모두 담는다
git add .

# 저장 지점을 찍는다 (메시지는 "무엇을 했는지" 한 줄)
git commit -m "W3: llm_planner ReAct 실제 LLM 호출로 교체"

# 원격(GitHub)에 올린다 (4번 설정 후)
git push
```

**커밋 단위 요령** — "한 가지 일 = 한 커밋"이 이상적입니다. 이 프로젝트는 노드가
파일로 분리돼 있으니 "노드 하나를 채우면 한 커밋"이 자연스럽습니다. 잘 되던 상태에서
자주 찍어 두세요. 커밋은 많을수록 되돌리기 쉽습니다.

**좋은 커밋 메시지 예**
- `W3: llm_planner를 OpenAI 호출로 교체, 컬럼 존재 검증 추가`
- `compute_facts: 이상치 탐지 후보 추가`
- `fix: cross 화면에서 후보가 비던 문제 수정`

---

## 4. GitHub에 올리기 (백업·이력·공유)

### 4.1 저장소 만들기 — GitHub CLI가 가장 쉽습니다

```powershell
# GitHub CLI 설치 (한 번만). 설치 후 PowerShell 새로 열기
winget install --id GitHub.cli

# 로그인 (브라우저가 열립니다)
gh auth login

# 현재 폴더를 private 저장소로 올리기 (한 방에 생성 + 연결 + push)
gh repo create scm-insight-agent --private --source . --remote origin --push
```

### 4.2 CLI 없이 웹으로 하려면

1. github.com에서 **New repository** → 이름 `scm-insight-agent`, **Private** 선택,
   README/gitignore는 추가하지 않음(이미 있으므로) → Create.
2. 만들어진 페이지의 명령을 그대로 복사해 실행:

```powershell
git remote add origin https://github.com/<내계정>/scm-insight-agent.git
git branch -M main
git push -u origin main
```

이후로는 `git push` 만으로 올라갑니다. 비밀번호 대신 **개인 액세스 토큰(PAT)** 을
물어보면, GitHub → Settings → Developer settings → Personal access tokens에서
발급해 붙여 넣습니다(한 번 넣으면 Windows 자격증명 관리자가 기억합니다).

---

## 5. 주차별 제출 지점 표시 (태그)

과제 제출처럼 "이 시점"을 딱 집어 두고 싶을 때 태그를 씁니다.

```powershell
git tag -a week2 -m "2주차 제출: 스켈레톤 + MCP 연동"
git push origin week2
```

나중에 `git checkout week2` 로 그 시점 상태를 그대로 볼 수 있습니다.

---

## 6. 브랜치 전략 (지금은 단순하게)

혼자 학습하는 단계에서는 복잡한 전략이 오히려 방해가 됩니다. 이렇게 시작하세요.

- 평소에는 `main` 한 곳에서 작업하고 매주 커밋한다.
- 큰 변경(예: W3에서 llm_planner를 실험적으로 바꿔 볼 때)만 주차 브랜치를 딴다:

```powershell
git switch -c week3-llm-planner   # 새 브랜치에서 실험
# ... 작업 & 커밋 ...
git switch main                   # 잘 되면 main으로 돌아와서
git merge week3-llm-planner       # 병합
```

실험이 실패하면 그 브랜치를 버리면 되니 `main`은 항상 "돌아가는 상태"로 남습니다.
이건 1단계에서 강조한 "START→END가 항상 도는 상태를 유지" 원칙과 같은 결입니다.

---

## 7. AI 코딩과 함께 쓸 때의 습관

- **AI에게 코드를 받기 전에 먼저 커밋**해 두세요. 결과가 마음에 안 들면
  `git restore .` 또는 `git checkout .` 으로 즉시 되돌립니다.
- AI가 만든 변경은 `git diff` 로 **직접 읽고** 커밋하세요. 무엇이 바뀌었는지
  이해하고 넘어가는 것이 학습 목적(이 프로젝트의 1번 목표)에도 맞습니다.
- 커밋 메시지에 "누가/무엇을"보다 "왜"를 남기면 나중에 큰 도움이 됩니다.

---

## 8. 자주 쓰는 명령 요약

| 하고 싶은 것 | 명령 |
|---|---|
| 지금 상태 보기 | `git status` |
| 바뀐 내용 보기 | `git diff` |
| 저장 지점 찍기 | `git add .` → `git commit -m "메시지"` |
| 원격에 올리기 | `git push` |
| 이력 보기 | `git log --oneline` |
| 마지막 커밋 이후 변경 되돌리기 | `git restore .` |
| 특정 시점 보기 | `git checkout <커밋해시 또는 태그>` |
| 다시 최신으로 | `git switch main` |
