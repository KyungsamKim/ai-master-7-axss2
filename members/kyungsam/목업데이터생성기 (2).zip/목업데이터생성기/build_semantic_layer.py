# -*- coding: utf-8 -*-
"""
build_semantic_layer.py
-----------------------
DDL(컬럼·코멘트) + 엑셀(제품 속성·비중) 로부터 2계층 Semantic Layer YAML 을 만든다.

산출물
  semantic_layer/common.yaml                      공통 계층 (업무 객체·어휘·규약)
  semantic_layer/screens/SCR_PMO_PROFBLT_PROD.yaml 화면별 계층 (컬럼 바인딩)

이 파일은 2주차 산출물 5.1 의 '오프라인 빌더' 스텁 자리에 해당한다.
지금은 규칙 기반으로 채우고, W6 에서 SQL Set 분석까지 확장한다.
"""

import os
import re
from collections import OrderedDict

import yaml

import mock_config as C
import build_core as B

OUT_DIR = os.path.join(C.OUT_DIR, "semantic_layer")
SCREEN_ID = "SCR_PMO_PROFBLT_PROD"

# 단위 스케일(접두사) -> 해당 스케일의 수량 컬럼
SCALE_QTY = {
    "WF": "WF_CONV_QTY",
    "EQ": "SOM_EQ_QTY",
    "DIE": "SOM_DIE_QTY",
    "PROD": "SALE_QTY",
}
SCALE_LABEL = {"WF": "웨이퍼", "EQ": "EQ(1Gb 환산)", "DIE": "DIE", "PROD": "제품", "YR": "연간"}
TIER_LABEL = {"VAR": "변동", "CASH": "현금", "COGS": "COGS", "COO": "COO"}


# ---------------------------------------------------------------------------
# YAML 출력 시 한글이 깨지지 않고, dict 순서가 유지되도록 설정
# ---------------------------------------------------------------------------
def represent_ordered_dict(dumper, data):
    return dumper.represent_mapping("tag:yaml.org,2002:map", data.items())


yaml.add_representer(OrderedDict, represent_ordered_dict)


def dump(obj, path, header):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(header)
        yaml.dump(obj, f, allow_unicode=True, sort_keys=False, width=100)
    return path


# ---------------------------------------------------------------------------
# 입력 파싱
# ---------------------------------------------------------------------------
def load_ddl():
    src = open(C.DDL_PATH, encoding="utf-8").read()
    start = src.index('CREATE TABLE "RPLS_ADM"')
    end = src.index("CONSTRAINT", start)
    cols = re.findall(
        r'"([A-Z0-9_]+)"\s+(VARCHAR2\(\d+\)|NUMBER\(\d+,\d+\)|DATE)', src[start:end])
    labels = dict(re.findall(
        r"COMMENT ON COLUMN\s+\S+\.(\w+)\s+IS\s+'([^']+)'", src))
    return [c for c, _ in cols], dict(cols), labels


# ---------------------------------------------------------------------------
# 공통 계층
# ---------------------------------------------------------------------------
def build_common(attrs, share):
    def codes_of(col, newer_when):
        items = OrderedDict()
        seqs = B.code_list(attrs, col)
        w_amt = B.weight_map(share, col, "w_amt")
        for code, seq in seqs.items():
            entry = OrderedDict()
            entry["seq"] = seq
            if code in w_amt:
                entry["sales_share"] = round(w_amt[code], 4)
            else:
                entry["sales_share"] = 0.0
            items[str(code)] = entry
        return OrderedDict([("newer_when", newer_when), ("values", items)])

    common = OrderedDict()
    common["version"] = "1.0"
    common["description"] = "전 화면 공통 Semantic Layer. 업무 객체 어휘와 집계 규약을 정의한다."

    common["semantic_roles"] = OrderedDict([
        ("time", "기간 축. 시계열 분석의 x축 후보"),
        ("dimension", "분류 축. 카테고리 비교·기여도 분석의 기준"),
        ("measure", "집계 대상 수치"),
        ("attribute", "객체 속성. 집계 대상이 아니다"),
        ("identifier", "식별자. 집계 부적합, 표 표시 전용"),
    ])

    common["aggregation_rules"] = OrderedDict([
        ("sum", "단순 합산 가능"),
        ("weighted_avg", "가중 평균만 유효. weight 컬럼으로 가중한다. 단순 평균은 오답"),
        ("derived", "합산·평균 모두 불가. formula 로 재계산해야 한다"),
        ("first", "그레인이 달라 행마다 반복되는 값. 그룹 내 대표값 1건만 사용(합산하면 중복 계상)"),
    ])

    common["units"] = OrderedDict([
        ("KRW", "원"),
        ("EA", "개"),
        ("WAFER", "매"),
        ("DIE", "개"),
        ("GB_EQ", "1Gb 환산 수량"),
        ("RATIO", "비율(0~1). 표시 시 100 을 곱한다"),
    ])

    common["entities"] = OrderedDict([
        ("product", OrderedDict([
            ("label", "제품"),
            ("description", "SCM 제품 속성 조합. 아래 6개 속성이 제품을 식별한다"),
            ("attributes", OrderedDict([
                ("scm_family", OrderedDict([
                    ("label", "SCM패밀리"), ("column", "SCM_FAMILY_CD"),
                    ("values", OrderedDict([("DRAM", OrderedDict([("seq", None)]))])),
                ])),
                ("tech", OrderedDict([("label", "테크"), ("column", "TECH_CD")] +
                                     list(codes_of("TECH_CD", "seq_lower").items()))),
                ("fab_density", OrderedDict(
                    [("label", "FAB Density"), ("column", "FAB_DEN_CD"),
                     ("note", "코드의 숫자가 곧 Gb 용량이다. SOM_EQ_QTY = SOM_DIE_QTY x Density")] +
                    list(codes_of("FAB_DEN_CD", "seq_lower").items()))),
                ("prod_mode", OrderedDict(
                    [("label", "제품모드"), ("column", "CHG_PROD_MODE_CD"),
                     ("families", ["DDR", "LPDDR", "GDDR", "HBM", "ULP"]),
                     ("note", "계열(DDR/LPDDR/GDDR/HBM) 안에서는 이름의 숫자가 클수록 최신이다. "
                              "계열이 다르면 seq 순서가 최신 순서를 뜻하지 않는다")] +
                    list(codes_of("CHG_PROD_MODE_CD", "name_number_higher").items()))),
                ("prod_version", OrderedDict(
                    [("label", "제품버전"), ("column", "SCM_PROD_VER_CD")] +
                    list(codes_of("SCM_PROD_VER_CD", "seq_lower").items()))),
                ("application", OrderedDict(
                    [("label", "어플리케이션"), ("column", "APP_LVL_1_CD")] +
                    list(codes_of("APP_LVL_1_CD", "seq_lower").items()))),
            ])),
        ])),
        ("period", OrderedDict([
            ("label", "기간"),
            ("grains", OrderedDict([
                ("month", OrderedDict([("column", "TGT_YM"), ("format", "yyyymm")])),
                ("quarter", OrderedDict([("column", "TGT_QUTR"), ("format", "yyyyQQ")])),
                ("half", OrderedDict([("column", "TGT_HALF"), ("format", "yyyyHH")])),
                ("year", OrderedDict([("column", "TGT_YEAR"), ("format", "yyyy")])),
            ])),
            ("grain_selector", "PRID_GBN_CD"),
            ("note", "네 컬럼은 서로 다른 행이 아니라 같은 행의 파생 축이다. "
                     "합산 시 하나의 축만 골라 써야 중복 계상되지 않는다"),
        ])),
        ("plan", OrderedDict([
            ("label", "계획"),
            ("attributes", OrderedDict([
                ("revision", OrderedDict([("label", "계획리비전"), ("column", "PLN_REV")])),
                ("year_week", OrderedDict([("label", "계획년주차"), ("column", "PLN_YW")])),
                ("data_type", OrderedDict([("label", "데이터구분"), ("column", "DATA_GBN_CD")])),
            ])),
        ])),
    ])

    common["measure_model"] = OrderedDict([
        ("description", "수익성 지표는 '단위 스케일 x 원가 계층' 의 격자로 구성된다"),
        ("unit_scales", OrderedDict([
            ("WF", OrderedDict([("label", "웨이퍼"), ("qty_column", "WF_CONV_QTY")])),
            ("EQ", OrderedDict([("label", "EQ(1Gb 환산)"), ("qty_column", "SOM_EQ_QTY")])),
            ("DIE", OrderedDict([("label", "DIE"), ("qty_column", "SOM_DIE_QTY")])),
            ("PROD", OrderedDict([("label", "제품"), ("qty_column", "SALE_QTY")])),
            ("YR", OrderedDict([("label", "연간(절대금액)"), ("qty_column", None)])),
        ])),
        ("cost_tiers", OrderedDict([
            ("VAR", "변동원가. 가장 좁은 원가"),
            ("CASH", "현금원가"),
            ("COGS", "매출원가"),
            ("COO", "COO 원가. 가장 넓은 원가"),
        ])),
        ("identities", [
            "*_PROF_AMT = *_SALE_AMT - *_COST  (5개 스케일 x 4개 계층 전부 성립)",
            "SOM_EQ_QTY = SOM_DIE_QTY x Density(Gb)",
            "SOM_DIE_QTY = WF_CONV_QTY x NET_DIE_300_CNT x CUM2_YLD",
            "ASP_AMT = EQ_SALE_AMT = SALE_AMT / SOM_EQ_QTY",
            "일반적으로 VAR <= CASH <= COGS <= COO (원가가 음수인 행에서는 부호가 뒤집힌다)",
        ]),
    ])

    common["business_terms"] = OrderedDict([
        ("영업이익률", "SALES_PROF_RATE. COO 원가 기준 이익 / 판매금액"),
        ("ASP", "1Gb 환산 단가. 제품 단가가 아니라 용량당 단가다"),
        ("기여도", "특정 분류의 값 / 전체 값"),
        ("증감", "직전 기간 대비 차이. 증감률은 직전 기간 대비 비율"),
    ])
    return common


# ---------------------------------------------------------------------------
# 화면별 계층
# ---------------------------------------------------------------------------
def classify_column(name, dtype, labels):
    """컬럼 1개의 semantic_role / 집계 규약을 정한다."""
    entry = OrderedDict()
    entry["label"] = labels.get(name, name)

    # --- 기간 축 ---
    if name in ("TGT_YM", "TGT_QUTR", "TGT_HALF", "TGT_YEAR"):
        entry["dtype"] = "string"
        entry["semantic_role"] = "time"
        entry["entity"] = "period." + {"TGT_YM": "month", "TGT_QUTR": "quarter",
                                       "TGT_HALF": "half", "TGT_YEAR": "year"}[name]
        entry["aggregation"] = "group_by"
        return entry

    # --- 제품 속성 축 ---
    product_map = {
        "SCM_FAMILY_CD": "product.scm_family", "TECH_CD": "product.tech",
        "FAB_DEN_CD": "product.fab_density", "CHG_PROD_MODE_CD": "product.prod_mode",
        "SCM_PROD_VER_CD": "product.prod_version", "APP_LVL_1_CD": "product.application",
    }
    if name in product_map:
        entry["dtype"] = "string"
        entry["semantic_role"] = "dimension"
        entry["entity"] = product_map[name]
        entry["aggregation"] = "group_by"
        return entry

    # --- 계획 / 기타 코드 축 ---
    if dtype.startswith("VARCHAR2") or dtype == "DATE":
        entry["dtype"] = "date" if dtype == "DATE" else "string"
        if name in ("PLN_REV", "PLN_YW", "DATA_GBN_CD", "PRID_GBN_CD"):
            entry["semantic_role"] = "dimension"
            entry["aggregation"] = "group_by"
        else:
            entry["semantic_role"] = "identifier"
            entry["aggregation"] = "none"
        if name in ("CELL_LAYER_TYP_CD", "UPPER_CD", "SSD_CLAS_NM", "DATA_GBN_CD"):
            entry["note"] = "DRAM 대상 자료에 값 정의가 없어 공백(' ')이다. 분석 축으로 쓰지 않는다"
            entry["active"] = False
        return entry

    # --- 수치 ---
    entry["dtype"] = "number"
    entry["semantic_role"] = "measure"

    if name in ("WF_CONV_QTY", "SOM_EQ_QTY", "SOM_DIE_QTY", "ORG_QTY", "SALE_QTY"):
        entry["unit"] = {"WF_CONV_QTY": "WAFER", "SOM_EQ_QTY": "GB_EQ",
                         "SOM_DIE_QTY": "DIE"}.get(name, "EA")
        entry["aggregation"] = "sum"
        entry["format"] = "#,##0"
        return entry

    if name == "SALE_AMT":
        entry["unit"] = "KRW"
        entry["aggregation"] = "sum"
        entry["format"] = "#,##0"
        entry["primary"] = True
        return entry

    if name == "ASP_AMT":
        entry["unit"] = "KRW"
        entry["aggregation"] = "derived"
        entry["formula"] = "SALE_AMT / SOM_EQ_QTY"
        entry["format"] = "#,##0.00"
        return entry

    if name == "SALES_PROF_RATE":
        entry["unit"] = "RATIO"
        entry["aggregation"] = "weighted_avg"
        entry["weight"] = "SALE_AMT"
        entry["format"] = "0.0%"
        entry["primary"] = True
        return entry

    if name == "YR_SALES_PROF_RATE":
        entry["unit"] = "RATIO"
        entry["aggregation"] = "first"
        entry["grain"] = "year"
        entry["format"] = "0.0%"
        return entry

    if name == "NET_DIE_300_CNT":
        entry["unit"] = "DIE"
        entry["semantic_role"] = "attribute"
        entry["aggregation"] = "derived"
        entry["formula"] = "SOM_DIE_QTY / (WF_CONV_QTY * CUM2_YLD)"
        return entry

    if name == "CUM2_YLD":
        entry["unit"] = "RATIO"
        entry["semantic_role"] = "attribute"
        entry["aggregation"] = "derived"
        entry["formula"] = "SOM_DIE_QTY / (WF_CONV_QTY * NET_DIE_300_CNT)"
        entry["format"] = "0.0%"
        return entry

    # --- 스케일 x 계층 격자 ---
    match = re.match(r"^(WF|EQ|DIE|PROD|YR)_(?:(VAR|CASH|COGS|COO)_)?(SALE_AMT|PROF_AMT|COST)$", name)
    if match:
        scale, tier, kind = match.groups()
        entry["unit"] = "KRW"
        entry["scale"] = scale
        if tier:
            entry["cost_tier"] = tier
        entry["format"] = "#,##0" if scale == "YR" else "#,##0.00"

        if scale == "YR":
            # 연간 그레인 값이 12개월 행에 반복된다 -> 합산하면 12배가 된다
            entry["aggregation"] = "first"
            entry["grain"] = "year"
            entry["note"] = "연간 합계값이 같은 제품의 12개월 행에 동일하게 반복된다. 합산 금지"
        else:
            entry["aggregation"] = "weighted_avg"
            entry["weight"] = SCALE_QTY[scale]
            entry["note"] = f"{SCALE_LABEL[scale]} 1단위당 금액. 단순 평균은 오답이며 " \
                            f"{SCALE_QTY[scale]} 로 가중해야 한다"
        if kind == "PROF_AMT" and tier:
            entry["formula"] = f"{scale}_SALE_AMT - {scale}_{tier}_COST"
        return entry

    entry["aggregation"] = "sum"
    return entry


def build_screen(columns, coltypes, labels):
    screen = OrderedDict()
    screen["screen_id"] = SCREEN_ID
    screen["title"] = "P-Mix 결과 수익성개선 제품정보"
    screen["purpose"] = ("계획 리비전 기준으로 DRAM 제품 속성별 판매·원가·수익성 지표를 조회한다. "
                         "제품 믹스(P-Mix) 조정이 수익성에 미치는 영향을 확인하는 화면이다")
    screen["source_table"] = f"{C.TABLE_OWNER}.{C.TABLE_NAME}"
    screen["grain"] = "계획(리비전·주차) x 제품 속성 조합 x 기간(PRID_GBN_CD 가 지정한 그레인)"
    screen["row_count_hint"] = OrderedDict([
        ("typical", C.TOTAL_ROWS),
        ("note", f"월 그레인 기준. 제품 조합 {C.N_COMBO}건 x {len(C.MONTHS)}개월 "
                 f"- 신규 제품 {C.N_LATE_LAUNCH}건의 1월분 = {C.TOTAL_ROWS}행"),
    ])
    screen["default_axes"] = OrderedDict([
        ("time", "TGT_YM"),
        ("dimensions", ["CHG_PROD_MODE_CD", "TECH_CD", "APP_LVL_1_CD",
                        "FAB_DEN_CD", "SCM_PROD_VER_CD"]),
        ("primary_measures", ["SALE_AMT", "SALE_QTY", "SALES_PROF_RATE", "ASP_AMT"]),
    ])
    screen["analysis_cautions"] = [
        "YR_ 접두사 컬럼은 연간 그레인 값이 월 행에 반복된다. 월 데이터와 함께 합산하면 12배가 된다",
        "단위당 금액(WF_/EQ_/DIE_/PROD_)은 단순 평균이 아니라 해당 스케일 수량으로 가중 평균해야 한다",
        "TGT_YM / TGT_QUTR / TGT_HALF / TGT_YEAR 는 같은 행의 파생 축이다. 동시에 group by 하지 않는다",
        "값이 공백(' ')인 코드 컬럼 4개는 분석 축에서 제외한다",
        "제품모드의 최신 여부는 계열 안에서만 이름의 숫자로 비교한다(DDR5 > DDR4). "
        "계열이 다르면 seq 로 최신 여부를 판단하지 않는다",
    ]

    cols = OrderedDict()
    for name in columns:
        cols[name] = classify_column(name, coltypes[name], labels)
    screen["columns"] = cols
    return screen


def main():
    attrs, share, _ = B.load_excel()
    columns, coltypes, labels = load_ddl()

    common = build_common(attrs, share)
    screen = build_screen(columns, coltypes, labels)

    p1 = dump(common, os.path.join(OUT_DIR, "common.yaml"),
              "# 공통 Semantic Layer (2계층 중 상위)\n"
              "# 생성 : build_semantic_layer.py · 근거 : DRAM제품속성.xlsx + Report DDL\n"
              "# 검수 후 확정할 것 (2주차 산출물 5장 '오프라인 빌더 초안 -> 사람 검수')\n\n")
    p2 = dump(screen, os.path.join(OUT_DIR, "screens", f"{SCREEN_ID}.yaml"),
              f"# 화면별 Semantic Layer : {SCREEN_ID}\n"
              "# 생성 : build_semantic_layer.py · 근거 : Report DDL 컬럼·코멘트\n"
              "# 검수 후 확정할 것\n\n")

    n_measure = sum(1 for c in screen["columns"].values()
                    if c.get("semantic_role") == "measure")
    n_dim = sum(1 for c in screen["columns"].values()
                if c.get("semantic_role") == "dimension")
    print(f"공통 계층 : {p1}")
    print(f"화면 계층 : {p2}  (dimension {n_dim} · measure {n_measure} · 전체 {len(columns)})")


if __name__ == "__main__":
    main()
