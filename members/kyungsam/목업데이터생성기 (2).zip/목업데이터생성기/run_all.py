# -*- coding: utf-8 -*-
"""
run_all.py
----------
생성 -> 검증 -> 산출물 저장을 한 번에 실행한다.
"""

import os
import numpy as np
import pandas as pd

import mock_config as C
import build_core as B
import generate_mock_data as G
import make_outputs as O

PK_COLS = ["PLN_REV", "PLN_YW", "DATA_GBN_CD", "SCM_FAMILY_CD", "TECH_CD",
           "FAB_DEN_CD", "CELL_LAYER_TYP_CD", "UPPER_CD", "CHG_PROD_MODE_CD",
           "SCM_PROD_VER_CD", "APP_LVL_1_CD", "SSD_CLAS_NM", "PRID_GBN_CD",
           "TGT_YM", "TGT_QUTR", "TGT_HALF", "TGT_YEAR"]

# 월 그레인으로 합산했을 때 통계 Total 과 일치해야 하는 컬럼
MONTHLY_TOTAL_COLS = ["WF_CONV_QTY", "SOM_EQ_QTY", "SOM_DIE_QTY", "ORG_QTY",
                      "SALE_QTY", "SALE_AMT"]
# 연간 그레인(조합 1,033건) 기준으로 통계와 대조하는 컬럼
ANNUAL_COLS = ["YR_SALE_AMT", "YR_VAR_PROF_AMT", "YR_CASH_PROF_AMT",
               "YR_COO_PROF_AMT", "YR_VAR_COST", "YR_CASH_COST",
               "YR_COGS_COST", "YR_COO_COST"]


def verdict(ok):
    return "PASS" if ok else "확인필요"


def build_checks(table, annual, stats, share, columns, coltypes):
    checks = []

    def add(item, target, result, note=""):
        checks.append({"검증항목": item, "기준": target, "결과": result,
                       "판정": "", "비고": note})

    # 1) 행 수
    add("총 행 수 (규칙 4.1)", f"{C.TOTAL_ROWS:,}", f"{len(table):,}",
        "통계 Total/Avg 로 역산하면 정확히 1,033")
    checks[-1]["판정"] = verdict(len(table) == C.TOTAL_ROWS)

    add("총 행 수 범위", "1,000 ~ 1,050", f"{len(table):,}", "규칙 4.1 명시 범위")
    checks[-1]["판정"] = verdict(1000 <= len(table) <= 1050)

    n_jan_missing = C.N_COMBO * len(C.MONTHS) - len(table)
    add("행 구성", f"{C.N_COMBO}조합 x {len(C.MONTHS)}개월 - {C.N_LATE_LAUNCH}행",
        f"{len(annual):,}조합 x {len(C.MONTHS)}개월 - {n_jan_missing}행",
        "1,033 은 12 로 나누어떨어지지 않아, 최신 제품 11개는 1월 행을 만들지 않는다")
    checks[-1]["판정"] = verdict(len(annual) == C.N_COMBO and
                                n_jan_missing == C.N_LATE_LAUNCH)

    per_combo = table.groupby(PK_COLS[:12]).size()
    add("조합별 월 수", f"{len(C.MONTHS)-1} ~ {len(C.MONTHS)}개월",
        f"{per_combo.min()} ~ {per_combo.max()}개월",
        f"{int((per_combo == len(C.MONTHS)-1).sum())}개 조합이 1월 미발생")
    checks[-1]["판정"] = verdict(per_combo.max() == len(C.MONTHS) and
                                per_combo.min() >= len(C.MONTHS) - 1)

    # 2) 컬럼 / PK
    add("컬럼 수·순서", f"DDL {len(columns)}개와 동일",
        f"{len(table.columns)}개", "DDL 파싱 결과를 그대로 사용")
    checks[-1]["판정"] = verdict(list(table.columns) == columns)

    dup = int(table.duplicated(PK_COLS).sum())
    add("PK 중복", "0건", f"{dup}건", "17개 PK 컬럼 조합")
    checks[-1]["판정"] = verdict(dup == 0)

    nulls = int(table.drop(columns=["CHG_TM", "CHG_USER_ID"]).isna().sum().sum())
    add("NOT NULL 위반", "0건", f"{nulls}건", "CHG_TM/CHG_USER_ID 는 NULL 허용")
    checks[-1]["판정"] = verdict(nulls == 0)

    # 3) 타입 / 길이
    too_long = []
    for col, dtype in coltypes.items():
        if dtype.startswith("VARCHAR2"):
            limit = int(dtype[dtype.index("(") + 1:-1])
            actual = table[col].astype(str).str.len().max()
            if actual > limit:
                too_long.append(f"{col}({actual}>{limit})")
    add("VARCHAR2 길이", "정의 길이 이내",
        "초과 없음" if not too_long else ", ".join(too_long))
    checks[-1]["판정"] = verdict(not too_long)

    num_cols = [c for c, d in coltypes.items() if d.startswith("NUMBER")]
    max_abs = float(np.nanmax([table[c].abs().max() for c in num_cols]))
    add("NUMBER(22,10) 범위", "정수부 12자리 이내", f"최대 절대값 {max_abs:,.0f}")
    checks[-1]["판정"] = verdict(max_abs < 1e12)

    # 4) 기간 파생값
    bad_period = 0
    for _, row in table[["TGT_YM", "TGT_QUTR", "TGT_HALF", "TGT_YEAR"]].drop_duplicates().iterrows():
        q, h, y = G.period_columns(int(row["TGT_YM"]))
        if (q, h, y) != (row["TGT_QUTR"], row["TGT_HALF"], row["TGT_YEAR"]):
            bad_period += 1
    add("기간 파생 정합성", "매핑표와 일치", f"불일치 {bad_period}건",
        "TGT_YM -> TGT_QUTR / TGT_HALF / TGT_YEAR")
    checks[-1]["판정"] = verdict(bad_period == 0)

    months = sorted(table["TGT_YM"].unique())
    add("대상 월", "202601 ~ 202612 (12개월)", f"{months[0]} ~ {months[-1]} ({len(months)}개)")
    checks[-1]["판정"] = verdict(len(months) == 12)

    # 5) 총합계
    for col in MONTHLY_TOTAL_COLS:
        target = float(stats.loc[col, "total"])
        got = float(table[col].sum())
        diff = abs(got - target) / target * 100
        add(f"총합계 {col}", f"{target:,.0f}", f"{got:,.0f}", f"편차 {diff:.6f}%")
        checks[-1]["판정"] = verdict(diff < 0.001)

    for col in ANNUAL_COLS:
        target = float(stats.loc[col, "total"])
        got = float(table.groupby(PK_COLS[:12])[col].first().sum())
        diff = abs(got - target) / abs(target) * 100
        add(f"총합계 {col} (연간 그레인)", f"{target:,.0f}", f"{got:,.0f}",
            f"편차 {diff:.4f}% · 12개월 행에 동일값 반복")
        checks[-1]["판정"] = verdict(diff < 0.01)

    # 5-1) 항등식
    den = table["FAB_DEN_CD"].str.replace("G", "", regex=False).astype(int)
    id_eq = int((table["SOM_EQ_QTY"] != table["SOM_DIE_QTY"] * den).sum())
    add("항등식 EQ = DIE x Density", "위반 0건", f"{id_eq}건")
    checks[-1]["판정"] = verdict(id_eq == 0)

    wf_calc = table["SOM_DIE_QTY"] / (table["NET_DIE_300_CNT"] * table["CUM2_YLD"])
    id_wf = int((abs(wf_calc - table["WF_CONV_QTY"]) > 0.01 * table["WF_CONV_QTY"].abs()).sum())
    add("항등식 DIE = WF x NETDIE x 수율", "위반 0건", f"{id_wf}건", "반올림 오차 1% 허용")
    checks[-1]["판정"] = verdict(id_wf == 0)

    id_prof = 0
    for prefix in ["WF", "EQ", "DIE", "PROD", "YR"]:
        for tier_name in ["VAR", "CASH", "COGS", "COO"]:
            left = table[f"{prefix}_{tier_name}_PROF_AMT"]
            right = table[f"{prefix}_SALE_AMT"] - table[f"{prefix}_{tier_name}_COST"]
            id_prof += int((abs(left - right) > 1e-4 * abs(right).clip(lower=1)).sum())
    add("항등식 이익 = 판매금액 - 원가", "위반 0건", f"{id_prof}건",
        "WF/EQ/DIE/PROD/YR x VAR/CASH/COGS/COO 20개 조합")
    checks[-1]["판정"] = verdict(id_prof == 0)

    # 6) 추세
    g = table.groupby("TGT_YM")[["SALE_QTY", "SALE_AMT"]].sum()
    add("전체 월별 증가 추세", "QTY·AMT 모두 단조 증가",
        f"QTY {g['SALE_QTY'].is_monotonic_increasing} / AMT {g['SALE_AMT'].is_monotonic_increasing}",
        f"12월/1월 = QTY {g['SALE_QTY'].iloc[-1]/g['SALE_QTY'].iloc[0]:.2f}배, "
        f"AMT {g['SALE_AMT'].iloc[-1]/g['SALE_AMT'].iloc[0]:.2f}배")
    checks[-1]["판정"] = verdict(g["SALE_QTY"].is_monotonic_increasing and
                                g["SALE_AMT"].is_monotonic_increasing)

    pivot = table.pivot_table(index="CHG_PROD_MODE_CD", columns="TGT_YM",
                              values="SALE_QTY", aggfunc="sum")
    ratio = (pivot["202612"] / pivot["202601"]).sort_values(ascending=False)
    newest = ["DDR5", "LPDDR5", "HBM4", "GDDR7"]
    legacy = ["DDR3", "LPDDR4", "HBM3", "GDDR6"]
    ok_new = all(ratio.get(m, 0) > 1.0 for m in newest)
    ok_old = all(ratio.get(m, 9) < 1.0 for m in legacy)
    add("최신 제품 증가", "DDR5·LPDDR5·HBM4·GDDR7 > 1.0배",
        ", ".join(f"{m} {ratio[m]:.2f}" for m in newest))
    checks[-1]["판정"] = verdict(ok_new)
    add("Legacy 제품 감소", "DDR3·LPDDR4·HBM3·GDDR6 < 1.0배",
        ", ".join(f"{m} {ratio[m]:.2f}" for m in legacy))
    checks[-1]["판정"] = verdict(ok_old)

    # 7) 비중 재현
    for col in ["TECH_CD", "CHG_PROD_MODE_CD", "SCM_PROD_VER_CD", "APP_LVL_1_CD"]:
        target = B.weight_map(share, col, "w_amt")
        got = table.groupby(col)["SALE_AMT"].sum() / table["SALE_AMT"].sum()
        worst_code = max(target, key=lambda code: abs(got.get(code, 0) - target[code]))
        gap = abs(got.get(worst_code, 0) - target[worst_code]) * 100
        add(f"매출 비중 재현 {col}", "엑셀 '제품 속성별 비중'과 일치",
            f"최대 편차 {gap:.2f}%p ({worst_code})")
        checks[-1]["판정"] = verdict(gap < 1.0)

    return pd.DataFrame(checks)


def measure_table(table, annual_view, stats):
    rows = []
    for m in stats.index:
        if m not in table.columns:
            continue
        source = annual_view if m.startswith("YR_") else table
        s = source[m].dropna()
        rows.append({
            "Measure": m,
            "그레인": "연간" if m.startswith("YR_") else "월",
            "행 수": int(len(s)),
            "통계 Total": float(stats.loc[m, "total"]),
            "목업 Total": float(s.sum()),
            "통계 Min": float(stats.loc[m, "min"]),
            "목업 Min": float(s.min()),
            "통계 Max": float(stats.loc[m, "max"]),
            "목업 Max": float(s.max()),
            "통계 Avg": float(stats.loc[m, "avg"]),
            "목업 Avg": float(s.mean()),
        })
    df = pd.DataFrame(rows)
    df["Avg 비율"] = df["목업 Avg"] / df["통계 Avg"]
    return df


def main():
    os.makedirs(C.OUT_DIR, exist_ok=True)
    table, annual, stats, columns, coltypes = G.main()
    attrs, share, _ = B.load_excel()

    annual_view = table.groupby(PK_COLS[:12], as_index=False).first()
    checks = build_checks(table, annual, stats, share, columns, coltypes)
    measures = measure_table(table, annual_view, stats)

    notes = [
        ["대상 테이블", f"{O.FQTN} (P-Mix결과수익성개선제품정보 레포트)"],
        ["행 구성", f"제품 조합 {len(annual):,}건 x 12개월(202601~202612) "
                    f"- 신규 제품 {C.N_LATE_LAUNCH}건의 1월분 = {len(table):,}행. "
                    "수익지표 통계의 Total/Avg 를 나누면 모든 절대금액 컬럼에서 1,033 이 나오므로 "
                    "최종 테이블 행 수를 1,033 으로 확정했다(규칙 4.1). "
                    "1,033 이 12 로 나누어떨어지지 않아, 최신도 상위 11개 조합은 "
                    "연초 양산 전으로 보고 1월 행을 만들지 않았다. 이 조합들은 남은 11개월에 "
                    "연간값을 다시 배분하므로 통계 Total 은 그대로 유지된다."],
        ["PRID_GBN_CD", "'M'(월). 기간 파생 예시에서 TGT_YM·QUTR·HALF·YEAR 가 동시에 채워지므로 "
                        "월 그레인 1종으로 생성했다."],
        ["YR_* 컬럼", f"해당 제품 조합의 2026년 연간 합계를 그 조합의 모든 월 행에 반복한다. "
                      f"총합계 검증은 연간 그레인(조합 {len(annual):,}건)에서 하고 통계 Total 과 일치한다. "
                      f"다만 통계 Avg 는 1,033행 기준이라, 조합이 {len(annual):,}건인 이 목업에서는 "
                      f"YR_* 의 행 평균이 통계 Avg 의 약 {len(table)/len(annual):.1f}배로 나온다. "
                      "통계상 SALE_AMT 와 YR_SALE_AMT 의 Total/Min/Max 가 완전히 같다는 것은 "
                      "원본에서 조합 1건이 행 1건이었다는 뜻인데, 이는 규칙 4.3 의 '월 단위 분리' 와 "
                      "양립하지 않는다. 규칙 4.1(총 1,033행) 을 우선했다."],
        ["값 정의가 없는 PK 컬럼", "DATA_GBN_CD / CELL_LAYER_TYP_CD / UPPER_CD / SSD_CLAS_NM 은 "
                                "엑셀 '제품 속성 데이터'에 정의가 없어 DDL 기본값 ' '(공백)을 넣었다. "
                                "임의 코드값을 만들지 않았다."],
        ["PLN_REV / PLN_YW", f"단일 계획 스냅샷으로 '{C.FIXED_CODES['PLN_REV']}' / "
                             f"'{C.FIXED_CODES['PLN_YW']}' 고정. mock_config.py 에서 변경 가능."],
        ["FAB_DEN_CD 비중", "엑셀에 '-' 로 비어 있다. SOM_EQ_QTY / SOM_DIE_QTY = 15.93 "
                            "(=1Gb 환산 수량 / DIE 수량, 즉 매출가중 조화평균 Density)이라는 "
                            "통계 제약으로 Density 배분을 역산했다."],
        ["EQ / DIE / ASP 관계", "SOM_EQ_QTY = SOM_DIE_QTY x Density(Gb), "
                               "ASP_AMT = EQ_SALE_AMT = SALE_AMT / SOM_EQ_QTY. "
                               "통계에서 ASP_AMT 와 EQ_SALE_AMT 의 4개 값이 완전히 동일한 데서 확인된다."],
        ["웨이퍼 관계", "SOM_DIE_QTY / WF_CONV_QTY = NET_DIE_300_CNT x CUM2_YLD. "
                       "통계상 DIE/WF = 1,040 이며 수율 0.87 기준 NET DIE 약 1,200 으로 "
                       "300mm 웨이퍼의 물리적 크기와 부합한다."],
        ["이익 = 매출 - 원가", "WF/EQ/DIE/PROD/YR 5개 계열 모두 *_PROF_AMT = *_SALE_AMT - *_COST 로 "
                             "성립한다. 통계 Total 에서도 이 항등식이 정확히 성립함을 확인했다."],
        ["COGS 이익 컬럼", "통계 시트에 *_COGS_PROF_AMT 4개가 없어, 위 항등식으로 산출했다."],
        ["영업이익 정의", "SALES_PROF_RATE = (SALE_AMT - COO원가) / SALE_AMT 로 두었다. "
                        "통계 Avg 0.83, Min -2.13, Max 1.02 를 재현하도록 적자 제품과 "
                        "원가 음수 제품을 소수 포함시켰다."],
        ["월별 추세", "월 증가율 = 0.19 x (최신도 - 0.62). 최신도는 제품모드 세대(계열 내), "
                     "TECH/Density/버전의 Code Seq(작을수록 최신)를 가중 평균한 값이다."],
        ["재현성", f"난수 시드 {C.RANDOM_SEED} 고정. generate_mock_data.py 를 다시 실행하면 "
                  "같은 데이터가 나온다."],
    ]

    csv_path = O.write_csv(table)
    sql_path = O.write_sql(table, columns, coltypes)
    xlsx_path = O.write_xlsx(table, notes, checks)

    os.makedirs(C.WORK_DIR, exist_ok=True)
    checks.to_pickle(os.path.join(C.WORK_DIR, "_checks.pkl"))
    measures.to_pickle(os.path.join(C.WORK_DIR, "_measures.pkl"))
    pd.DataFrame(notes, columns=["항목", "내용"]).to_pickle(
        os.path.join(C.WORK_DIR, "_notes.pkl"))

    print(checks[["검증항목", "결과", "판정"]].to_string(index=False))
    print()
    for path in [csv_path, sql_path, xlsx_path]:
        print(f"{path}  ({os.path.getsize(path)/1024/1024:.1f} MB)")


if __name__ == "__main__":
    main()
