# -*- coding: utf-8 -*-
"""
generate_mock_data.py
---------------------
PMO_PROFBLT_IMPROV_PROD_IDC_REPORT 목업 데이터 생성기.

실행 : python generate_mock_data.py

산출물
  - PMO_PROFBLT_IMPROV_PROD_IDC_REPORT_MOCK.csv    (전체 데이터)
  - PMO_PROFBLT_IMPROV_PROD_IDC_REPORT_MOCK.sql    (INSERT ALL 스크립트)
  - PMO_PROFBLT_IMPROV_PROD_IDC_REPORT_MOCK.xlsx   (Insert 용 엑셀)
  - 검증리포트.md
"""

import os
import re
import numpy as np
import pandas as pd

import mock_config as C
import build_core as B


# ===========================================================================
# 공통 도우미
# ===========================================================================
def largest_remainder(values, total):
    """
    실수 배분값을 정수로 바꾸되 합계를 total 에 정확히 맞춘다(최대잉여법).
    수량 컬럼처럼 정수여야 하면서 총합이 통계와 일치해야 할 때 쓴다.
    """
    values = np.asarray(values, dtype=float)
    floors = np.floor(values).astype(np.int64)
    remainder = int(total - floors.sum())
    if remainder > 0:
        order = np.argsort(-(values - floors))
        floors[order[:remainder]] += 1
    elif remainder < 0:
        order = np.argsort(values - floors)
        floors[order[:(-remainder)]] -= 1
    return floors


def apply_floor_keep_total(values, floor_value):
    """하한을 적용하고, 늘어난 만큼을 가장 큰 행에서 빼서 총합을 유지한다."""
    values = np.asarray(values, dtype=float).copy()
    added = np.maximum(floor_value - values, 0.0)
    values = np.maximum(values, floor_value)
    if added.sum() > 0:
        values[int(np.argmax(values))] -= added.sum()
    return values


def rank01(seq_values):
    """Code Seq 를 0~1 의 '최신도'로 바꾼다. seq 가 작을수록 1(최신)."""
    s = pd.Series(seq_values)
    r = s.rank(method="dense")
    if r.max() == r.min():
        return np.full(len(s), 0.5)
    return (1.0 - (r - r.min()) / (r.max() - r.min())).to_numpy()


def parse_ddl_columns():
    """DDL 에서 컬럼 순서와 타입을 읽는다(순서를 손으로 옮겨 적지 않기 위해)."""
    src = open(C.DDL_PATH, encoding="utf-8").read()
    i = src.index('CREATE TABLE "RPLS_ADM"')
    j = src.index("CONSTRAINT", i)
    found = re.findall(
        r'"([A-Z0-9_]+)"\s+(VARCHAR2\(\d+\)|NUMBER\(\d+,\d+\)|DATE)', src[i:j])
    return [c for c, _ in found], dict(found)


# ===========================================================================
# 1. 연간 그레인(조합 N_COMBO 행) 지표 산출
# ===========================================================================
def build_annual(attrs, share, stats, rng):
    combos = B.select_combos(B.build_all_combos(attrs, share), share, C.N_COMBO)

    # seed 의 편차를 실데이터 수준으로 눌러 준다(실데이터 max/min 비 ≈ 3e9).
    combos["seed"] = combos["seed"] ** 0.60

    T_amt = float(stats.loc["SALE_AMT", "total"])
    T_qty = float(stats.loc["SALE_QTY", "total"])
    T_org = float(stats.loc["ORG_QTY", "total"])
    T_die = float(stats.loc["SOM_DIE_QTY", "total"])
    T_eq = float(stats.loc["SOM_EQ_QTY", "total"])
    T_wf = float(stats.loc["WF_CONV_QTY", "total"])
    T_var = float(stats.loc["YR_VAR_COST", "total"])
    T_cash = float(stats.loc["YR_CASH_COST", "total"])
    T_cogs = float(stats.loc["YR_COGS_COST", "total"])
    T_coo = float(stats.loc["YR_COO_COST", "total"])
    T_prof = T_amt - T_coo                       # 영업이익(COO 기준) 총액

    # --- 1) 최신도(newness) : ASP·추세의 기준 -------------------------------
    newness = (0.40 * B.mode_generation_newness(combos["CHG_PROD_MODE_CD"]) +
               0.25 * rank01(combos["seq_tech"]) +
               0.20 * rank01(combos["seq_den"]) +
               0.15 * rank01(combos["seq_ver"]))
    combos["newness"] = newness
    den_gb = combos["den_gb"].to_numpy(dtype=float)

    # --- 2) ASP 형상 (1Gb 환산 단가) ---------------------------------------
    # 최신 제품일수록 Gb 당 단가가 높고, 고밀도 제품일수록 Gb 당 단가는 낮다.
    # 또한 대형 품목일수록 단가가 높다(=소형 품목이 단가를 낮추는 방향).
    # 이 크기 상관은 실데이터의 ASP 행평균(1.49)이 매출가중 조화평균(1.528)보다
    # 낮다는 사실에서 나온다.
    w_amt_seed = B.fit_shares(combos, share, "w_amt", n_iter=60)
    size_rank = pd.Series(w_amt_seed).rank(pct=True).to_numpy()
    asp_raw = ((1.0 + C.ASP_NEWNESS_SLOPE * newness)
               * np.power(den_gb, C.ASP_DEN_SLOPE)
               * np.exp(C.ASP_SIZE_SLOPE * (size_rank - 0.5))
               * np.exp(rng.normal(0.0, C.ASP_SIGMA, size=len(combos))))

    # --- 3) Density 배분 기울기 --------------------------------------------
    # 엑셀에 FAB_DEN_CD 비중이 없으므로(-), EQ/DIE = 15.93 제약으로 결정한다.
    nu = B.solve_density_tilt(combos, share, asp_raw, T_die / T_eq, "w_amt")
    combos["seed"] = combos["seed"] * np.power(den_gb, nu)

    # --- 4) 비중 적합 -------------------------------------------------------
    # 판매수량 비중은 매출 비중과 같은 씨앗에 편차를 더해 만든다.
    # 그래야 제품당 단가(PROD_SALE_AMT)가 실데이터처럼 넓게 퍼진다.
    w_amt = B.fit_shares(combos, share, "w_amt")
    qty_combos = combos.copy()
    qty_combos["seed"] = combos["seed"].to_numpy() * np.exp(
        rng.normal(0.0, C.QTY_SPREAD_SIGMA, size=len(combos)))
    w_qty = B.fit_shares(qty_combos, share, "w_qty")
    # 이익 비중은 매출 비중을 씨앗으로 삼아 적합한다.
    # 그래야 행별 이익률 편차가 불필요하게 커지지 않는다(단위당 원가가 과대해지는 것을 막음).
    prof_combos = combos.copy()
    prof_combos["seed"] = w_amt
    w_prof = B.fit_shares(prof_combos, share, "w_prof")

    # --- 5) 매출 / 수량 -----------------------------------------------------
    # 하한 : 월 분리 후에도 0 이 나오지 않도록 연간 최소치를 준다.
    sale_amt = apply_floor_keep_total(w_amt * T_amt, 48.0)
    sale_qty = largest_remainder(
        apply_floor_keep_total(w_qty * T_qty, 12.0), int(T_qty))

    org_ratio = (T_org / T_qty) * rng.normal(1.0, 0.004, size=len(combos))
    org_raw = sale_qty * org_ratio
    org_raw = org_raw * (T_org / org_raw.sum())      # 총합을 먼저 정확히 맞춘다
    org_qty = largest_remainder(org_raw, int(T_org))

    # --- 6) EQ / DIE : ASP 로부터 역산 --------------------------------------
    eq_f, die_f, asp, k_asp = B.solve_eq_and_die(sale_amt, den_gb, asp_raw, T_die, T_eq)
    som_die = largest_remainder(die_f, int(round(T_die)))
    som_die = np.maximum(som_die, 12)                      # 월 분리 시 0 방지
    som_eq = som_die * den_gb.astype(np.int64)             # 항등식 EQ = DIE * Density 유지

    # --- 7) NET DIE / 수율 / 웨이퍼 ----------------------------------------
    net_die, yld = B.net_die_and_yield(combos, rng)
    wf = som_die / (net_die * yld)
    net_die = net_die * (wf.sum() / T_wf)    # NET DIE 를 보정해 항등식을 유지
    wf = som_die / (net_die * yld)

    # --- 8) 영업이익 / 원가 4계층 -------------------------------------------
    profit = B.clip_rate_preserve_total(
        (w_prof * T_prof) / sale_amt, sale_amt, T_prof,
        C.RATE_MIN_ANNUAL, C.RATE_MAX_ANNUAL)
    profit = B.add_rate_tails(profit, sale_amt, newness, T_prof, rng,
                              loss_ratio=C.LOSS_ROW_RATIO,
                              high_ratio=C.HIGH_RATE_ROW_RATIO,
                              rate_min=C.RATE_MIN_ANNUAL,
                              rate_max=C.RATE_MAX_ANNUAL)
    profit = B.align_rate_mean(profit, sale_amt, T_prof, C.RATE_MEAN_TARGET)
    coo_cost = sale_amt - profit

    def tier(target_total):
        noise = rng.normal(1.0, C.COST_TIER_NOISE, size=len(combos))
        raw = coo_cost * (target_total / T_coo) * noise
        return raw * (target_total / raw.sum())

    def positive_tier(cost, target_total, sale):
        """실데이터에서 변동원가·COGS원가는 음수가 없다. 하한을 주고 총합을 다시 맞춘다."""
        cost = np.maximum(cost, 0.0004 * sale)
        return cost * (target_total / cost.sum())

    var_cost = positive_tier(tier(T_var), T_var, sale_amt)
    cash_cost = tier(T_cash)
    cogs_cost = positive_tier(tier(T_cogs), T_cogs, sale_amt)

    df = combos.copy()
    df["SALE_AMT"] = sale_amt
    df["SALE_QTY"] = sale_qty
    df["ORG_QTY"] = org_qty
    df["SOM_DIE_QTY"] = som_die
    df["SOM_EQ_QTY"] = som_eq
    df["WF_CONV_QTY"] = wf
    df["NET_DIE_300_CNT"] = net_die
    df["CUM2_YLD"] = yld
    df["OP_PROFIT"] = profit
    df["VAR_COST"] = var_cost
    df["CASH_COST"] = cash_cost
    df["COGS_COST"] = cogs_cost
    df["COO_COST"] = coo_cost

    return df, nu


# ===========================================================================
# 2. 월 분리 (규칙 4.3 / 4.4)
# ===========================================================================
def monthly_weights(rate, n=12, active=None):
    """
    월 증가율 rate 를 n 개월 가중치로 바꾼다(행별 합 = 1).

    active 는 (조합수 x n) 의 bool 행렬로, 그 조합이 해당 월에 존재하는지를 나타낸다.
    존재하지 않는 월은 가중치 0 으로 두고 나머지 월에 다시 정규화하므로,
    행이 빠져도 조합별 연간 합계(=통계 Total)는 그대로 유지된다.
    """
    powers = np.arange(n)
    w = np.power(1.0 + rate[:, None], powers[None, :])
    if active is not None:
        w = np.where(active, w, 0.0)
    return w / w.sum(axis=1, keepdims=True)


GUARD_COLS = ["CHG_PROD_MODE_CD", "TECH_CD", "APP_LVL_1_CD",
              "FAB_DEN_CD", "SCM_PROD_VER_CD"]


def active_month_matrix(df):
    """
    조합 x 월 의 존재 여부 행렬(bool)을 만든다.

    총 행 수를 C.TOTAL_ROWS(1,033)에 정확히 맞추기 위해,
    최신도(newness)가 높은 C.N_LATE_LAUNCH 개 조합은 1월 행을 만들지 않는다.
    (신규 제품이라 연초에는 아직 양산 전이라는 해석. 규칙 4.4 의 '최신 제품 증가' 와도 맞다)

    단, 어떤 코드값이 1월에 통째로 사라지면 월별 비교 축이 끊기므로
    (예: HBM4 가 1월에 하나도 없으면 12월/1월 증가율을 계산할 수 없다)
    각 코드값마다 최소 1개 조합은 1월에 남긴다.
    """
    n_month = len(C.MONTHS)
    active = np.ones((len(df), n_month), dtype=bool)

    n_drop = int(C.N_LATE_LAUNCH)
    if n_drop <= 0:
        return active

    codes = {col: df[col].to_numpy() for col in GUARD_COLS}
    remain = {col: pd.Series(codes[col]).value_counts().to_dict() for col in GUARD_COLS}

    dropped = 0
    for i in np.argsort(-df["newness"].to_numpy()):
        if dropped >= n_drop:
            break
        if any(remain[col][codes[col][i]] <= 1 for col in GUARD_COLS):
            continue                      # 이 조합을 빼면 코드값이 1월에 사라진다
        active[i, 0] = False
        for col in GUARD_COLS:
            remain[col][codes[col][i]] -= 1
        dropped += 1

    if dropped < n_drop:
        raise RuntimeError(
            f"1월에서 뺄 조합이 부족하다 ({dropped}/{n_drop}). "
            f"N_COMBO({C.N_COMBO})를 늘리거나 TOTAL_ROWS 를 조정해야 한다.")
    return active


def period_columns(ym):
    """TGT_YM -> (TGT_QUTR, TGT_HALF, TGT_YEAR) 파생 (규칙 4.3 매핑표)."""
    year = ym // 100
    month = ym % 100
    quarter = (month - 1) // 3 + 1
    half = 1 if month <= 6 else 2
    return f"{year}{quarter:02d}", f"{year}{half:02d}", str(year)


def build_monthly(df):
    n_month = len(C.MONTHS)
    newness = df["newness"].to_numpy()

    r_qty = C.GROWTH_SLOPE * (newness - C.GROWTH_PIVOT)
    r_amt = r_qty + C.ASP_DRIFT * (2 * newness - 1)      # 단가 믹스 효과
    r_prof = r_amt + C.MARGIN_DRIFT * (2 * newness - 1)  # 수익성 개선 효과

    # 조합 x 월 존재 여부. 여기서 빠지는 행 수만큼 최종 행 수가 줄어든다.
    active = active_month_matrix(df)

    w_qty = monthly_weights(r_qty, n_month, active)
    w_amt = monthly_weights(r_amt, n_month, active)
    w_prof = monthly_weights(r_prof, n_month, active)

    blocks = []
    for m_idx, ym in enumerate(C.MONTHS):
        keep = np.flatnonzero(active[:, m_idx])     # 이 달에 존재하는 조합만
        if len(keep) == 0:
            continue
        d = df.iloc[keep]
        qutr, half, year = period_columns(ym)
        b = pd.DataFrame(index=range(len(keep)))

        # --- 키 컬럼 ---
        b["TECH_CD"] = d["TECH_CD"].to_numpy()
        b["FAB_DEN_CD"] = d["FAB_DEN_CD"].to_numpy()
        b["CHG_PROD_MODE_CD"] = d["CHG_PROD_MODE_CD"].to_numpy()
        b["SCM_PROD_VER_CD"] = d["SCM_PROD_VER_CD"].to_numpy()
        b["APP_LVL_1_CD"] = d["APP_LVL_1_CD"].to_numpy()
        b["TGT_YM"] = str(ym)
        b["TGT_QUTR"] = qutr
        b["TGT_HALF"] = half
        b["TGT_YEAR"] = year
        b["_den_gb"] = d["den_gb"].to_numpy()

        # --- 제품 속성(월 불변) ---
        b["NET_DIE_300_CNT"] = d["NET_DIE_300_CNT"].to_numpy()
        b["CUM2_YLD"] = d["CUM2_YLD"].to_numpy()

        # --- 월 배분 ---
        b["_wq"] = w_qty[keep, m_idx]
        b["_wa"] = w_amt[keep, m_idx]
        b["_wp"] = w_prof[keep, m_idx]
        b["SALE_AMT"] = d["SALE_AMT"].to_numpy() * w_amt[keep, m_idx]
        b["OP_PROFIT"] = d["OP_PROFIT"].to_numpy() * w_prof[keep, m_idx]
        for col in ["SALE_QTY", "ORG_QTY", "SOM_DIE_QTY", "SOM_EQ_QTY", "WF_CONV_QTY"]:
            b[col] = d[col].to_numpy() * w_qty[keep, m_idx]

        # --- 연간값(YR_*)은 조합의 연간 합계를 그대로 반복 ---
        b["YR_SALE_AMT"] = d["SALE_AMT"].to_numpy()
        b["YR_VAR_COST"] = d["VAR_COST"].to_numpy()
        b["YR_CASH_COST"] = d["CASH_COST"].to_numpy()
        b["YR_COGS_COST"] = d["COGS_COST"].to_numpy()
        b["YR_COO_COST"] = d["COO_COST"].to_numpy()
        b["_combo"] = keep
        blocks.append(b)

    mon = pd.concat(blocks, ignore_index=True)

    # --- 수량 정수화 (전체 합계를 통계 Total 에 정확히 맞춘다) ---
    for col in ["SALE_QTY", "ORG_QTY", "SOM_DIE_QTY"]:
        target = int(round(mon[col].sum()))
        mon[col] = largest_remainder(mon[col].to_numpy(), target)
    # EQ / 웨이퍼는 반올림하지 않고 항등식으로 다시 만든다.
    #   SOM_EQ_QTY  = SOM_DIE_QTY x Density
    #   WF_CONV_QTY = SOM_DIE_QTY / (NET_DIE_300_CNT x CUM2_YLD)
    mon["SOM_EQ_QTY"] = mon["SOM_DIE_QTY"].to_numpy() * mon["_den_gb"].to_numpy(dtype=np.int64)
    mon["WF_CONV_QTY"] = (mon["SOM_DIE_QTY"].to_numpy()
                          / (mon["NET_DIE_300_CNT"].to_numpy() * mon["CUM2_YLD"].to_numpy()))

    # --- 월 원가 : 연간 원가 계층 비율을 그대로 적용 ---
    ratio_var = (mon["YR_VAR_COST"] / mon["YR_COO_COST"]).to_numpy()
    ratio_cash = (mon["YR_CASH_COST"] / mon["YR_COO_COST"]).to_numpy()
    ratio_cogs = (mon["YR_COGS_COST"] / mon["YR_COO_COST"]).to_numpy()

    mon["COO_COST"] = mon["SALE_AMT"] - mon["OP_PROFIT"]
    floor = 0.0004 * mon["SALE_AMT"].to_numpy()
    # 실데이터에서 변동원가/COGS원가는 음수가 없다(현금·COO 원가만 음수가 있다).
    mon["VAR_COST"] = np.maximum(mon["COO_COST"].to_numpy() * ratio_var, floor)
    mon["CASH_COST"] = mon["COO_COST"] * ratio_cash
    mon["COGS_COST"] = np.maximum(mon["COO_COST"].to_numpy() * ratio_cogs, floor)
    return mon


# ===========================================================================
# 3. 파생 컬럼 (단위별 단가 / 이익 / 원가)
# ===========================================================================
def add_derived_columns(mon):
    """
    WF / EQ / DIE / PROD 4개 단위별 컬럼을 만든다.
      단위당 판매금액 = 판매금액 / 해당 단위 수량
      단위당 원가     = 원가     / 해당 단위 수량
      단위당 이익     = 단위당 판매금액 - 단위당 원가
    """
    scale_qty = {
        "WF": mon["WF_CONV_QTY"].to_numpy(dtype=float),
        "EQ": mon["SOM_EQ_QTY"].to_numpy(dtype=float),
        "DIE": mon["SOM_DIE_QTY"].to_numpy(dtype=float),
        "PROD": mon["SALE_QTY"].to_numpy(dtype=float),
    }
    sale = mon["SALE_AMT"].to_numpy(dtype=float)
    costs = {
        "VAR": mon["VAR_COST"].to_numpy(dtype=float),
        "CASH": mon["CASH_COST"].to_numpy(dtype=float),
        "COGS": mon["COGS_COST"].to_numpy(dtype=float),
        "COO": mon["COO_COST"].to_numpy(dtype=float),
    }

    for prefix, qty in scale_qty.items():
        safe_qty = np.where(qty <= 0, np.nan, qty)
        unit_sale = sale / safe_qty
        mon[f"{prefix}_SALE_AMT"] = unit_sale
        for tier_name, cost in costs.items():
            unit_cost = cost / safe_qty
            mon[f"{prefix}_{tier_name}_COST"] = unit_cost
            mon[f"{prefix}_{tier_name}_PROF_AMT"] = unit_sale - unit_cost

    # ASP : 통계상 ASP_AMT 와 EQ_SALE_AMT 의 Total/Min/Max/Avg 가 완전히 동일하다.
    #       -> ASP 는 EQ(1Gb 환산) 기준 단가로 본다.
    mon["ASP_AMT"] = mon["EQ_SALE_AMT"]

    # 영업이익률
    mon["SALES_PROF_RATE"] = mon["OP_PROFIT"] / mon["SALE_AMT"]

    # 연간(YR_*) 이익 및 연간 영업이익률
    for tier_name in ["VAR", "CASH", "COGS", "COO"]:
        mon[f"YR_{tier_name}_PROF_AMT"] = mon["YR_SALE_AMT"] - mon[f"YR_{tier_name}_COST"]
    mon["YR_SALES_PROF_RATE"] = mon["YR_COO_PROF_AMT"] / mon["YR_SALE_AMT"]
    return mon


# ===========================================================================
# 4. 최종 테이블 조립
# ===========================================================================
def assemble_table(mon, columns):
    out = pd.DataFrame(index=mon.index)
    for col in columns:
        if col in C.FIXED_CODES:
            out[col] = C.FIXED_CODES[col]
        elif col == "CRT_TM":
            out[col] = C.CRT_TM
        elif col in ("CHG_TM", "CHG_USER_ID"):
            out[col] = None
        elif col in mon.columns:
            out[col] = mon[col].to_numpy()
        else:
            raise KeyError(f"컬럼 누락: {col}")

    # 반올림 : 수량은 정수, 금액/비율은 소수 6자리 (NUMBER(22,10) 범위 내)
    int_cols = ["SOM_EQ_QTY", "SOM_DIE_QTY", "ORG_QTY", "SALE_QTY"]
    for col in out.columns:
        if col in int_cols:
            out[col] = out[col].astype("int64")
        elif out[col].dtype.kind == "f":
            out[col] = out[col].round(6)

    # 정렬 : 년월 -> 제품 순
    out = out.sort_values(
        ["TGT_YM", "TECH_CD", "FAB_DEN_CD", "CHG_PROD_MODE_CD",
         "SCM_PROD_VER_CD", "APP_LVL_1_CD"]).reset_index(drop=True)
    return out


def main():
    rng = np.random.default_rng(C.RANDOM_SEED)
    os.makedirs(C.OUT_DIR, exist_ok=True)

    attrs, share, stats = B.load_excel()
    columns, coltypes = parse_ddl_columns()

    annual, nu = build_annual(attrs, share, stats, rng)
    mon = build_monthly(annual)
    mon = add_derived_columns(mon)
    table = assemble_table(mon, columns)

    os.makedirs(C.WORK_DIR, exist_ok=True)
    table.to_pickle(os.path.join(C.WORK_DIR, "_table.pkl"))
    annual.to_pickle(os.path.join(C.WORK_DIR, "_annual.pkl"))
    print("행 수:", len(table), "/ 컬럼 수:", len(table.columns))
    print("density tilt nu =", round(nu, 4))
    return table, annual, stats, columns, coltypes


if __name__ == "__main__":
    main()
