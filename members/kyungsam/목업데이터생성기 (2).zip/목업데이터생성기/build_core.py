# -*- coding: utf-8 -*-
"""
build_core.py
-------------
1) 엑셀에서 제품 속성 / 비중 / 수익지표 통계를 읽는다.
2) 제품 조합(연간 그레인 C.N_COMBO 행)을 만든다.
3) IPF(반복 비례 조정)로 조합별 매출/수량/이익 비중을 엑셀 마진에 맞춘다.
4) 연간 지표를 산출한다. (월 분리는 build_monthly.py 에서)
"""

import math
import openpyxl
import pandas as pd
import numpy as np

import mock_config as C


# ===========================================================================
# 1. 엑셀 로딩
# ===========================================================================
def load_excel():
    """엑셀 3개 시트를 읽어 (속성, 비중, 통계) 로 돌려준다."""
    wb = openpyxl.load_workbook(C.EXCEL_PATH, data_only=True)

    # --- 시트1 : 제품 속성 데이터 (코드 목록 + Code Seq) ---
    rows = []
    for r in wb["제품 속성 데이터"].iter_rows(min_row=3, values_only=True):
        if r[1] is None:
            continue
        rows.append({"col": r[1], "code": r[2], "seq": r[3]})
    attrs = pd.DataFrame(rows)

    # --- 시트2 : 제품 속성별 비중 ---
    rows = []
    for r in wb["제품 속성별 비중"].iter_rows(min_row=3, values_only=True):
        if r[1] is None:
            continue
        rows.append({
            "col": r[1], "code": r[2], "seq": r[3],
            "w_amt": r[4], "w_qty": r[5], "w_prof": r[6],
        })
    share = pd.DataFrame(rows)
    # '-' (FAB_DEN_CD) 는 결측으로 처리
    for c in ["w_amt", "w_qty", "w_prof"]:
        share[c] = pd.to_numeric(share[c], errors="coerce")

    # --- 시트3 : 수익지표 통계 ---
    rows = []
    for r in wb["수익지표 통계"].iter_rows(min_row=3, values_only=True):
        if r[1] is None:
            continue
        rows.append({"measure": r[1], "total": r[2], "min": r[3], "max": r[4], "avg": r[5]})
    stats = pd.DataFrame(rows).set_index("measure")

    return attrs, share, stats


def code_list(attrs, col):
    """특정 DB 컬럼의 코드 목록과 Code Seq 를 dict 로 돌려준다."""
    sub = attrs[attrs["col"] == col]
    return dict(zip(sub["code"], sub["seq"]))


def weight_map(share, col, kind):
    """특정 DB 컬럼의 비중을 dict 로 돌려준다. 비중 0 인 코드는 제외한다."""
    sub = share[share["col"] == col]
    out = {}
    for _, row in sub.iterrows():
        w = row[kind]
        if pd.notna(w) and w > 0:
            out[row["code"]] = float(w)
    return out


# ===========================================================================
# 2. 조합 생성
# ===========================================================================
def density_to_gb(code):
    """'16G' -> 16 (Gb). SOM_EQ_QTY = SOM_DIE_QTY * Density 관계에 쓴다."""
    return int(code.replace("G", ""))


def build_all_combos(attrs, share):
    """
    친화도 표를 이용해 '있을 법한' 제품 조합을 전부 만든다.
    각 조합에는 마진 비중의 곱(seed weight)을 붙여 둔다.
    """
    w_tech = weight_map(share, "TECH_CD", "w_amt")
    w_mode = weight_map(share, "CHG_PROD_MODE_CD", "w_amt")
    w_ver = weight_map(share, "SCM_PROD_VER_CD", "w_amt")
    w_app = weight_map(share, "APP_LVL_1_CD", "w_amt")

    seq_tech = code_list(attrs, "TECH_CD")
    seq_den = code_list(attrs, "FAB_DEN_CD")
    seq_mode = code_list(attrs, "CHG_PROD_MODE_CD")
    seq_ver = code_list(attrs, "SCM_PROD_VER_CD")

    records = []
    for mode, wm in w_mode.items():
        aff_app = C.MODE_APP_AFFINITY.get(mode, {})
        aff_den = C.MODE_DEN_AFFINITY.get(mode, {})
        aff_tech = C.MODE_TECH_AFFINITY.get(mode, {})

        for app, a_app in aff_app.items():
            if app not in w_app:
                continue
            for den, a_den in aff_den.items():
                for tech, a_tech in aff_tech.items():
                    if tech not in w_tech:
                        continue
                    for ver, wv in w_ver.items():
                        seed = (w_tech[tech] * a_tech) * (wm * 1.0) * \
                               (w_app[app] * a_app) * (a_den * 1.0) * wv
                        records.append({
                            "TECH_CD": tech,
                            "FAB_DEN_CD": den,
                            "CHG_PROD_MODE_CD": mode,
                            "SCM_PROD_VER_CD": ver,
                            "APP_LVL_1_CD": app,
                            "seed": seed,
                            "den_gb": density_to_gb(den),
                            "seq_tech": seq_tech[tech],
                            "seq_den": seq_den[den],
                            "seq_mode": seq_mode[mode],
                            "seq_ver": seq_ver[ver],
                        })
    return pd.DataFrame(records)


def select_combos(all_combos, share, n_target):
    """
    seed weight 상위 n_target 개를 고른다.
    단, 엑셀에 비중이 있는 코드는 최소 1개 조합이 반드시 포함되도록 먼저 확보한다.
    (그래야 뒤의 IPF 가 모든 코드의 마진을 맞출 수 있다)
    """
    df = all_combos.sort_values("seed", ascending=False).reset_index(drop=True)

    must_have = []
    for col in ["TECH_CD", "FAB_DEN_CD", "CHG_PROD_MODE_CD", "SCM_PROD_VER_CD", "APP_LVL_1_CD"]:
        for code in df[col].unique():
            idx = df.index[df[col] == code][0]     # 그 코드를 가진 가장 큰 조합
            must_have.append(idx)
    must_have = sorted(set(must_have))

    chosen = list(must_have)
    for idx in df.index:
        if len(chosen) >= n_target:
            break
        if idx not in set(chosen):
            chosen.append(idx)
    chosen = sorted(set(chosen))[:n_target]

    return df.loc[chosen].reset_index(drop=True)


# ===========================================================================
# 3. IPF (반복 비례 조정) - 조합별 비중을 엑셀 마진에 맞춘다
# ===========================================================================
def fit_shares(combos, share, kind, n_iter=200):
    """
    combos 의 seed 를 출발점으로, 아래 4개 축의 합계 비중이
    엑셀 값과 일치하도록 반복적으로 비례 조정한다.
      TECH_CD / CHG_PROD_MODE_CD / SCM_PROD_VER_CD / APP_LVL_1_CD
    FAB_DEN_CD 는 엑셀에 비중이 없으므로(-) 자유롭게 둔다.
    """
    targets = {}
    for col in ["TECH_CD", "CHG_PROD_MODE_CD", "SCM_PROD_VER_CD", "APP_LVL_1_CD"]:
        targets[col] = weight_map(share, col, kind)

    w = combos["seed"].to_numpy(dtype=float).copy()
    w = w / w.sum()

    for _ in range(n_iter):
        for col, tgt in targets.items():
            codes = combos[col].to_numpy()
            for code, target_share in tgt.items():
                mask = (codes == code)
                cur = w[mask].sum()
                if cur > 0:
                    w[mask] *= (target_share / cur)
        w = w / w.sum()

    return w


# ===========================================================================
# 4. 물량 체계 산출
# ===========================================================================
def solve_density_tilt(combos, share, asp_raw, target_ratio, kind="w_amt"):
    """
    매출 배분에 Density 기울기 nu 를 넣어, 아래 제약을 만족시킨다.
        sum(매출 / (asp_raw * Density)) / sum(매출 / asp_raw) = SOM_DIE Total / SOM_EQ Total

    왜 필요한가
      EQ 는 1Gb 환산 수량이므로  SOM_EQ_QTY = SOM_DIE_QTY * Density 다.
      통계상 EQ/DIE = 15.93 이라는 것은 "매출 가중 조화평균 Density = 15.93" 이라는 뜻이다.
      엑셀에 FAB_DEN_CD 비중이 비어 있으므로(-), 이 제약이 곧 Density 비중을 결정한다.
      기울기를 ASP 쪽이 아니라 매출 배분 쪽에 두어야 ASP 범위(0.23~3.84)가 좁게 유지된다.
    """
    den_gb = combos["den_gb"].to_numpy(dtype=float)
    base_seed = combos["seed"].to_numpy(dtype=float)

    def ratio_at(nu):
        tilted = combos.copy()
        tilted["seed"] = base_seed * np.power(den_gb, nu)
        w = fit_shares(tilted, share, kind, n_iter=60)
        eq_w = w / asp_raw
        return float(np.sum(eq_w / den_gb) / np.sum(eq_w))

    lo, hi = -6.0, 6.0
    for _ in range(28):
        mid = (lo + hi) / 2.0
        if ratio_at(mid) > target_ratio:
            lo = mid          # nu 를 키우면 고밀도 비중이 늘어 조화평균 Density 가 커진다
        else:
            hi = mid
    return (lo + hi) / 2.0


def solve_eq_and_die(sale_amt, den_gb, asp_raw, total_die, total_eq):
    """
    SOM_EQ_QTY / SOM_DIE_QTY 를 'EQ 단가(ASP)' 로부터 거꾸로 만든다.

    왜 이 순서인가
      수익지표 통계에서 ASP_AMT 와 EQ_SALE_AMT 의 Total/Min/Max/Avg 가 완전히 같다.
      즉 ASP = 판매금액 / SOM_EQ_QTY (1Gb 환산 단가) 이고,
      실데이터의 ASP 는 0.23 ~ 3.84 로 좁은 범위에 모여 있다.
      수량에서 금액으로 가면 이 좁은 범위를 재현할 수 없으므로,
      단가를 먼저 정하고 수량을 역산한다.

    관계식
      SOM_EQ_QTY  = 판매금액 / ASP
      SOM_DIE_QTY = SOM_EQ_QTY / Density(Gb)      <- EQ 는 1Gb 환산 단위

    EQ Total 제약은 배율 k 하나로 맞춘다(ASP = k * asp_raw).
    DIE Total 제약은 앞 단계 solve_density_tilt 가 Density 배분으로 이미 맞춰 두었다.
    """
    def s_of(mu):
        return float(np.sum(sale_amt / (asp_raw * np.power(den_gb, mu))))

    # 1) Density 기울기는 매출 배분 쪽(solve_density_tilt)에서 이미 반영했으므로
    #    여기서는 배율 k 로 EQ 총합을 맞춘다.  ASP = k * asp_raw
    k = s_of(0.0) / total_eq
    asp = k * asp_raw
    eq = sale_amt / asp
    die = eq / den_gb

    # 2) DIE 총합까지 정확히 맞춘다.
    #    solve_density_tilt 는 IPF 반복 횟수를 줄여(60회) 이분탐색을 돌리므로,
    #    조합 수가 적을수록 최종 배분(200회)과의 오차가 남아 EQ/DIE 비가 흔들린다.
    #    die_i' = s * die_i * Density_i^t 로 두면 미지수 2개(s, t)로
    #      sum(die')            = total_die
    #      sum(die' x Density)  = total_eq
    #    두 제약을 동시에 정확히 만족시킬 수 있다.
    #    (Density 재배분일 뿐이라 ASP 범위·비중 적합에는 영향이 거의 없다)
    def mean_density_at(t):
        w = die * np.power(den_gb, t)
        return float(np.sum(w * den_gb) / np.sum(w))

    target_density = total_eq / total_die
    lo, hi = -6.0, 6.0
    for _ in range(80):
        mid = (lo + hi) / 2.0
        if mean_density_at(mid) < target_density:
            lo = mid
        else:
            hi = mid
    t = (lo + hi) / 2.0

    die = die * np.power(den_gb, t)
    die = die * (total_die / die.sum())
    eq = die * den_gb
    asp = sale_amt / eq
    return eq, die, asp, k


def add_rate_tails(profit, sale_amt, newness, total_profit, rng,
                   loss_ratio=0.025, high_ratio=0.010,
                   rate_min=-2.13, rate_max=1.02):
    """
    영업이익률에 실데이터와 같은 양쪽 꼬리를 만든다.

    실데이터 SALES_PROF_RATE 는 min -2.13 / max 1.02 다.
      - 음수 구간 : 적자 제품(주로 Legacy·소량)
      - 1 초과 구간 : 원가가 음수인 행 (WF_CASH_COST min 이 -473 인 것과 대응)
    꼬리를 만든 뒤 나머지 행을 비례 조정해 이익 총액을 그대로 유지한다.
    """
    profit = profit.astype(float).copy()
    n = len(profit)

    # 적자 후보 : 오래된 제품 + 매출 작은 순
    score = (1.0 - newness) * 2.0 - np.log10(np.maximum(sale_amt, 1.0)) / 10.0
    loss_idx = np.argsort(-score)[:max(1, int(n * loss_ratio))]
    high_idx = np.argsort(-newness)[:max(1, int(n * high_ratio))]
    high_idx = np.array([i for i in high_idx if i not in set(loss_idx.tolist())])

    tail = np.zeros(n, dtype=bool)
    profit[loss_idx] = rng.uniform(rate_min, -0.10, size=len(loss_idx)) * sale_amt[loss_idx]
    profit[high_idx] = rng.uniform(rate_max - 0.03, rate_max, size=len(high_idx)) * sale_amt[high_idx]
    tail[loss_idx] = True
    tail[high_idx] = True

    rest = ~tail
    need = total_profit - profit[tail].sum()
    profit[rest] = profit[rest] * (need / profit[rest].sum())
    return profit


def net_die_and_yield(combos, rng):
    """
    NET_DIE_300_CNT(300mm 웨이퍼당 net die 수) 와 CUM2_YLD(누적2수율) 을 만든다.
    die 면적은 Density 에 비례하고 TECH 가 최신일수록 작아진다고 본다.
    """
    den_gb = combos["den_gb"].to_numpy(dtype=float)
    seq_tech = combos["seq_tech"].to_numpy(dtype=float)

    # TECH 계수 : seq 가 작을수록(최신) 면적이 작다. 770(PO) ~ 850(PL)
    tech_factor = 1.0 + (seq_tech - 770.0) / 80.0 * 0.45

    usable_area = 66000.0                       # 300mm 웨이퍼 유효 면적(mm^2)
    die_area = 3.4 * den_gb * tech_factor       # Gb 당 약 3.4mm^2 가정
    net_die = usable_area / die_area
    net_die = net_die * rng.normal(1.0, 0.03, size=len(net_die))

    # 수율 : 오래된(성숙) TECH 일수록 높다
    maturity = (seq_tech - 770.0) / 80.0
    yld = 0.80 + 0.15 * maturity + rng.normal(0.0, 0.015, size=len(net_die))
    yld = np.clip(yld, 0.62, 0.985)
    return net_die, yld


# ===========================================================================
# 5. 수익 지표 산출
# ===========================================================================
def clip_rate_preserve_total(rate, sale_amt, total_profit, lo, hi, n_iter=60):
    """
    영업이익률을 통계 min/max 범위 안으로 넣으면서 이익 총액은 보존한다.
    범위를 벗어난 행은 잘라내고, 남는 이익을 여유 있는 행에 재배분한다.
    """
    profit = rate * sale_amt
    for _ in range(n_iter):
        capped = np.clip(profit, lo * sale_amt, hi * sale_amt)
        gap = total_profit - capped.sum()
        if abs(gap) < 1.0:
            profit = capped
            break
        room = np.where(gap > 0, hi * sale_amt - capped, capped - lo * sale_amt)
        room = np.maximum(room, 0.0)
        if room.sum() <= 0:
            profit = capped
            break
        profit = capped + np.sign(gap) * room * (abs(gap) / room.sum())
    return profit


def align_rate_mean(profit, sale_amt, total_profit, target_mean_rate):
    """
    영업이익률의 '행 평균'을 통계값(0.83)에 맞춘다.

    제약이 두 개다.
      (1) 이익 총액 = total_profit      -> 매출가중 평균 이익률이 고정된다
      (2) 행 평균 이익률 = 0.83
    두 조건을 동시에 만족시키기 위해, 매출 규모(z)에 대한 1차 보정을 푼다.
        rate' = rate + a + b * z
    z 는 log(매출)을 표준화한 값이라 평균이 0 이므로 a, b 가 바로 풀린다.
    """
    rate = profit / sale_amt
    z = np.log(np.maximum(sale_amt, 1.0))
    z = (z - z.mean()) / z.std()

    a = target_mean_rate - rate.mean()
    denom = float(np.sum(z * sale_amt))
    b = -a * float(np.sum(sale_amt)) / denom if denom != 0 else 0.0

    new_rate = rate + a + b * z
    return new_rate * sale_amt


def mode_generation_newness(mode_codes):
    """
    제품모드의 '최신도'를 0~1 로 만든다.

    목업 규칙 4.4 의 최신 제품 판단 기준 두 가지
      (1) 제품별 SEQ 가 작을수록 최신
      (2) 제품명의 숫자가 클수록 최신 (DDR5 > DDR4)
    이 두 기준은 같은 계열(DDR / LPDDR / GDDR / HBM) 안에서는 서로 일치하지만,
    계열이 다르면 SEQ 순서가 곧 최신 순서는 아니다(DDR 계열이 앞 번호를 쓴다).
    그래서 계열 안에서 세대 숫자로 최신도를 매긴다.
      DDR5=1.0 / DDR4=0.5 / DDR3=0.0 , HBM4=1.0 / HBM3=0.0 ...
    """
    families = []
    generations = []
    for code in mode_codes:
        digits = "".join(ch for ch in code if ch.isdigit())
        family = code
        for ch in "0123456789":
            family = family.replace(ch, "")
        family = family.replace("E", "")           # HBM2E -> HBM
        families.append(family)
        generations.append(float(digits) if digits else 0.0)

    df = pd.DataFrame({"family": families, "gen": generations})
    out = np.zeros(len(df))
    for family, group in df.groupby("family"):
        lo, hi = group["gen"].min(), group["gen"].max()
        if hi == lo:
            out[group.index] = 0.5
        else:
            out[group.index] = (group["gen"] - lo) / (hi - lo)
    return out
