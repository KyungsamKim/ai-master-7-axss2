# -*- coding: utf-8 -*-
"""
make_outputs.py
---------------
생성된 목업 데이터를 3가지 형태로 내보낸다.
  1) CSV        - DBeaver / SQL*Loader 등으로 적재
  2) SQL        - Oracle INSERT ALL 스크립트
  3) XLSX       - Table Insert 용 엑셀 (+ 생성규칙·검증 시트)
"""

import os
import numpy as np
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

import mock_config as C
import build_core as B
from generate_mock_data import parse_ddl_columns

OUT = C.OUT_DIR
BASE = "PMO_PROFBLT_IMPROV_PROD_IDC_REPORT_MOCK"
FQTN = f"{C.TABLE_OWNER}.{C.TABLE_NAME}"


# ---------------------------------------------------------------------------
# 1. CSV
# ---------------------------------------------------------------------------
def write_csv(table):
    path = os.path.join(OUT, BASE + ".csv")
    out = table.copy()
    out["CRT_TM"] = C.CRT_TM
    out.to_csv(path, index=False, encoding="utf-8-sig")
    return path


# ---------------------------------------------------------------------------
# 2. Oracle INSERT 스크립트
# ---------------------------------------------------------------------------
def sql_literal(value, col, coltypes):
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "NULL"
    dtype = coltypes[col]
    if dtype == "DATE":
        return f"TO_DATE('{value}','YYYY-MM-DD')"
    if dtype.startswith("VARCHAR2"):
        return "'" + str(value).replace("'", "''") + "'"
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    text = f"{float(value):.6f}".rstrip("0").rstrip(".")
    return text if text not in ("", "-") else "0"


def write_sql(table, columns, coltypes, batch=250):
    path = os.path.join(OUT, BASE + ".sql")
    values_matrix = []
    for col in columns:
        series = table[col]
        values_matrix.append([sql_literal(v, col, coltypes) for v in series])
    rows = list(zip(*values_matrix))

    with open(path, "w", encoding="utf-8") as f:
        f.write("--------------------------------------------------------------------------------\n")
        f.write(f"-- {FQTN} 목업 데이터 INSERT 스크립트\n")
        f.write(f"-- 행 수 : {len(table):,} "
                f"(제품조합 {C.N_COMBO:,} x {len(C.MONTHS)}개월 - 신규제품 {C.N_LATE_LAUNCH}건의 1월분)\n")
        f.write("-- 컬럼 순서는 CREATE TABLE 정의 순서와 동일하다.\n")
        f.write("-- 실행 전 : ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD';\n")
        f.write("--------------------------------------------------------------------------------\n")
        f.write("-- 컬럼 순서\n-- " + ", ".join(columns) + "\n\n")

        for start in range(0, len(rows), batch):
            chunk = rows[start:start + batch]
            f.write("INSERT ALL\n")
            for row in chunk:
                f.write(f"  INTO {FQTN} VALUES ({','.join(row)})\n")
            f.write("SELECT 1 FROM DUAL;\n\n")
        f.write("COMMIT;\n")
    return path


# ---------------------------------------------------------------------------
# 3. 엑셀
# ---------------------------------------------------------------------------
def write_xlsx(table, notes_rows, check_rows):
    path = os.path.join(OUT, BASE + ".xlsx")
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        table.to_excel(writer, sheet_name="INSERT_DATA", index=False)
        pd.DataFrame(notes_rows, columns=["항목", "내용"]).to_excel(
            writer, sheet_name="생성규칙_가정", index=False)
        pd.DataFrame(check_rows).to_excel(
            writer, sheet_name="검증결과", index=False)

    wb = openpyxl.load_workbook(path)
    wb._named_styles["Normal"].font = Font(name="Arial", size=10)

    header_font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="1F4E79")
    for name in wb.sheetnames:
        ws = wb[name]
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.freeze_panes = "A2"

    ws = wb["INSERT_DATA"]
    for idx in range(1, ws.max_column + 1):
        ws.column_dimensions[get_column_letter(idx)].width = 20

    for name, widths in [("생성규칙_가정", [34, 110]), ("검증결과", [30, 26, 26, 18, 44])]:
        ws2 = wb[name]
        for i, width in enumerate(widths[:ws2.max_column], start=1):
            ws2.column_dimensions[get_column_letter(i)].width = width
        for row in ws2.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)

    wb.save(path)
    return path
