# 목업 데이터 산출물 안내

`RPLS_ADM.PMO_PROFBLT_IMPROV_PROD_IDC_REPORT` (P-Mix결과수익성개선제품정보 레포트) 목업 데이터와,
같은 자료로 채운 Semantic Layer YAML 초안입니다.

---

## 1. 파일 목록

### 목업 데이터 (셋 중 편한 것 하나만 쓰면 됩니다)

| 파일 | 크기 | 용도 |
|---|---|---|
| `PMO_PROFBLT_IMPROV_PROD_IDC_REPORT_MOCK.csv` | 약 0.7 MB | DBeaver / SQL*Loader 임포트 (권장) |
| `PMO_PROFBLT_IMPROV_PROD_IDC_REPORT_MOCK.sql` | 약 0.8 MB | Oracle `INSERT ALL` 스크립트 (250행 × 5블록) |
| `PMO_PROFBLT_IMPROV_PROD_IDC_REPORT_MOCK.xlsx` | 약 0.6 MB | Table Insert용 엑셀 (3시트) |

엑셀은 시트 3개입니다.
- `INSERT_DATA` — 1,033행 × 77컬럼, DDL 컬럼 순서 그대로
- `생성규칙_가정` — 14개 항목의 근거·가정
- `검증결과` — 35개 검증 항목과 판정

### Semantic Layer 초안

| 파일 | 내용 |
|---|---|
| `semantic_layer/common.yaml` | 공통 계층 — 업무 객체(제품·기간·계획), 집계 규약, 단위, 항등식 |
| `semantic_layer/screens/SCR_PMO_PROFBLT_PROD.yaml` | 화면별 계층 — 77개 컬럼 바인딩 |

### 생성 스크립트

`generator/` 폴더. 난수 시드(`20260820`) 고정이라 다시 돌리면 같은 데이터가 나옵니다.

```
generator/
├── mock_config.py          사람이 정한 값만 모아 둔 설정
├── build_core.py           엑셀 로딩 · 조합 생성 · IPF · 물량/단가 역산
├── generate_mock_data.py   연간 지표 산출 → 월 분리 → 파생 컬럼 → 테이블 조립
├── make_outputs.py         CSV / SQL / XLSX 출력
├── run_all.py              생성 + 검증 + 저장 일괄 실행
└── build_semantic_layer.py Semantic Layer YAML 생성
```

입력 2개(`DRAM제품속성.xlsx`, `PMO_PROFBLT_IMPROV_PROD_IDC_REPORT.sql` = CREATE TABLE DDL)를
스크립트와 같은 폴더에 두면 그대로 돌아갑니다. 다른 위치에 있으면 `mock_config.py`의
`EXCEL_PATH` / `DDL_PATH`를 절대경로로 바꾸면 됩니다. 산출물은 `outputs/` 아래에 생성됩니다.

실행:
```bash
pip install pandas numpy openpyxl pyyaml
python run_all.py               # 목업 데이터 3종
python build_semantic_layer.py  # YAML 2종
```

---

## 2. SQL 적재 방법

```sql
ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD';
-- 스크립트 실행 (DBeaver: Alt+X)
```

`INSERT ALL ... INTO 테이블 VALUES (...)` 형태로 컬럼 목록을 생략했습니다.
테이블 컬럼 순서가 DDL과 같아야 하며, 순서는 스크립트 상단 주석에 적어 두었습니다.

---

## 3. 데이터 구조

**행 구성** — 총 **1,033행**, `PRID_GBN_CD = 'M'`

```
  제품 조합 87건 × 12개월(202601~202612)   = 1,044행
- 신규 제품 11건의 1월분                    =    11행
------------------------------------------------------
  최종                                      = 1,033행
```

총 행 수를 1,033으로 잡은 근거는 수익지표 통계 시트입니다. 절대금액 컬럼 전부에서
`Total ÷ Avg`가 정확히 1,033이 나옵니다.

```
SALE_AMT  182,649,393,345 ÷ 176,814,514 = 1,033.00
SOM_EQ_QTY 119,558,014,008 ÷ 115,738,639 = 1,033.00
```

1,033은 12로 나누어떨어지지 않습니다(`1,033 = 86×12 + 1`). 그래서 조합 수는 올림(87)으로
잡고, 남는 11행은 **최신도 상위 11개 조합의 1월 행을 만들지 않는 것**으로 덜어냈습니다.
신규 제품이라 연초에는 아직 양산 전이라는 해석이고, 규칙 4.4의 "최신 제품 증가" 추세와도
맞습니다. 1월이 빠진 조합은 남은 11개월에 연간값을 다시 배분하므로 **통계 Total은 그대로
유지**됩니다. 어떤 코드값이 1월에 통째로 사라지지 않도록(예: HBM4) 코드값별로 최소 1개
조합은 1월에 남깁니다.

행 수를 바꾸려면 `mock_config.py`의 `TOTAL_ROWS` 하나만 고치면 됩니다.
`N_COMBO`(조합 수)와 `N_LATE_LAUNCH`(1월을 뺄 조합 수)는 여기서 자동 계산됩니다.

**통계 시트에서 역산한 컬럼 관계** — 생성 로직의 뼈대입니다.

| 관계 | 근거 |
|---|---|
| `SOM_EQ_QTY = SOM_DIE_QTY × Density(Gb)` | EQ/DIE = 15.93 ≈ 평균 Density 16G |
| `ASP_AMT = EQ_SALE_AMT = SALE_AMT / SOM_EQ_QTY` | 두 컬럼의 Total/Min/Max/Avg가 완전히 동일 |
| `SOM_DIE_QTY = WF_CONV_QTY × NET_DIE_300_CNT × CUM2_YLD` | DIE/WF = 1,040. 수율 0.87 기준 NET DIE ≈ 1,200으로 300mm 웨이퍼 물리값과 부합 |
| `*_PROF_AMT = *_SALE_AMT - *_COST` | 통계 Total에서 WF/EQ/DIE/PROD/YR 5계열 모두 정확히 성립 |

**FAB_DEN_CD 비중** — 엑셀에 `-`로 비어 있었습니다. `EQ/DIE = 15.93`이 곧 "매출가중 조화평균
Density"라는 점을 이용해 Density 배분을 역산했습니다.

**YR_* 컬럼** — 해당 제품 조합의 연간 합계를 그 조합의 모든 월 행에 반복합니다.
총합계 검증은 연간 그레인(조합 87건)에서 하고, 통계 Total과 일치합니다. 다만 통계 Avg는
1,033행 기준이라 `YR_*`의 행 평균은 통계 Avg의 약 11.9배로 나옵니다 — 아래 5절 참고.

---

## 4. 검증 결과 — 35개 항목 전부 PASS

- 행 수 1,033 / 컬럼 77개 DDL 순서 일치 / PK 중복 0 / NOT NULL 위반 0
- 조합별 월 수 11~12개월(11개 조합이 1월 미발생), 대상 월 202601~202612 12개 모두 존재
- VARCHAR2 길이·NUMBER(22,10) 범위 준수
- 총합계: `SALE_AMT` `SALE_QTY` `ORG_QTY` `SOM_EQ_QTY` `SOM_DIE_QTY` `WF_CONV_QTY` 모두 통계와 일치
- **월 그레인 컬럼 6개의 Avg 비율 = 1.000000** (행 수가 1,033이라 `Total ÷ 1,033`이 통계 Avg와 정확히 일치)
- 항등식 3종(EQ·웨이퍼·이익) 위반 0건
- 기간 파생(`TGT_YM` → `TGT_QUTR`/`TGT_HALF`/`TGT_YEAR`) 불일치 0건
- 비중 재현 최대 편차 0.63%p

**추세**

| 구분 | 12월/1월 |
|---|---|
| 전체 | QTY 1.48배 (12개월 단조 증가) |
| 최신 | LPDDR5 2.12 · HBM4 1.98 · GDDR7 1.80 · DDR5 1.71 |
| Legacy | HBM3 0.72 · GDDR6 0.72 · LPDDR4 0.63 · DDR3 0.52 |

---

## 5. 판단이 필요했던 지점과 알려진 편차

**행 수 해석** — 규칙 4.1의 "원본 기준 1,000~1,050"과 4.3의 "월 단위 분리"가 겹칩니다.
**규칙 4.1을 우선해 최종 테이블을 1,033행으로 맞췄습니다**(`TOTAL_ROWS = 1033`).
그 결과 월 그레인 절대금액 컬럼 6개의 `Total ÷ 행수`가 통계 Avg와 소수점까지 일치합니다.

**`YR_*`와 `SALE_AMT`의 Total이 같다는 통계** — 통계 시트에서 `SALE_AMT`와 `YR_SALE_AMT`의
Total/Min/Max가 완전히 같습니다. 이는 원본에서 *제품 조합 1건 = 행 1건*이었다는 뜻인데,
규칙 4.3의 "월 단위 분리"와는 양립할 수 없습니다. 월로 분리하는 이상 `YR_*`는 같은 조합의
여러 행에 반복될 수밖에 없고, 전체 합계는 조합당 월 수(약 11.9배)만큼 커집니다.
이 목업은 규칙 4.1(1,033행) + 4.3(12개월 존재)을 택하고 이 편차를 남겨 두었습니다.
두 통계를 모두 정확히 맞추려면 *1,033개 조합에 각각 하나의 월만 배정*하는 구성이어야 하는데,
그러면 규칙 4.4의 월별 추세를 제품별로 볼 수 없어집니다.

**조합 수가 1,033 → 87로 줄면서 보정한 것** — 조합이 줄면 `solve_density_tilt`의 이분탐색
(IPF 60회)과 최종 배분(IPF 200회) 사이 오차가 커져 `SOM_DIE_QTY` 총합이 0.11% 틀어졌습니다.
`solve_eq_and_die`에 사후 보정을 넣어 `sum(DIE) = Total_DIE`와 `sum(DIE×Density) = Total_EQ`를
동시에 정확히 맞추도록 했습니다(미지수 2개 `s`, `t`로 `die' = s·die·Density^t`).

**값 정의가 없는 PK 컬럼 4개** — `DATA_GBN_CD` `CELL_LAYER_TYP_CD` `UPPER_CD` `SSD_CLAS_NM`은
엑셀 "제품 속성 데이터"에 정의가 없어 DDL 기본값 `' '`(공백)을 넣었습니다. 임의 코드값을
만들지 않았습니다. `DATA_GBN_CD`에 계획/실적 두 값을 넣으면 계획 대비 실적 비교 데이터셋으로
확장할 수 있습니다.

**단위당 원가 컬럼의 평균 편차** — `DIE_VAR_COST` `PROD_COO_COST` 등 단위당 원가의 행 평균이
통계 대비 1.1~1.5배 높습니다. 원가는 `단가 − 이익`의 작은 잔차라, 단가·이익이 각각 ±5% 안에
들어와도 잔차에서는 상대오차가 증폭됩니다. 단가·이익 컬럼(Avg 비율 0.94~1.01)을 우선
맞추는 쪽을 택했습니다.

**WF_CONV_QTY의 Min/Max** — 통계 시트의 Min(0.000471)/Max(173.256)이 Total(7,219,775)·
Avg(6,989)와 약 1,000배 스케일이 어긋납니다. 자기 정합적인 Total·Avg를 기준으로 삼았습니다.

---

## 6. Semantic Layer YAML에 담은 것

에이전트가 이 데이터를 잘못 집계하지 않도록, 컬럼별 집계 규약을 명시했습니다.

| 규약 | 적용 대상 | 이유 |
|---|---|---|
| `sum` | `SALE_AMT` `SALE_QTY` `SOM_*` `WF_CONV_QTY` | 단순 합산 가능 |
| `weighted_avg` | `WF_/EQ_/DIE_/PROD_` 40개 컬럼 | 단위당 금액. 해당 스케일 수량으로 가중해야 함 |
| `derived` | `ASP_AMT` `NET_DIE_300_CNT` `CUM2_YLD` | formula로 재계산 |
| `first` | `YR_*` 10개 컬럼 | 조합의 모든 월 행에 반복되므로 합산하면 약 12배 |

`analysis_cautions`에 다섯 가지 함정을 적어 두었습니다. 특히 아래 두 가지는 실제로 틀리기 쉽습니다.

- `YR_*`를 월 데이터와 함께 합산 → 약 12배 과다 계상
- `TGT_YM`/`TGT_QUTR`/`TGT_HALF`/`TGT_YEAR`를 동시에 group by → 중복 계상

두 YAML 모두 **초안**입니다. 2주차 산출물 5.1의 "오프라인 빌더 초안 → 사람 검수" 흐름대로,
실제 화면·컬럼을 보시고 검수한 뒤 확정하시면 됩니다.

---

## 7. 회사 자료 취급 참고

`semantic_layer/` YAML과 `generator/mock_config.py`에는 실제 컬럼명·코드값이 들어 있습니다.
개인 GitHub 저장소에 올리실 때는 기존 방침(추상화된 스키마·구조 문서만 보관)에 비추어
한 번 확인해 보시는 편이 좋겠습니다. 목업 데이터 자체는 실적 수치가 아니므로 상대적으로
자유롭습니다.
